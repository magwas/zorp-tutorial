/***************************************************************************
 *
 * This file is covered by a dual licence. You can choose whether you
 * want to use it according to the terms of the GNU GPL version 2, or
 * under the terms of Zorp Professional Firewall System EULA located
 * on the Zorp installation CD.
 *
 * $Id: connect.c,v 1.52 2004/10/05 14:06:37 chaoron Exp $
 *
 * Author  : Bazsi
 * Auditor :
 * Last audited version:
 * Notes:
 *
 ***************************************************************************/

#include <zorp/connect.h>
#include <zorp/io.h>
#include <zorp/log.h>
#include <zorp/socketsource.h>
#include <zorp/socket.h>
#include <zorp/error.h>
#include <zorp/streamfd.h>

#include <sys/types.h>
#ifdef HAVE_UNISTD_H
  #include <unistd.h>
#endif
#include <fcntl.h>

#ifdef G_OS_WIN32
#  include <winsock2.h>
#include <io.h>
#define close _close 
#else
#  include <netinet/tcp.h>
#  include <netinet/in.h>
#  include <sys/poll.h>
#endif

/** 
 * z_connector_connected:
 * @timed_out: specifies whether the operation timed out
 * @data: user data passed by socket source, assumed to point to ZConnector instance
 *
 * Private callback function, registered to a #ZSocketSource to be called
 * when the socket becomes writeable, e.g. when the connection is
 * established.
 *
 * Returns: always returns FALSE to indicate that polling the socket should end
 *
 **/
static gboolean 
z_connector_connected(gboolean timed_out, gpointer data)
{
  ZConnector *self = (ZConnector *) data;
  int error_num = 0;
  socklen_t errorlen = sizeof(error_num);
  ZConnectFunc callback;
  GError *err = NULL;
  gint fd;
  
  z_enter();
  if (!self->callback)
    z_return(FALSE); /* we have been called */
  
  fd = self->fd;
  if (timed_out)
    {
      error_num = ETIMEDOUT;
    }
  else if (getsockopt(fd, SOL_SOCKET, SO_ERROR, (char *)(&error_num), &errorlen) == -1)
    {
      /*LOG
        This message indicates that getsockopt(SOL_SOCKET, SO_ERROR)
        failed for the given fd. This system call should never fail,
        so if you see this please report it to the Zorp QA.
       */
      z_log(self->session_id, CORE_ERROR, 0, "getsockopt(SOL_SOCKET, SO_ERROR) failed for connecting socket, ignoring; fd='%d', error='%s'", self->fd, g_strerror(errno));
    }
  if (error_num)
    {
      char buf1[MAX_SOCKADDR_STRING], buf2[MAX_SOCKADDR_STRING];
      
      /*LOG
        This message indicates that the connection to the remote end
	 failed for the given reason. It is likely that the remote end
	 is unreachable.
       */
      z_log(self->session_id, CORE_ERROR, 2, "Connection to remote end failed; local='%s', remote='%s', error='%s'", 
               self->local ? z_sockaddr_format(self->local, buf1, sizeof(buf1)) : "NULL", 
               z_sockaddr_format(self->remote, buf2, sizeof(buf2)), g_strerror(error_num));
      
      /* self->poll.fd is closed when we are freed */
      fd = -1;
    }
  else
    {
#ifdef G_OS_WIN32
      WSAEventSelect(fd, 0, 0);
#endif
      z_fd_set_nonblock(fd, 0);
      z_fd_set_keepalive(fd, 1);
      
      /* don't close our fd when freed */
      self->fd = -1;
    }
  
  g_static_rec_mutex_lock(&self->lock);
  
  if (self->watch || self->blocking)
    {
      if (error_num)
        g_set_error(&err, 0, error_num, g_strerror(error_num));
      
      callback = self->callback;
      self->callback = NULL;
      callback(fd >= 0 ? z_stream_fd_new(fd, "") : NULL, err, self->user_data);
      
      g_clear_error(&err);
    }
  else
    {
      /*LOG
        This message reports that the connection was cancelled, and
        no further action is taken.
       */
      z_log(self->session_id, CORE_DEBUG, 6, "Connection cancelled, not calling callback; fd='%d'", fd);
      close(fd);
    }
  g_static_rec_mutex_unlock(&self->lock);

  /* don't poll again, and destroy associated source */
  z_return(FALSE);
}

/**
 * z_connector_source_destroy_cb:
 * @self: ZConnector instance
 *
 * This function is registered as the destroy notify function of @self when
 * the associated #ZSocketSource source is destroyed. It calls our
 * destroy_notify callback, and unrefs self.
 *
 **/
static void
z_connector_source_destroy_cb(ZConnector *self)
{
  if (self->destroy_notify)
    self->destroy_notify(self->user_data);
  z_connector_unref(self);
}

/**
 * z_connector_start_internal:
 * @s: ZConnector instance
 *
 * This function is used by the different z_connector_start_*() functions,
 * it contains the common things to do when a connection is initiated.
 *
 * Returns: the local address where we are bound
 **/
static ZSockAddr *
z_connector_start_internal(ZConnector *self)
{
  ZSockAddr *local = NULL;
  gchar buf1[MAX_SOCKADDR_STRING], buf2[MAX_SOCKADDR_STRING];

  z_enter();
  /*LOG
    This message reports that a new connection is initiated
    from/to the given addresses.
   */
  z_log(self->session_id, CORE_DEBUG, 7, "Initiating connection; from='%s', to='%s'",
        self->local ? z_sockaddr_format(self->local, buf1, sizeof(buf1)) : "NULL",
        z_sockaddr_format(self->remote, buf2, sizeof(buf2)));

  if (z_connect(self->fd, self->remote, self->sock_flags) != G_IO_STATUS_NORMAL && !z_errno_is(EINPROGRESS))
    {
      /*LOG
        This message indicates that the connection to the remote end
        failed for the given reason. It is likely that the remote end
        is unreachable.
       */
      z_log(self->session_id, CORE_ERROR, 2, "Connection to remote end failed; local='%s', remote='%s', error='%s'", 
            self->local ? z_sockaddr_format(self->local, buf1, sizeof(buf1)) : "NULL", 
            z_sockaddr_format(self->remote, buf2, sizeof(buf2)), g_strerror(errno));
      z_return(NULL);
    }

  if (z_getsockname(self->fd, &local, self->sock_flags) == G_IO_STATUS_NORMAL)
    {
      ZSockAddr *l;
      
      /* it contained the bind address, we now have an exact value */
      l = self->local;
      self->local = NULL;
      z_sockaddr_unref(l);
      self->local = local;
      z_sockaddr_ref(local);
    }
  return local;
}

/**
 * z_connector_start:
 * @s: ZConnector instance
 *
 * Start initiating the connection.
 *
 * Returns: the local address we were bound to
 **/
ZSockAddr *
z_connector_start(ZConnector *self)
{  
  ZSockAddr *local;
  
  z_enter();
  if (self->watch)
    {
      /*LOG
        This message indicates that the connection was started twice.
        Please report this error to the Balabit QA Team (devel@balabit.com).
       */
      z_log(self->session_id, CORE_ERROR, 3, "Internal error, z_connector_start was called twice;");
      z_return(NULL);
    }

  local = z_connector_start_internal(self);
  if (local)
    {
      z_connector_ref(self);
      self->watch = z_socket_source_new(self->fd, Z_SOCKEVENT_CONNECT, self->timeout);
      
      g_source_set_callback(self->watch, (GSourceFunc) z_connector_connected, self, (GDestroyNotify) z_connector_source_destroy_cb);
      if (g_source_attach(self->watch, self->context) == 0)
        {
	  /*LOG
	    This message indicates that the connection can not be initiated. It is 
	    likely that some resource is not available.
	   */
          z_log(self->session_id, CORE_ERROR, 3, "Error attaching source to context; fd='%d', context='%p'", self->fd, self->context);
          g_source_unref(self->watch);
          self->watch = NULL;
          z_connector_unref(self);
          z_sockaddr_unref(local);
          local = NULL;
        }
    }
  z_return(local);
}

/**
 * z_connector_start_block:
 * @s: ZConnector instance
 *
 * Initiate the connection and block while it either succeeds or fails.
 * Instead of returning the results the user callback is called.
 *
 * Returns: the local address we were bound to
 **/
 
#ifndef G_OS_WIN32

ZSockAddr *
z_connector_start_block(ZConnector *self)
{  
  ZSockAddr *local;
  int res;
  time_t timeout_target, timeout_left;

  z_enter();
  local = z_connector_start_internal(self);
  if (local)
    {
      struct pollfd pfd;
      
      z_connector_ref(self);
      pfd.fd = self->fd;
      pfd.events = POLLOUT;
      pfd.revents = 0;
      timeout_target = time(NULL) + self->timeout;
      do
        {
          timeout_left = timeout_target - time(NULL);
          res = poll((struct pollfd *) &pfd, 1, timeout_left < 0 ? 0 : timeout_left * 1000);
          if (res == 1)
            break;
        }
      while (res == -1 && errno == EINTR);
      self->blocking = 1;
      if (res >= 0)
        z_connector_connected(res == 0, self);
      z_connector_source_destroy_cb(self);
    }
  z_return(local);
}

#else

ZSockAddr *
z_connector_start_block(ZConnector *self)
{  
  ZSockAddr *local;
  int res;

  z_enter();
  local = z_connector_start_internal(self);
  if (local)
    {
      fd_set rf;
      TIMEVAL to;
 
      to.tv_sec = 0;
      to.tv_usec = self->timeout * 1000;
      FD_ZERO(&rf);
      FD_SET(self->fd, &rf);
      do
        {
          res = select(0,&rf,&rf,&rf,&to); //   ((struct pollfd *) &pfd, 1, self->timeout);
          if (res == 1)
            break;
        }
      while (res == -1 && errno == EINTR);
      self->blocking = 1;
      if (res >= 0)
        z_connector_connected(res == 0, self);
    }
  z_return(local);
}

#endif

/**
 * z_connector_start_in_context:
 * @s: ZConnector instance
 * @context: GMainContext to use for polling
 *
 * Same as z_connector_start() but using the context specified in context.
 *
 * Returns: the local address we were bound to
 **/
ZSockAddr *
z_connector_start_in_context(ZConnector *self, GMainContext *context)
{
  ZSockAddr *res;

  z_enter();
  if (context)
    {
      g_main_context_ref(context);
      self->context = context;
    }
  res = z_connector_start(self);
  z_return(res);
}

/**
 * z_connector_cancel:
 * @s: ZConnector instance
 *
 * Cancel connection after _start was called. It is guaranteed that no
 * user callbacks will be called after z_connector_cancel() returns.
 **/
void
z_connector_cancel(ZConnector *self)
{
  z_enter();
  
  g_static_rec_mutex_lock(&self->lock);
  if(self->watch)
    {
      /* Must unlock self->lock before call g_source_destroy,
       * because in another thread we may be hold context lock
       * (inside the glib) and wait for this lock. (For example if
       * the client stop the download in exactly the same time, when
       * the connection failed.
       */
      GSource *watch = self->watch;
      self->watch = NULL;
      g_static_rec_mutex_unlock(&self->lock);

      g_source_destroy(watch);
      g_source_unref(watch);
    }
  else
    {
      g_static_rec_mutex_unlock(&self->lock);
    }
  z_return();
}

/**
 * z_connector_set_timeout:
 * @s: ZConnector instance
 * @timeout: timeout in milliseconds
 *
 * Set connection timeout. The connection establishment may not exceed the
 * time specified in timeout.
 * 
 **/
void
z_connector_set_timeout(ZConnector *self, gint timeout)
{
  self->timeout = timeout;
}

/**
 * z_connector_set_destroy_notify:
 * @s: ZConnector instance
 * @notify: destroy notify callback
 *
 * Set the destroy notify callback to be called when this ZConnector instance is freed.
 * 
 **/
void 
z_connector_set_destroy_notify(ZConnector *self, GDestroyNotify notify)
{
  self->destroy_notify = notify;
}

/**
 * z_connector_open_socket:
 * @self: ZConnector instance
 *
 * This function opens a new socket and returns the newly created fd.
 **/
static gint
z_connector_open_socket(ZConnector *self)
{
  gint fd;
  gint on = 1;
  gchar buf[MAX_SOCKADDR_STRING];
  
  fd = socket(z_map_pf(self->remote->sa.sa_family), self->socket_type, 0);
  
  if (fd == -1)
    {
      
      /*LOG
        This message indicates that Zorp failed to create a socket for
        establishing a connection with the indicated remote endpoint.
       */
      z_log(self->session_id, CORE_ERROR, 1, "Creating socket for connecting failed; family='%d', type='%s', remote='%s', error='%s'", 
            self->remote->sa.sa_family, z_socket_type_to_str(self->socket_type), z_sockaddr_format(self->remote, buf, sizeof(buf)), g_strerror(errno));
      z_return(-1);
    }
  if (setsockopt(fd, SOL_SOCKET, SO_REUSEADDR, &on, sizeof(on)) < 0)
    {
      z_log(self->session_id, CORE_ERROR, 1, "Enabling SO_REUSEADDR on connect socket failed; family='%d', type='%s', error='%s'", 
            self->remote->sa.sa_family, z_socket_type_to_str(self->socket_type), g_strerror(errno));
    }
  if (self->local && z_bind(fd, self->local, self->sock_flags) != G_IO_STATUS_NORMAL)
    {
      z_log(self->session_id, CORE_ERROR, 1, "Error binding socket; local='%s', error='%s'", z_sockaddr_format(self->local, buf, sizeof(buf)), g_strerror(errno));
      z_return(-1);
    }
  z_fd_set_our_tos(fd, self->tos);
  if (!z_fd_set_nonblock(fd, TRUE))
    z_return(-1); /* z_fd_set_nonblock sends log message for failure */

  z_return(fd);
}

/**
 * z_connector_new:  
 * @session_id: session id used for logging
 * @local: local address to bind to.
 * @remote: remote address to connect to.
 * @sock_flags: 
 * @tos: Type of Service flag.
 * @callback: function to call when the connection is established.
 * @user_data: opaque pointer to pass to callback.
 *
 * This function creates a new ZConnector instance.
 *
 * Returns: The allocated instance.
 **/
ZConnector *
z_connector_new(ZClass *class,
                const gchar *session_id,
                gint socket_type,
                ZSockAddr *local, 
                ZSockAddr *remote,
                guint32 sock_flags,
                gint tos,
		ZConnectFunc callback,
		gpointer user_data)
{
  ZConnector *self;
  
  z_enter();
  self = Z_NEW_COMPAT(class, ZConnector);
  self->refcnt = 1;
  self->local = z_sockaddr_ref(local);
  self->remote = z_sockaddr_ref(remote);
  self->session_id = session_id ? g_strdup(session_id) : NULL;
  self->callback = callback;
  self->user_data = user_data;
  self->timeout = -1;
  self->sock_flags = sock_flags;
  self->tos = tos;
  self->socket_type = socket_type;
  self->fd = z_connector_open_socket(self);
  if (self->fd < 0)
    {
      z_connector_unref(self);
      self = NULL;
    }
  z_return((ZConnector *) self);
}

/**
 * z_connector_free:
 * @s: ZConnector instance to free
 *
 * This function is called by z_connector_unref() when the reference count
 * of s goes down to zero. It frees the contents of s.
 **/
static void 
z_connector_free(ZObject *s)
{
  ZConnector *self = Z_CAST(s, ZConnector);
  z_enter();
  self->callback = NULL;
  if (self->fd != -1)
    close(self->fd);
  if (self->watch)
    {
      /* self->watch might still be present when the destruction of this
       * object is done by the FALSE return value of our callback.
       * 1) connected returns FALSE
       * 2) GSource calls our destroy notify, which drops the reference 
       *    held by the source
       * 3) when our ref_cnt goes to 0, this function is called, but 
       *    self->watch might still be present 
       *
       * Otherwise the circular reference is broken by _cancel or right in 
       * _start when the error occurs.
       */
      g_source_destroy(self->watch);
      g_source_unref(self->watch);
      self->watch = NULL;
    } 
  z_sockaddr_unref(self->local);
  z_sockaddr_unref(self->remote);
  if (self->context)
    g_main_context_unref(self->context);
  
  g_free(self->session_id);
  z_object_free_method(s);
  z_return();
}

ZConnectorFuncs z_connector_funcs = 
{
  {
    Z_FUNCS_COUNT(ZObject),
    z_connector_free
  },
};

#ifdef G_OS_WIN32
  LIBZORPLL_EXTERN
#endif 
ZClass ZConnector__class = 
{
  Z_CLASS_HEADER,
  Z_CLASS(ZObject),               // super_class 
  "ZConnector",                   // name
  sizeof(ZConnector),             // size
  &z_connector_funcs.super        // funcs
};

ZConnectorFuncs z_stream_connector_funcs = 
{
  {
    Z_FUNCS_COUNT(ZObject),
    NULL
  }
};

#ifdef G_OS_WIN32
  LIBZORPLL_EXTERN
#endif 
ZClass ZStreamConnector__class = 
{
  Z_CLASS_HEADER,
  Z_CLASS(ZConnector),            // super_class 
  "ZStreamConnector",             // name 
  sizeof(ZConnector),             // size 
  &z_stream_connector_funcs.super //funcs 
};
