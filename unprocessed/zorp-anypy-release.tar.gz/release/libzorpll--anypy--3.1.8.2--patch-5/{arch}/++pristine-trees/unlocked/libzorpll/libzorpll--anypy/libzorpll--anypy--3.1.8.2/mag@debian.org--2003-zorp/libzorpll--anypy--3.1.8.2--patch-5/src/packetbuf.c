#include <zorp/packetbuf.h>
#include <zorp/log.h>

/**
 * z_pktbuf_dump:
 * @session_id: parameter for z_log
 * @class: parameter for z_log
 * @level: parameter for z_log
 * @self: this
 * @title: optional title to prepend
 *
 * Logs the contents of a buffer, prepended with a header if @title is not NULL.
 */
void
z_pktbuf_dump(const gchar *session_id, const gchar *class, int level, ZPktBuf *self, const gchar *title)
{
  if (title)
    {
      z_log(session_id, class, level,
            "Packet buffer dump follows; title='%s', borrowed='%s', data='%p', "
            "allocated='%" G_GSIZE_FORMAT"', length='%" G_GSIZE_FORMAT "', "
            "pos='%" G_GSIZE_FORMAT "'",
            title, YES_NO_STR(self->flags & Z_PB_BORROWED), self->data,
            self->allocated, self->length, self->pos);
    }
  z_log_data_dump(session_id, class, level, self->data, self->length);
}

/**
 * z_pktbuf_copy:
 * @self: 'this'
 * @data: pointer to the data block
 * @length: length of the data block
 *
 * Set the data/length fields of p to the specified data block by copying the
 * data to the internal buffer of ZPktBuf.
 *
 * Return: TRUE to be able to chain it.
 */
gboolean
z_pktbuf_copy(ZPktBuf *self, const guchar *data, gsize length)
{
  z_pktbuf_resize(self, length);
  if (self->pos > length)
    self->pos = length;
  self->length = length;
  memcpy(self->data, data, length);
  return TRUE;
}

/**
 * z_pktbuf_relocate:
 * @self: 'this'
 * @data: pointer to the data block
 * @length: length of the data block
 * @is_borrowed: is @data to be freed automatically or not
 *
 * Set the data/length fields of p to the specified data block without
 * copying and actually using @data as a pointer. If @is_borrowed is set, then
 * it is assumed that @data cannot be freed using g_free().
 */
void
z_pktbuf_relocate(ZPktBuf *self, guchar *data, gsize length, gboolean is_borrowed)
{
  if (self->data && !(self->flags & Z_PB_BORROWED))
    g_free(self->data);
  if (self->pos > length)
    self->pos = length;
  self->data = data;
  self->length = self->allocated = length;
  if (is_borrowed)
    self->flags |= Z_PB_BORROWED;
  else
    self->flags &= ~Z_PB_BORROWED;
}

/**
 * z_pktbuf_resize:
 * @self: this
 * @size: requested length in bytes
 *
 * Tries to ensure that at least @size bytes is available in @self.
 * NOTE: This may fail if the buffer is initialised from an external
 * and not relocatable data.
 *
 */
void
z_pktbuf_resize(ZPktBuf *self, gsize size)
{
  if (size > self->allocated)
    {
      /* We don't have to realloc borrowed memory pointer. */
      g_assert(!(self->flags & Z_PB_BORROWED));

      self->data = g_realloc(self->data, size);
      self->allocated = size;
    }
  if (self->length > size)
    self->length = size;
  if (self->pos > size)
    self->pos = size;
}

/**
 * z_pktbuf_set_available:
 * @self: this
 * @size: amount of bytes needed
 *
 * Tries to ensures that @size bytes are available in @self starting from the
 * current position.
 *
 * FIXME: Why it's setting self->length?
 * 
 * Returns:
 * TRUE on success
 */
gboolean
z_pktbuf_set_available(ZPktBuf *self, gsize size)
{
  if (self->length >= self->pos + size)
    return TRUE;
  self->length = self->pos + size;
  z_pktbuf_resize(self, self->pos + size);
  return TRUE;
}

/**
 * z_pktbuf_append:
 * @self: this
 * @data: buffer to append
 * @length: length of @data
 *
 * Tries to append a byte array to @self.
 *
 * Returns:
 * TRUE
 */
gboolean
z_pktbuf_append(ZPktBuf *self, const guchar *data, gsize length)
{
  z_pktbuf_resize(self, self->length + length);
  g_memmove(self->data + self->length, data, length);
  self->length += length;
  return TRUE;
}

/**
 * z_pktbuf_insert:
 * @self: this
 * @pos: position to insert to
 * @data: data to insert
 * @length: length of @data
 *
 * Tries to insert a byte array into @self.
 *
 * Returns:
 * TRUE on success
 */
gboolean
z_pktbuf_insert(ZPktBuf *self, gsize pos, const guchar *data, gsize length)
{
  z_pktbuf_resize(self, self->length + length);

  g_memmove(self->data + pos + length, self->data + pos, self->length - pos);
  g_memmove(self->data + pos, data, length);
  self->length += length;
  return TRUE;
}

/**
 * z_pktbuf_new:
 *
 * Create a new ZPktBuf instance, set its length to 0 and its data ptr to NULL
 *
 * Returns:
 * ZPktBuf* pointer to the new instance
 */
ZPktBuf *
z_pktbuf_new(void)
{
  ZPktBuf *self;

  z_enter();
  self = g_new0(ZPktBuf, 1);
  z_refcount_set(&self->ref_cnt, 1);
  z_return(self);
}

/**
 * z_pktbuf_part:
 *
 * Create a new ZPktBuf instance pointing to a slice of an other instance.
 * 
 * NOTE: the parent instance must hold a non-relocatable buffer, otherwise
 * it couldn't be guaranteed that a) the original instance won't get relocated
 * b) both ZPktBuf instances manipulate the same data
 * NOTE2: it turned out so that we must permit this - no way to
 * do it without hacking
 *
 * Returns:
 * ZPktBuf* pointer to the new instance
 */
ZPktBuf *
z_pktbuf_part(ZPktBuf *parent, gsize pos, gsize len)
{
  ZPktBuf *self = NULL;

  z_enter();
  self = g_new0(ZPktBuf, 1);
  z_refcount_set(&self->ref_cnt, 1);
  self->data = parent->data + pos;
  self->allocated = self->length = MIN(len, parent->length - pos);
  self->flags = Z_PB_BORROWED;
  z_return(self);
}

/**
 * z_pktbuf_ref:
 * @self: packet
 *
 * Increment the reference counter for @self.
 *
 * Returns:
 * Pointer to the instance
 */
ZPktBuf *
z_pktbuf_ref(ZPktBuf *self)
{
  z_refcount_inc(&self->ref_cnt);
  return self;
}

/**
 * z_pktbuf_unref:
 * @self: 'this'
 *
 * Decrements the reference counter for @self and once it reaches 0, it
 * deallocates the buffer if present, then the instance itself.
 */
void 
z_pktbuf_unref(ZPktBuf *self)
{
  z_enter();
  if (self && z_refcount_dec(&self->ref_cnt))
    {
      if (self->data && !(self->flags & Z_PB_BORROWED))
        g_free(self->data);

      g_free(self);
    }
  z_return();
}

/**
 * z_pktbuf_seek:
 * @self: this
 * @whence: seek type
 * @pos: amount to seek
 *
 * Moves the current position in the buffer
 *
 * Returns:
 * TRUE on success
 */
gboolean
z_pktbuf_seek(ZPktBuf *self, GSeekType whence, gssize pos)
{
  switch (whence)
    {
    case G_SEEK_CUR:
      if ((self->pos + pos) > self->length || (((gssize)self->pos) + pos) < 0)
        return FALSE;
      self->pos += pos;
      break;

    case G_SEEK_SET:
      if (pos > (gssize)self->length || pos < 0)
        return FALSE;
      self->pos = pos;
      break;

    case G_SEEK_END:
      if ((pos > 0) || ((gssize)self->length > -pos))
        return FALSE;
      self->pos = self->length + pos;
      break;
    }
  return TRUE;
}

/**
 * z_pktbuf_get_uX:
 * @self: this
 * @e: endianness of the stored value
 * @res: pointer to store the value to
 *
 * Reads an unsigned X-bit number from the current position of @self and
 * stores it to @res if it's not NULL, moving the current position pointer to
 * the next available position.
 *
 * Returns:
 * TRUE on success
 */

/**
 * z_pktbuf_put_uX:
 * @self: this
 * @e: endianness to use for storing the value
 * @d: value to store
 *
 * Writes an unsigned X-bit number to the current position of @self, moving
 * the current position pointer to the next available position.
 *
 * Returns:
 * TRUE on success
 */

/**
 * z_pktbuf_get_uXs:
 * @self: this
 * @e: endianness of the stored values
 * @n: number of values to read
 * @res: pointer to store the values to
 *
 * Reads an array of @n unsigned X-bit numbers from the current position of
 * @self and stores them to @res if it's not NULL, moving the current position
 * pointer to the next available position.
 *
 * Returns:
 * TRUE on success
 */

/**
 * z_pktbuf_put_uXs:
 * @self: this
 * @e: endianness to use for storing the values
 * @n: number of values to write
 * @res: array of values to write
 *
 * Writes an array of @n unsigned X-bit numbers to the current position of
 * @self, moving the current position pointer to the next available position.
 *
 * Returns:
 * TRUE on success
 */

gboolean
z_pktbuf_get_u8(ZPktBuf *self, guint8 *res)
{
  if (z_pktbuf_available(self) < 1)
    {
      z_log(NULL, CORE_DEBUG, 7, "Error parsing uint8; length='%" G_GSIZE_FORMAT "', pos='%" G_GSIZE_FORMAT"'", self->length, self->pos);
      return FALSE;
    }

  if (res)
    res[0] = *(guint8*)(self->data + self->pos);
  self->pos++;
  return TRUE;
}

gboolean
z_pktbuf_get_u16(ZPktBuf *self, gint e, guint16 *res)
{
  if (z_pktbuf_available(self) < 2)
    {
      z_log(NULL, CORE_DEBUG, 7, "Error parsing uint16; length='%" G_GSIZE_FORMAT "', pos='%" G_GSIZE_FORMAT"'", self->length, self->pos);
      return FALSE;
    }

  if (res)
    {
      if (e == G_HOST_ENDIAN)
        res[0] = *(guint16*)(self->data + self->pos);
      else
        res[0] = GUINT16_SWAP_LE_BE(*(guint16*)(self->data + self->pos));
    }
  self->pos += 2;
  return TRUE;
}

gboolean
z_pktbuf_get_u32(ZPktBuf *self, gint e, guint32 *res)
{
  if (z_pktbuf_available(self) < 4)
    {
      z_log(NULL, CORE_DEBUG, 7, "Error parsing uint32; length='%" G_GSIZE_FORMAT "', pos='%" G_GSIZE_FORMAT"'", self->length, self->pos);
      return FALSE;
    }

  if (res)
    {
      if (e == G_HOST_ENDIAN)
        res[0] = *(guint32*)(self->data + self->pos);
      else
        res[0] = GUINT32_SWAP_LE_BE(*(guint32*)(self->data + self->pos));
    }
  self->pos += 4;
  return TRUE;
}

gboolean
z_pktbuf_get_u64(ZPktBuf *self, gint e, guint64 *res)
{
  if (z_pktbuf_available(self) < 8)
    {
      z_log(NULL, CORE_DEBUG, 7, "Error parsing uint64; length='%" G_GSIZE_FORMAT "', pos='%" G_GSIZE_FORMAT"'", self->length, self->pos);
      return FALSE;
    }

  if (res)
    {
      if (e == G_HOST_ENDIAN)
        res[0] = *(guint64*)(self->data + self->pos);
      else
        res[0] = GUINT64_SWAP_LE_BE(*(guint64*)(self->data + self->pos));
    }
  self->pos += 8;
  return TRUE;
}

gboolean
z_pktbuf_put_u8(ZPktBuf *self, guint8 d)
{
  z_pktbuf_set_available(self, 1);

  *(guint8*)(self->data + self->pos) = d;
  self->pos++;
  return TRUE;
}

gboolean
z_pktbuf_put_u16(ZPktBuf *self, gint e, guint16 d)
{
  z_pktbuf_set_available(self, 2);

  if (e == G_HOST_ENDIAN)
    *(guint16*)(self->data + self->pos) = d;
  else
    *(guint16*)(self->data + self->pos) = GUINT16_SWAP_LE_BE(d);
  self->pos += 2;
  return TRUE;
}

gboolean
z_pktbuf_put_u32(ZPktBuf *self, gint e, guint32 d)
{
  z_pktbuf_set_available(self, 4);

  if (e == G_HOST_ENDIAN)
    *(guint32*)(self->data + self->pos) = d;
  else
    *(guint32*)(self->data + self->pos) = GUINT32_SWAP_LE_BE(d);
  self->pos += 4;
  return TRUE;
}

gboolean
z_pktbuf_put_u64(ZPktBuf *self, gint e, guint64 d)
{
  z_pktbuf_set_available(self, 8);

  if (e == G_HOST_ENDIAN)
    *(guint64*)(self->data + self->pos) = d;
  else
    *(guint64*)(self->data + self->pos) = GUINT64_SWAP_LE_BE(d);
  self->pos += 8;
  return TRUE;
}

gboolean
z_pktbuf_get_u8s(ZPktBuf *self, gsize n, guint8 *res)
{
  if (z_pktbuf_available(self) < n)
    {
      z_log(NULL, CORE_DEBUG, 7, "Error parsing uint8 array; length='%" G_GSIZE_FORMAT "', pos='%" G_GSIZE_FORMAT"', req_len='%" G_GSIZE_FORMAT"'", self->length, self->pos, n);
      return FALSE;
    }

  if (res)
    memcpy(res, self->data + self->pos, n);
  self->pos += n;
  return TRUE;

}

gboolean
z_pktbuf_get_u16s(ZPktBuf *self, gint e, gsize n, guint16 *res)
{
  guint i;

  n <<= 1;
  if (z_pktbuf_available(self) < n)
    {
      z_log(NULL, CORE_DEBUG, 7, "Error parsing uint16 array; length='%" G_GSIZE_FORMAT "', pos='%" G_GSIZE_FORMAT"', req_len='%" G_GSIZE_FORMAT"'", self->length, self->pos, n);
      return FALSE;
    }

  if (res)
    {
      if (e == G_HOST_ENDIAN)
        {
          memcpy(res, self->data + self->pos, n);
        }
      else
        {
          for (i = 0; i < n; i += 2)
            *(guint16*)((guint8*)res + i) = GUINT16_SWAP_LE_BE(*(guint16*)(self->data + self->pos + i));
        }
    }
  self->pos += n;
  return TRUE;
}

gboolean
z_pktbuf_get_u32s(ZPktBuf *self, gint e, gsize n, guint32 *res)
{
  guint i;

  n <<= 2;
  if (z_pktbuf_available(self) < n)
    {
      z_log(NULL, CORE_DEBUG, 7, "Error parsing uint32 array; length='%" G_GSIZE_FORMAT "', pos='%" G_GSIZE_FORMAT"', req_len='%" G_GSIZE_FORMAT"'", self->length, self->pos, n);
      return FALSE;
    }

  if (res)
    {
      if (e == G_HOST_ENDIAN)
        {
          memcpy(res, self->data + self->pos, n);
        }
      else
        {
          for (i = 0; i < n; i += 4)
            *(guint32*)((guint8*)res + i) = GUINT32_SWAP_LE_BE(*(guint32*)(self->data + self->pos + i));
        }
    }
  self->pos += n;
  return TRUE;
}

gboolean
z_pktbuf_get_u64s(ZPktBuf *self, gint e, gsize n, guint64 *res)
{
  guint i;

  n <<= 3;
  if (z_pktbuf_available(self) < n)
    {
      z_log(NULL, CORE_DEBUG, 7, "Error parsing uint64 array; length='%" G_GSIZE_FORMAT "', pos='%" G_GSIZE_FORMAT"', req_len='%" G_GSIZE_FORMAT"'", self->length, self->pos, n);
      return FALSE;
    }

  if (res)
    {
      if (e == G_HOST_ENDIAN)
        {
          memcpy(res, self->data + self->pos, n);
        }
      else
        {
          for (i = 0; i < n; i += 8)
            *(guint64*)((guint8*)res + i) = GUINT64_SWAP_LE_BE(*(guint64*)(self->data + self->pos + i));
        }
    }
  self->pos += n;
  return TRUE;
}

gboolean
z_pktbuf_put_u8s(ZPktBuf *self, gsize n, const guint8 *res)
{
  z_pktbuf_set_available(self, n);

  if (res)
    memcpy(self->data + self->pos, res, n);
  self->pos += n;
  return TRUE;

}

gboolean
z_pktbuf_put_u16s(ZPktBuf *self, gint e, gsize n, const guint16 *res)
{
  guint i;

  n <<= 1;
  z_pktbuf_set_available(self, n);

  if (res)
    {
      if (e == G_HOST_ENDIAN)
        {
          memcpy(self->data + self->pos, res, n);
        }
      else
        {
          for (i = 0; i < n; i += 2)
            *(guint16*)(self->data + self->pos + i) = GUINT16_SWAP_LE_BE(*(guint16*)((guint8*)res + i));
        }
    }
  self->pos += n;
  return TRUE;
}

gboolean
z_pktbuf_put_u32s(ZPktBuf *self, gint e, gsize n, const guint32 *res)
{
  guint i;

  n <<= 2;
  z_pktbuf_set_available(self, n);

  if (res)
    {
      if (e == G_HOST_ENDIAN)
        {
          memcpy(self->data + self->pos, res, n);
        }
      else
        {
          for (i = 0; i < n; i += 4)
            *(guint32*)(self->data + self->pos + i) = GUINT32_SWAP_LE_BE(*(guint32*)((guint8*)res + i));
        }
    }
  self->pos += n;
  return TRUE;
}

gboolean
z_pktbuf_put_u64s(ZPktBuf *self, gint e, gsize n, const guint64 *res)
{
  guint i;

  n <<= 3;
  z_pktbuf_set_available(self, n);

  if (res)
    {
      if (e == G_HOST_ENDIAN)
        {
          memcpy(self->data + self->pos, res, n);
        }
      else
        {
          for (i = 0; i < n; i += 8)
            *(guint64*)(self->data + self->pos + i) = GUINT64_SWAP_LE_BE(*(guint64*)((guint8*)res + i));
        }
    }
  self->pos += n;
  return TRUE;
}

gboolean
z_pktbuf_get_boolean(ZPktBuf *self, gboolean *res)
{
  if (z_pktbuf_available(self) < 1)
    {
      z_log(NULL, CORE_DEBUG, 7, "Error parsing boolean; length='%" G_GSIZE_FORMAT "', pos='%" G_GSIZE_FORMAT"'", self->length, self->pos);
      return FALSE;
    }

  if (res)
    res[0] = !!(*(guint8*)(self->data + self->pos));
  self->pos++;
  return TRUE;
}

gboolean
z_pktbuf_put_boolean(ZPktBuf *self, gboolean res)
{
  if (!z_pktbuf_set_available(self, 1))
    return FALSE;

  *(guint8*)(self->data + self->pos) = res ? 1 : 0;
  self->pos++;
  return TRUE;
}


gboolean
z_pktbuf_get_boolean16(ZPktBuf *self, gboolean *res)
{
  if (z_pktbuf_available(self) < 2)
    {
      z_log(NULL, CORE_DEBUG, 7, "Error parsing boolean16; length='%" G_GSIZE_FORMAT "', pos='%" G_GSIZE_FORMAT"'", self->length, self->pos);
      return FALSE;
    }

  if (res)
    res[0] = !!(*(guint16*)(self->data + self->pos));
  self->pos += 2;
  return TRUE;
}
