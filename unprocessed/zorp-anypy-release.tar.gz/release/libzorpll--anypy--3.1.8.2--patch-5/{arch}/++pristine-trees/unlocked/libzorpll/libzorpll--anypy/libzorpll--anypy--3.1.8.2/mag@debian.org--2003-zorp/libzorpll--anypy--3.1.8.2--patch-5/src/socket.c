/***************************************************************************
 *
 * This file is covered by a dual licence. You can choose whether you
 * want to use it according to the terms of the GNU GPL version 2, or
 * under the terms of Zorp Professional Firewall System EULA located
 * on the Zorp installation CD.
 *
 * $Id: socket.c,v 1.21 2004/05/22 14:04:16 bazsi Exp $
 *
 * Author  : Bazsi
 * Auditor :
 * Last audited version:
 * Notes:
 *
 ***************************************************************************/

#include <zorp/socket.h>
#include <zorp/cap.h>
#include <zorp/log.h>
#include <zorp/error.h>

#define MAGIC_FAMILY_NUMBER 111

/**
 * z_bind:
 * @fd: socket to bind
 * @addr: address to bind
 *
 * A thin interface around bind() using a ZSockAddr structure for
 * socket address. It enables the NET_BIND_SERVICE capability (should be
 * in the permitted set).
 *
 **/
GIOStatus
z_bind(gint fd, ZSockAddr *addr, guint32 sock_flags)
{
  cap_t saved_caps;
  GIOStatus rc;
  
  z_enter();
  saved_caps = cap_save();
  cap_enable(CAP_NET_BIND_SERVICE); /* for binding low numbered ports */
  cap_enable(CAP_NET_ADMIN); /* for binding non-local interfaces, transparent proxying */
  
  if (addr->sa_funcs && addr->sa_funcs->sa_bind_prepare)
    addr->sa_funcs->sa_bind_prepare(fd, addr, sock_flags);

  if (addr->sa_funcs && addr->sa_funcs->sa_bind)
    rc = addr->sa_funcs->sa_bind(fd, addr, sock_flags);
  else
    {
      if (addr && z_ll_bind(fd, &addr->sa, addr->salen, sock_flags) < 0)
        {
          gchar buf[MAX_SOCKADDR_STRING];
          /*LOG
            This message indicates that the low level bind failed for the given reason.
           */
          z_log(NULL, CORE_ERROR, 3, "bind() failed; bind='%s', error='%s'", z_sockaddr_format(addr, buf, sizeof(buf)), g_strerror(errno));
          cap_restore(saved_caps);
          z_return(G_IO_STATUS_ERROR);
        }
      rc = G_IO_STATUS_NORMAL;
    }
  cap_restore(saved_caps);
  z_return(rc);
}

/**
 * z_accept:
 * @fd: accept connection on this socket
 * @newfd: fd of the accepted connection
 * @addr: store the address of the client here
 *
 * Accept a connection on the given fd, returning the newfd and the
 * address of the client in a Zorp SockAddr structure.
 **/
GIOStatus
z_accept(gint fd, gint *newfd, ZSockAddr **addr, guint32 sock_flags)
{
  char sabuf[1024];
  int salen = sizeof(sabuf);
  struct sockaddr *sa = (struct sockaddr *) sabuf;
  
  /* NOTE: workaround a Linux 2.4.20 kernel problem */
  sa->sa_family = MAGIC_FAMILY_NUMBER;
  
  do
    {
      *newfd = z_ll_accept(fd, (struct sockaddr *) sabuf, &salen, sock_flags);
    }
  while (*newfd == -1 && z_errno_is(EINTR));
  if (*newfd != -1)
    {
      if (sa->sa_family == MAGIC_FAMILY_NUMBER && salen == sizeof(sabuf))
        {
          /* workaround the linux 2.4.20 problem */
          sa->sa_family = AF_UNIX;
          salen = 2;
        }
      *addr = z_sockaddr_new((struct sockaddr *) sabuf, salen);
    }
  else if (z_errno_is(EAGAIN))
    {
      return G_IO_STATUS_AGAIN;
    }
  else
    {
      /*LOG
        This message indicates that the low level accept of a connection failed
        for the given reason.
       */
      z_log(NULL, CORE_ERROR, 3, "accept() failed; fd='%d', error='%s'", fd, g_strerror(errno));
      return G_IO_STATUS_ERROR;
    }
  return G_IO_STATUS_NORMAL;
}

/**
 * z_connect:
 * @fd: socket to connect
 * @remote: remote address
 *
 * Connect a socket using Zorp style ZSockAddr structure.
 **/
GIOStatus
z_connect(gint fd, ZSockAddr *remote, guint32 sock_flags)
{
  int rc;

  z_enter();
  do
    {
      rc = z_ll_connect(fd, &remote->sa, remote->salen, sock_flags);
    }
  while (rc == -1 && z_errno_is(EINTR));

  if (rc != -1)
    z_return(G_IO_STATUS_NORMAL);

  if (!z_errno_is(EINPROGRESS))
    {
      int saved_errno = z_errno_get();

      /*LOG
        This message indicates that the low level connection establishment failed for
        the given reason.
        */
      z_log(NULL, CORE_ERROR, 3, "connect() failed; fd='%d', error='%s'", fd, g_strerror(errno));
      z_errno_set(saved_errno);
    }
  z_return(G_IO_STATUS_ERROR);
}

/**
 * z_disconnect:
 * @fd: socket to disconnect
 * @sock_flags: socket flags (not used)
 *
 * Disconnect an already connected socket for protocols that support this
 * operation. (for example UDP)
 **/
GIOStatus
z_disconnect(int fd, guint32 sock_flags G_GNUC_UNUSED)
{
  gint rc;
  struct sockaddr sa;

  z_enter();
  sa.sa_family = AF_UNSPEC;
  do
    {
      rc = connect(fd, &sa, sizeof(struct sockaddr));
    }
  while (rc == -1 && errno == EINTR);

  if (rc != -1)
    z_return(G_IO_STATUS_NORMAL);

  /*LOG
    This message indicates that the low level disconnect failed for
    the given reason.
    */
  z_log(NULL, CORE_ERROR, 3, "Disconnect failed; error='%s'", g_strerror(errno));
  z_return(G_IO_STATUS_ERROR);
}

/**
 * z_listen:
 * @fd: socket to listen
 * @backlog: the number of possible connections in the backlog queue
 * @accept_one: whether only one connection is to be accepted (used as a hint)
 *
 * Start listening on this socket given the underlying protocol supports it.
 **/
GIOStatus
z_listen(gint fd, gint backlog, guint32 sock_flags)
{
  if (z_ll_listen(fd, backlog, sock_flags) == -1)
    {
      /*LOG
        This message indicates that the low level listen failed for
        the given reason.
       */
      z_log(NULL, CORE_ERROR, 3, "listen() failed; fd='%d', error='%s'", fd, g_strerror(errno));
      return G_IO_STATUS_ERROR;
    }
  return G_IO_STATUS_NORMAL;
}

/**
 * z_getsockname:
 * @fd: socket
 * @local_addr: the local address is returned here
 *
 * Get the local address where a given socket is bound.
 **/ 
GIOStatus
z_getsockname(gint fd, ZSockAddr **local_addr, guint32 sock_flags)
{
  char sabuf[1500];
  socklen_t salen = sizeof(sabuf);
  
  if (z_ll_getsockname(fd, (struct sockaddr *) sabuf, &salen, sock_flags) == -1)
    {
      /*LOG
        This message indicates that the getsockname() system call failed
        for the given fd.
       */
      z_log(NULL, CORE_ERROR, 3, "getsockname() failed; fd='%d', error='%s'", fd, g_strerror(errno));
      return G_IO_STATUS_ERROR;
    }
  *local_addr = z_sockaddr_new((struct sockaddr *) sabuf, salen);
  return G_IO_STATUS_NORMAL;
}

/**
 * z_getpeername:
 * @fd: socket
 * @peer_addr: the address of the peer is returned here
 *
 * Get the remote address where a given socket is connected.
 **/ 
GIOStatus
z_getpeername(gint fd, ZSockAddr **peer_addr, guint32 sock_flags)
{
  char sabuf[1500];
  socklen_t salen = sizeof(sabuf);
  
  if (z_ll_getpeername(fd, (struct sockaddr *) sabuf, &salen, sock_flags) == -1)
    {
      return G_IO_STATUS_ERROR;
    }
  *peer_addr = z_sockaddr_new((struct sockaddr *) sabuf, salen);
  return G_IO_STATUS_NORMAL;
}

/**
 * z_getdestname:
 * @fd: socket
 * @peer_addr: the address of the peer's original destination is returned here
 *
 * Get the original destination of a client represented by the socket.
 **/ 
GIOStatus
z_getdestname(gint fd, ZSockAddr **dest_addr, guint32 sock_flags)
{
  char sabuf[1500];
  socklen_t salen = sizeof(sabuf);
  
  if (z_ll_getdestname(fd, (struct sockaddr *) sabuf, &salen, sock_flags) == -1)
    {
      return G_IO_STATUS_ERROR;
    }
  *dest_addr = z_sockaddr_new((struct sockaddr *) sabuf, salen);
  return G_IO_STATUS_NORMAL;
}

/* low level functions */
gint
z_do_ll_bind(int fd, struct sockaddr *sa, socklen_t salen, guint32 sock_flags G_GNUC_UNUSED)
{
  if ((sock_flags & ZSF_LOOSE_BIND) == 0 ||
      sa->sa_family != AF_INET ||
      ntohs(((struct sockaddr_in *) sa)->sin_port) == 0)
    {
      return bind(fd, sa, salen);
    }
  else
    {
      gint rc, range;
      
      /* the port is sa is only a hint, the only requirement is that the
       * allocated port is in the same group, but we need to disable REUSE
       * address for this to work properly */
       
      rc = bind(fd, sa, salen);
      if (rc < 0 && errno == EADDRINUSE)
        {
          guint16 port_min, port_max;
          guint16 port;
          
          port = ntohs(((struct sockaddr_in *) sa)->sin_port);
          if (port < 512)
            {
              port_min = 1;
              port_max = 511;
            }
          else if (port < 1024)
            {
              port_min = 512;
              port_max = 1023;
            }
          else
            {
              port_min = 1024;
              port_max = 65535;
            }
          port++;
          range = port_max - port_min + 1;
          for (; range > 0; port++, range--)
            {
              if (port > port_max)
                port = port_min;
              ((struct sockaddr_in *) sa)->sin_port = htons(port);
              if (bind(fd, sa, salen) >= 0)
                {
                  return 0;
                }
              else if (errno != EADDRINUSE)
                {
                  rc = -1;
                  break;
                }
            }
        }
      return rc;
    }
}

gint
z_do_ll_accept(int fd, struct sockaddr *sa, socklen_t *salen, guint32 sock_flags G_GNUC_UNUSED)
{
  return accept(fd, sa, salen);
}

gint 
z_do_ll_connect(int fd, struct sockaddr *sa, socklen_t salen, guint32 sock_flags G_GNUC_UNUSED)
{
  return connect(fd, sa, salen);
}

gint 
z_do_ll_listen(int fd, gint backlog, guint32 sock_flags G_GNUC_UNUSED)
{
  return listen(fd, backlog);
}

gint
z_do_ll_getsockname(int fd, struct sockaddr *sa, socklen_t *salen, guint32 sock_flags G_GNUC_UNUSED)
{
  return getsockname(fd, sa, salen);
}

gint 
z_do_ll_getpeername(int fd, struct sockaddr *sa, socklen_t *salen, guint32 sock_flags G_GNUC_UNUSED)
{
  return getpeername(fd, sa, salen);
}

ZSocketFuncs z_socket_funcs = 
{
  z_do_ll_bind,
  z_do_ll_accept,
  z_do_ll_connect,
  z_do_ll_listen,
  z_do_ll_getsockname,
  z_do_ll_getpeername,
  z_do_ll_getsockname
};

ZSocketFuncs *socket_funcs = &z_socket_funcs;

#ifdef G_OS_WIN32

#include <winsock2.h>

gboolean
z_socket_init(void)
{
  WSADATA wsa;
  int res;

  res = WSAStartup(MAKEWORD(2,0), &wsa);
  if (res)
    {
      /*LOG
        This message indicates that Winsock startup failed for the given reason.
       */
      z_log(NULL, CORE_DEBUG, 0, "WinSock startup failed; error_code='%d'", WSAGetLastError() );
      return FALSE;
    }
  return TRUE;
}

void
z_socket_done(void)
{
  WSACleanup();
}

#else

gboolean
z_socket_init(void)
{
  return TRUE;
}

void
z_socket_done(void)
{
}

#endif
