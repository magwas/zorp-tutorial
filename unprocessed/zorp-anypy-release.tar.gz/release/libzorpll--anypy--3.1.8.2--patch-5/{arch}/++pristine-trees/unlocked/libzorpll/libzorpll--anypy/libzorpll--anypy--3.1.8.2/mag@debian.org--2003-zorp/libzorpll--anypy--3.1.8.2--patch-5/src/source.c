/***************************************************************************
 *
 * This file is covered by a dual licence. You can choose whether you
 * want to use it according to the terms of the GNU GPL version 2, or
 * under the terms of Zorp Professional Firewall System EULA located
 * on the Zorp installation CD.
 *
 * $Id: source.c,v 1.27 2004/05/22 14:04:16 bazsi Exp $
 *
 * Author  : SaSa
 * Auditor :
 * Last audited version:
 * Notes:
 *
 ***************************************************************************/

#include <zorp/source.h>
#include <zorp/log.h>

#include <glib.h>

/* miscelaneous source objects for use throughout the ZMS */

typedef struct _ZThresholdSource
{
  GSource super;
  guint idle_threshold;
  guint busy_threshold;
  time_t last_call;
  time_t start_time;
} ZThresholdSource;

/**
 * z_threshold_source_prepare:
 * @s: source object
 * @timeout: returns the calculated timeout here
 *
 * prepare() function for the threshold source
 **/
static gboolean
z_threshold_source_prepare(GSource *s, gint *timeout)
{
  ZThresholdSource *self = (ZThresholdSource *)s;
  time_t now;
  
  now = time(NULL);
  self->start_time = now;
  
  *timeout = MIN(self->idle_threshold,
                 self->busy_threshold + self->last_call - now) * 1000;
  
  return FALSE;
}

/**
 * z_threshold_source_check:
 * @s: source object
 *
 * check() function for the threshold source
 **/
static gboolean
z_threshold_source_check(GSource *s)
{
  ZThresholdSource *self = (ZThresholdSource *) s;
  time_t now;
  gboolean ret;
  
  z_enter();
  now = time(NULL);
  ret = ((time_t)(self->start_time + self->idle_threshold) <= now);
  ret = ret || ((time_t)(self->last_call + self->busy_threshold) <= now);
  z_return(ret);
}

/**
 * z_threshold_source_dispatch:
 * @s: source object
 * @callback: callback function associated with the source
 * @user_data: pointer to be passed to the callback function
 *
 * dispatch() function for the threshold source
 **/
static gboolean
z_threshold_source_dispatch(GSource     *s,
                            GSourceFunc  callback,
                            gpointer     user_data)
{
  ZThresholdSource *self = (ZThresholdSource *)s;
  gboolean rc = FALSE;

  z_enter();
  if (callback != NULL)
    {
      rc =  (*callback) (user_data);
      self->last_call = time(NULL);
    }
  else
    {
      /*LOG
        This message indicates an internal error. Please report this error
        to the QA team.
       */
      z_log(NULL, CORE_ERROR, 4, "Threshold callback function not set;");
    }
  z_return(rc);
}

static GSourceFuncs 
z_threshold_source_funcs = 
{
  z_threshold_source_prepare,
  z_threshold_source_check,
  z_threshold_source_dispatch,
  NULL,
  NULL,
  NULL
};

/**
 * z_threshold_source_new:
 * @idle_threshold:
 * @busy_threshold:
 * 
 *
 **/
GSource *
z_threshold_source_new(guint idle_threshold, guint busy_threshold)
{
  ZThresholdSource *self;
  
  self = (ZThresholdSource *) g_source_new(&z_threshold_source_funcs, sizeof(ZThresholdSource));
  self->idle_threshold = idle_threshold;
  self->busy_threshold = busy_threshold;
  return &self->super;
}

/**
 * z_threshold_source_set_threshold:
 * @source: the threshold source instance
 * @idle_threshold: new idle threshold
 * @busy_threshold: new busy threshold
 * 
 * This function changes the thresholds associated with the threshold source.
 **/
void
z_threshold_source_set_threshold(GSource *source, guint idle_threshold, guint busy_threshold)
{
  ZThresholdSource *self = (ZThresholdSource *) source;
  
  self->idle_threshold = idle_threshold;
  self->busy_threshold = busy_threshold;
}

typedef struct _ZTimeoutSource
{
  GSource super;
  GTimeVal timeout_target;
} ZTimeoutSource;

static gboolean
z_timeout_source_enabled(ZTimeoutSource *self)
{
  if (self->timeout_target.tv_sec > 0)
    return TRUE;
  else if (self->timeout_target.tv_sec < 0)
    return FALSE;
  else
    return self->timeout_target.tv_usec > 0;
}

/**
 * z_timeout_source_prepare:
 * @s: source object
 * @timeout: returns the calculated timeout here
 *
 * prepare() function for the timeout source
 **/
static gboolean
z_timeout_source_prepare(GSource *s, gint *timeout)
{
  ZTimeoutSource *self = (ZTimeoutSource *)s;
  GTimeVal now;
  
  if (!z_timeout_source_enabled(self))
    return FALSE;

  g_source_get_current_time(s, &now);
  if (g_time_val_compare(&self->timeout_target, &now) <= 0)
    return TRUE;
  else if (timeout)
    *timeout = g_time_val_diff(&self->timeout_target, &now) / 1000;
  
  return FALSE;
}

/**
 * z_timeout_source_check:
 * @s: source object
 *
 * check() function for the timeout source
 **/
static gboolean
z_timeout_source_check(GSource *s)
{
  ZTimeoutSource *self = (ZTimeoutSource *) s;
  GTimeVal now;
  
  if (!z_timeout_source_enabled(self))
    return FALSE;

  g_source_get_current_time(s, &now);
  return g_time_val_compare(&self->timeout_target, &now) <= 0;
}

/**
 * z_timeout_source_dispatch:
 * @s: source object (not used)
 * @callback: callback function associated with the source
 * @user_data: pointer to be passed to the callback function
 *
 * dispatch() function for the timeout source
 **/
static gboolean
z_timeout_source_dispatch(GSource     *s G_GNUC_UNUSED,
                          GSourceFunc  callback,
                          gpointer     user_data)
{
  return (*callback)(user_data);
}

static GSourceFuncs z_timeout_source_funcs = 
{
  z_timeout_source_prepare,
  z_timeout_source_check,
  z_timeout_source_dispatch,
  NULL,
  NULL,
  NULL
};

/**
 * z_timeout_source_set_timeout:
 * @source: a reference to the timeout source
 * @new_timeout: the new timeout value in milliseconds
 * 
 * This function changes the timeout associated to the timeout source
 * pointed to by @source.
 **/
void
z_timeout_source_set_timeout(GSource *source, gulong new_timeout)
{
  ZTimeoutSource *self = (ZTimeoutSource *) source;
  
  g_get_current_time(&self->timeout_target);
  self->timeout_target.tv_sec += new_timeout / 1000;
  g_time_val_add(&self->timeout_target, (new_timeout % 1000) * 1000);
}

/**
 * z_timeout_source_set_time:
 * @source: a reference to the timeout source
 * @new_timeout: the new timeout value in milliseconds
 * 
 * This function changes the timeout associated to the timeout source
 * pointed to by @source.
 **/
void
z_timeout_source_set_time(GSource *source, GTimeVal *nexttime)
{
  ZTimeoutSource *self = (ZTimeoutSource *) source;
  
  self->timeout_target.tv_sec = nexttime->tv_sec;
  self->timeout_target.tv_usec = nexttime->tv_usec;
}

/**
 * z_timeout_source_disable:
 * @source: a reference to the timeout source
 * 
 * This function disables the timeout source pointed to by @source.
 **/
void
z_timeout_source_disable(GSource *source)
{
  ZTimeoutSource *self = (ZTimeoutSource *) source;
  
  self->timeout_target.tv_sec = -1;
}

/**
 * z_timeout_source_new:
 * @initial_timeout: the initial timeout value in milliseconds
 *
 * This function creates and initializes a source which issues a callback
 * when a given timeout elapses. It does not matter how many times the
 * poll() loop runs as the time is saved as the target time instead of an
 * interval which would start each time the poll loop is run.
 **/
GSource *
z_timeout_source_new(gulong initial_timeout)
{
  ZTimeoutSource *self;
  
  self = (ZTimeoutSource *) g_source_new(&z_timeout_source_funcs, sizeof(ZTimeoutSource));
  z_timeout_source_set_timeout((GSource*)self, initial_timeout);
  return &self->super;
}

