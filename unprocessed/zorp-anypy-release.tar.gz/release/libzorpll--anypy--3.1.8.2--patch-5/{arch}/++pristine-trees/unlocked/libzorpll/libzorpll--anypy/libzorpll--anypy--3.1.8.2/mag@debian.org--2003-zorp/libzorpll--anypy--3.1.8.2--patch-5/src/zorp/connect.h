/***************************************************************************
 *
 * This file is covered by a dual licence. You can choose whether you
 * want to use it according to the terms of the GNU GPL version 2, or
 * under the terms of Zorp Professional Firewall System EULA located
 * on the Zorp installation CD.
 *
 * $Id: connect.h,v 1.15 2004/10/05 14:06:37 chaoron Exp $
 *
 ***************************************************************************/

#ifndef ZORP_CONNECT_H_INCLUDED
#define ZORP_CONNECT_H_INCLUDED


#include <zorp/zorplib.h>
#include <zorp/sockaddr.h>
#include <zorp/socket.h>
#include <zorp/zobject.h>
#include <zorp/stream.h>

#ifdef __cplusplus
extern "C" {
#endif

/* z_io_connect public interface */

typedef void (*ZConnectFunc)(ZStream *fdstream, GError *error, gpointer user_data);


/**
 * Connect to the given socket address using the given local address,
 * and call a given callback function if the connection is established.
 **/
typedef struct _ZConnector 
{
  ZObject super;
  ZSockAddr *local;
  gint fd;
  
  /* private */
  ZSockAddr *remote;
  
  /* we use a reference to our GSource, as using source_id would cause a race */
  GSource *watch;
  gint timeout;
  ZConnectFunc callback;
  gpointer user_data;
  GDestroyNotify destroy_notify;
  gint refcnt;
  GStaticRecMutex lock;
  GMainContext *context;
  gboolean blocking;
  gint tos;
  gint socket_type;
  guint32 sock_flags;
  gchar *session_id;
} ZConnector;

typedef struct _ZConnectorFuncs 
{
  ZObjectFuncs super;
} ZConnectorFuncs;

LIBZORPLL_EXTERN ZClass ZConnector__class;
LIBZORPLL_EXTERN ZClass ZStreamConnector__class;

ZConnector *
z_connector_new(ZClass *class,
                const gchar *session_id,
                gint socket_type,
                ZSockAddr *local, 
                ZSockAddr *remote,
                guint32 sock_flags,
                gint tos,
		ZConnectFunc callback,
		gpointer user_data);

ZSockAddr *z_connector_start_block(ZConnector *self);
ZSockAddr *z_connector_start(ZConnector *self);
ZSockAddr *z_connector_start_in_context(ZConnector *self, GMainContext *context);
void z_connector_set_timeout(ZConnector *self, gint timeout);
void z_connector_set_destroy_notify(ZConnector *self, GDestroyNotify notify);
void z_connector_cancel(ZConnector *self);
  
static inline ZConnector *
z_connector_ref(ZConnector *self)
{
  return Z_CAST(z_object_ref(&self->super), ZConnector);
}
  
static inline void 
z_connector_unref(ZConnector *self)
{
  z_object_unref(&self->super);
}
  
static inline const gchar *
z_connector_get_session_id(ZConnector *self)
{
  return self->session_id;
}

static inline ZConnector *
z_stream_connector_new(const gchar *session_id,
                       ZSockAddr *local, 
                       ZSockAddr *remote,
                       guint32 sock_flags,
                       gint tos,
                       ZConnectFunc callback,
	               gpointer user_data)
{
  return z_connector_new(Z_CLASS(ZStreamConnector), session_id, SOCK_STREAM, local, remote, sock_flags, tos, callback, user_data);
}

#ifdef __cplusplus
}
#endif
#endif
