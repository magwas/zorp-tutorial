/***************************************************************************
 *
 * This file is covered by a dual licence. You can choose whether you
 * want to use it according to the terms of the GNU GPL version 2, or
 * under the terms of Zorp Professional Firewall System EULA located
 * on the Zorp installation CD.
 *
 * $Id: zobject.h,v 1.6 2003/10/17 17:38:28 bazsi Exp $
 *
 ***************************************************************************/

#ifndef ZORP_ZOBJECT_H_INCLUDED
#define ZORP_ZOBJECT_H_INCLUDED

/* this might need to be moved to libzorpll */

#include <zorp/zorplib.h>
#include <zorp/misc.h>

#ifdef __cplusplus
extern "C" {
#endif


typedef struct _ZClass ZClass;
typedef struct _ZObject ZObject;

typedef struct _ZObjectFuncs
{
  gint method_count;
  void (*free_fn)(ZObject *self);
} ZObjectFuncs;

struct _ZObject
{
  ZRefCount ref_cnt;
  ZClass *isa;
};

struct _ZClass
{
  ZObject super;
  gboolean funcs_resolved; /* indicates whether function inheritance was already performed */
  struct _ZClass *super_class;
  gchar *name;
  gsize size;
  ZObjectFuncs *funcs; 
};

LIBZORPLL_EXTERN ZClass ZClass__class;

LIBZORPLL_EXTERN ZClass ZObject__class;

typedef ZClass ZInterface;

#define Z_OBJECT_HEADER   { Z_REFCOUNT_INIT, NULL }
#define Z_CLASS_HEADER    Z_OBJECT_HEADER, 0

#define Z_CLASS(class)       (&class##__class)

#define Z_CAST(inst, class) ((class *) z_object_check_compatible((ZObject *) inst, Z_CLASS(class)))

#define Z_FUNCS(inst, class) ((class##Funcs *) (z_object_check_compatible((ZObject *) inst, Z_CLASS(class))->isa->funcs))
#define Z_SUPER(inst, class) ((class##Funcs *) (z_object_check_compatible((ZObject *) inst, Z_CLASS(class))->isa->super_class->funcs))
#define Z_FUNCS_COUNT(class) ((sizeof(class##Funcs)-sizeof(gint))/sizeof(void (*)(void)))
#define Z_NEW(class)         (class *) z_object_new(Z_CLASS(class))
#define Z_NEW_COMPAT(class, compat) (compat *) z_object_new_compatible(class, Z_CLASS(compat))

ZObject *z_object_new(ZClass *class);
ZObject *z_object_new_compatible(ZClass *class, ZClass *compat);
gboolean z_object_is_compatible(ZObject *self, ZClass *class);
gboolean z_object_is_subclass(ZClass *class, ZClass *subclass);
gboolean z_object_is_instance(ZObject *self, ZClass *class);

#if ZORPLIB_ENABLE_DEBUG

static inline ZObject *
z_object_check_compatible(ZObject *self, ZClass *class G_GNUC_UNUSED)
{
  g_assert(!self || z_object_is_compatible(self, class));
  return self;
}

#else

static inline ZObject *
z_object_check_compatible(ZObject *self, ZClass *class G_GNUC_UNUSED)
{
  return self;
}

#endif

/* function declaration for virtual functions */

void z_object_free_method(ZObject *s);

/**
 * z_object_ref:
 * @self: ZObject instance
 *
 * Increment the reference count of @self.
 **/
static inline ZObject *
z_object_ref(ZObject *self)
{
  if (self)
    z_refcount_inc(&self->ref_cnt);
  return self;
}

/**
 * z_object_unref:
 * @self: ZObject instance
 *
 * Decrement the reference count of @self and free it if the reference count
 * goes down to zero.
 **/
static inline void
z_object_unref(ZObject *self)
{
  if (self && z_refcount_dec(&self->ref_cnt))
    {
      Z_FUNCS(self, ZObject)->free_fn(self);
      g_free(self);
    }
}

#ifdef __cplusplus
}
#endif

#endif
