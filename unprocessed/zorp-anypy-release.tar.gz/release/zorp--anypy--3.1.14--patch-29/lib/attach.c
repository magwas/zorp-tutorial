/***************************************************************************
 *
 * Copyright (c) 2000, 2001, 2002, 2003, 2004, 2005, 2006 BalaBit IT Ltd, Budapest, Hungary
 *
 * This program is free software; you can redistribute it and/or modify it
 * under the terms of the GNU General Public License version 2 as published
 * by the Free Software Foundation.
 *
 * Note that this permission is granted for only version 2 of the GPL.
 *
 * As an additional exemption you are allowed to compile & link against the
 * OpenSSL libraries as published by the OpenSSL project. See the file
 * COPYING for details.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
 *
 * $Id: attach.c,v 1.29 2004/01/26 16:55:34 bazsi Exp $
 *
 * Author  : Bazsi
 * Auditor :
 * Last audited version:
 * Notes:
 *
 ***************************************************************************/

#include <zorp/attach.h>
#include <zorp/connect.h>
#include <zorp/dgram.h>
#include <zorp/log.h>
#include <zorp/streamfd.h>

#include <string.h>

/*
 * Attach - establish outgoing connection
 * 
 */

struct _ZAttach
{
  GStaticRecMutex lock; /* lock protecting ref_cnt */
  gint ref_cnt;
  gchar session_id[MAX_SESSION_ID];
  guint proto;
  ZSockAddr *bind_addr;
  ZSockAddr *local;
  ZSockAddr *remote;
  ZAttachParams params;
  ZAttachCallback callback;
  gpointer user_data;
  GDestroyNotify user_data_notify;
  
  GMutex *connected_lock;
  GCond *connected_cond;
  ZConnection *conn;
  
  ZConnector *connector;
};

#define not_connected_yet_mark ((ZConnection *) &z_attach_new)


/**
 * z_attach_free:
 * @self this
 *
 * Destructor, destroyes the connection, decrements the ref counters of sub-objects
 * 
 */
static void
z_attach_free(ZAttach *self)
{
  z_session_enter(self->session_id);
  if (self->conn && self->conn != not_connected_yet_mark)
    z_connection_destroy(self->conn, FALSE);
  z_sockaddr_unref(self->bind_addr);
  z_sockaddr_unref(self->local);
  z_sockaddr_unref(self->remote);
  if (self->connector)
    z_connector_unref(self->connector);
  if (self->connected_lock)
    {
      g_mutex_free(self->connected_lock);
      g_cond_free(self->connected_cond);
    }
  g_free(self);
  z_return();
}


/**
 * z_attach_ref:
 * @self this
 *
 * Increments the reference counter of the instance
 *
 * Returns:
 * The instance
 */
ZAttach *
z_attach_ref(ZAttach *self)
{
  g_static_rec_mutex_lock(&self->lock);
  g_assert(self->ref_cnt);
  self->ref_cnt++;
  g_static_rec_mutex_unlock(&self->lock);
  return self;
}


/**
 * z_attach_unref:
 * @self this
 *
 * Decrements the reference counter of the instance
 *
 * Returns:
 * The instance
 */
void
z_attach_unref(ZAttach *self)
{
  g_static_rec_mutex_lock(&self->lock);
  g_assert(self->ref_cnt);
  if (--self->ref_cnt == 0)
    {
      g_static_rec_mutex_unlock(&self->lock);
      z_attach_free(self);
    }
  else
    g_static_rec_mutex_unlock(&self->lock);
}


/**
 * z_attach_callback:
 * @self this
 * @conn The connection to add
 *
 * Internal callback function, called when a connection is established.
 * Called from: z_attach_tcp_callback (tcp) or z_attach_start (udp).
 */
static void
z_attach_callback(ZStream *fdstream, GError *err G_GNUC_UNUSED, gpointer user_data)
{
  ZAttach *self = (ZAttach *) user_data;
  gchar buf[256];
  ZConnection *conn;
  
  z_session_enter(self->session_id);

  if (fdstream != NULL)
    {
      gint fd =  z_stream_get_fd(fdstream);
      
      conn = z_connection_new();
      if (z_getsockname(fd, &conn->local, 0) != G_IO_STATUS_NORMAL ||
          z_getpeername(fd, &conn->remote, 0) != G_IO_STATUS_NORMAL)   
        {
          z_connection_destroy(conn, FALSE);
          z_stream_close(fdstream, NULL);
          z_stream_unref(fdstream);
          z_session_leave(self->session_id);
          return;   
        }
      conn->protocol = self->proto;
      conn->stream = fdstream;
      conn->dest = z_sockaddr_ref(conn->remote);
    }
  else
    {
      conn = NULL;
    }
  
  /*LOG
    This message reports that the connection was successfully established.
  */
  z_log(NULL, CORE_DEBUG, 6, "Established connection; %s", z_connection_format(conn, buf, sizeof(buf)));
  if (self->callback)
    {
      self->callback(conn, self->user_data);
      if (self->user_data && self->user_data_notify)
        {
          self->user_data_notify(self->user_data);
        }
      self->user_data = NULL;
    }
  else
    {
      g_mutex_lock(self->connected_lock);
      self->conn = conn;
      g_cond_signal(self->connected_cond);
      g_mutex_unlock(self->connected_lock);
    }
  z_session_leave(self->session_id);
}

/**
 * z_attach_start_in_context:
 * @self: this
 * @context: GMainContext to use for polling
 *
 * Initiate establishing a connection using @context
 *
 * Returns:
 * TRUE on success
 */
gboolean
z_attach_start_in_context(ZAttach *self, GMainContext *context)
{
  gboolean res = FALSE;
  
  z_session_enter(self->session_id);
  if (self->proto == ZD_PROTO_TCP)
    {
      self->connector = z_stream_connector_new(self->session_id, self->bind_addr, self->remote, (self->params.tcp.loose ? ZSF_LOOSE_BIND : 0) | ZSF_MARK_TPROXY, self->params.tcp.tos, z_attach_callback, self);
    }
  else  if (self->proto == ZD_PROTO_UDP)
    {
      self->connector = z_dgram_connector_new(self->session_id, self->bind_addr, self->remote, (self->params.udp.loose ? ZSF_LOOSE_BIND : 0) | ZSF_MARK_TPROXY, self->params.udp.tos, z_attach_callback, self);
    }
    
  if (self->connector)
    {
      z_connector_set_timeout(self->connector, self->params.tcp.timeout < 0 ? -1 : (self->params.tcp.timeout + 999) / 1000);
      z_attach_ref(self);
      z_connector_set_destroy_notify(self->connector, (GDestroyNotify) z_attach_unref);
      if (self->callback)
        {
          self->local = z_connector_start_in_context(self->connector, context);
        }
      else
        {
          self->local = z_connector_start_block(self->connector);
        }
      if (!self->local)
        {
          z_connector_unref(self->connector);
          self->connector = NULL;
        }
      else
        {
          res = TRUE;
        }
    }
  z_session_leave(self->session_id);
  return res;
}

/**
 * z_attach_start:
 * @self: this
 *
 * Initiate establishing a connection
 *
 * Returns:
 * TRUE on success
 */
gboolean
z_attach_start(ZAttach *self)
{
  gboolean res;

  z_session_enter(self->session_id);
  res = z_attach_start_in_context(self, NULL);
  z_session_leave(self->session_id);
  return res;
}

/**
 * z_attach_block:
 * @self this
 *
 * Wait until the connection is established
 *
 * Returns:
 * The established connection
 */
ZConnection *
z_attach_block(ZAttach *self)
{
  ZConnection *conn;
  
  z_session_enter(self->session_id);
  z_attach_ref(self);
  
  g_mutex_lock(self->connected_lock);
  while (self->conn == not_connected_yet_mark)
    g_cond_wait(self->connected_cond, self->connected_lock);
  conn = self->conn;
  self->conn = NULL;
  g_mutex_unlock(self->connected_lock);
  
  z_attach_unref(self);
  z_session_leave(self->session_id);
  return conn;
}


/**
 * z_attach_cancel:
 * @self this
 *
 * Cancel a connection, and call the notification callback if the connection
 * wasn't established (and so the callback wasn't called yet).
 */
void
z_attach_cancel(ZAttach *self)
{
  z_session_enter(self->session_id);
  if (self->connector)
    z_connector_cancel(self->connector);
    
  /* either our callback was called in which case user_data is already
   * NULLed or we _have_ to call user_data_notify here. */
  
  if (self->user_data && self->user_data_notify)
    {
      self->user_data_notify(self->user_data);
     }
  self->user_data = NULL;
  z_session_leave(self->session_id);
}


/**
 * z_attach_get_local:
 * @self this
 *
 * Get the address of the connection's local endpoint.
 *
 * Returns:
 * The address of the local endpoint
 */
ZSockAddr *
z_attach_get_local(ZAttach *self)
{
  return z_sockaddr_ref(self->local);
}


/**
 * z_attach_new:
 * @session_id The ID of the session
 * @bind_addr The address to bind to
 * @remote The address to connect to
 * @params The optional parameters for the connection
 * @callback Callback function to call when the connection is established
 * @notify Callback to call when the structure is destroyed
 *
 * Allocates and sets up a new instance of ZAttach.
 * (For the connection parameters see ZAttachTCPParams and ZAttachUDPParams.)
 *
 * Returns:
 * The new instance
 */
ZAttach *
z_attach_new(gchar *session_id, 
             guint proto, ZSockAddr *bind_addr, ZSockAddr *remote, 
             ZAttachParams *params,
             ZAttachCallback callback, gpointer user_data, GDestroyNotify notify)
{
  ZAttach *self = g_new0(ZAttach, 1);
  
  z_session_enter(session_id);
  g_strlcpy(self->session_id, session_id, sizeof(self->session_id));
  self->proto = proto;
  self->bind_addr = z_sockaddr_ref(bind_addr);
  self->remote = z_sockaddr_ref(remote);
  self->callback = callback;
  self->user_data = user_data;
  self->user_data_notify = notify;
  self->ref_cnt = 1;
  memcpy(&self->params, params, sizeof(self->params));
  if (!callback)
    {
      self->connected_lock = g_mutex_new();
      self->connected_cond = g_cond_new();
    }
  self->conn = not_connected_yet_mark;
  z_session_leave(session_id);
  return self;
}
