/***************************************************************************
 *
 * Copyright (c) 2000, 2001, 2002, 2003, 2004, 2005, 2006 BalaBit IT Ltd, Budapest, Hungary
 *
 * This program is free software; you can redistribute it and/or modify it
 * under the terms of the GNU General Public License version 2 as published
 * by the Free Software Foundation.
 *
 * Note that this permission is granted for only version 2 of the GPL.
 *
 * As an additional exemption you are allowed to compile & link against the
 * OpenSSL libraries as published by the OpenSSL project. See the file
 * COPYING for details.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
 *
 * $Id: pyattach.c,v 1.14 2004/07/02 10:03:33 bazsi Exp $
 *
 * Author  : Bazsi
 * Auditor :
 * Last audited version:
 * Notes:
 *
 ***************************************************************************/

#include <zorp/pyattach.h>
#include <zorp/attach.h>
#include <zorp/log.h>
#include <zorp/policy.h>
#include <zorp/pysockaddr.h>
#include <zorp/socket.h>
#include <zorp/stream.h>
#include <zorp/streamfd.h>
#include <zorp/pystream.h>

/*
 * struct ZorpAttach
 *
 * Author:  Bazsi, 2000/03/27
 * Purpose: this class encapsulates a connector
 *
 */

typedef struct _ZorpAttach
{
  PyObject_HEAD
  ZPolicy *policy;
  ZAttach *attach;
  ZSockAddr *local;
  PyObject *handler;
} ZorpAttach;

static PyObject *z_py_zorp_attach_new_instance(PyObject *s, PyObject *args);
static void z_py_zorp_attach_free(ZorpAttach *self);
static PyObject *z_py_zorp_attach_getattr(PyObject *o, char *name);

static PyObject *z_py_zorp_attach_start_method(ZorpAttach *self, PyObject *args);
static PyObject *z_py_zorp_attach_block_method(ZorpAttach *self, PyObject *args);
static PyObject *z_py_zorp_attach_cancel_method(ZorpAttach *self, PyObject *args);


PyMethodDef z_py_zorp_attach_funcs[] =
{
  { "Attach",  z_py_zorp_attach_new_instance, METH_VARARGS, NULL },
  { NULL,      NULL, 0, NULL }   /* sentinel*/
};

static PyMethodDef py_zorp_attach_methods[] =
{
  { "start",       (PyCFunction) z_py_zorp_attach_start_method, 0, NULL },
  { "block",       (PyCFunction) z_py_zorp_attach_block_method, 0, NULL },
  { "cancel",      (PyCFunction) z_py_zorp_attach_cancel_method, 0, NULL },
  { NULL,          NULL, 0, NULL }   /* sentinel*/
};

PyTypeObject z_py_zorp_attach_type = 
{
  PyObject_HEAD_INIT(&PyType_Type)
  0,
  "ZorpAttach",
  sizeof(ZorpAttach),
  0,
  (destructor) z_py_zorp_attach_free,
  0,
  (getattrfunc) z_py_zorp_attach_getattr,
  0,
  0,
  0, /*(reprfunc) z_py_zorp_attach_repr,*/
  0,
  0,
  0,
  0,
  0,
  0,
  0,
  0,
  0,
  0,
  "ZorpAttach class for Zorp",
  0, 0, 0, 0,
  Z_PYTYPE_TRAILER
};

/* called by the low level connector, under the main thread */
static void
z_py_zorp_attach_connected(ZConnection *conn, gpointer user_data)
{
  ZorpAttach *self = (ZorpAttach *) user_data;
  PyObject *res, *sobj;

  z_enter();
  if (!self->handler)
    {
      /* we have already been cancelled */
      z_connection_destroy(conn, TRUE);
      z_return();
    }
  z_policy_acquire_main(self->policy);
  if (self->handler)
    {
      if (conn)
        sobj = z_policy_stream_new(conn->stream);
      else 
        {
          Py_XINCREF(Py_None);
          sobj = Py_None;
        }
      res = PyEval_CallFunction(self->handler, "(O)", sobj);
      if (!res)
        {
	  PyErr_Print();
	  z_stream_close(conn->stream, NULL);
        }
      Py_XDECREF(sobj);
    }
  else
    {
      z_stream_close(conn->stream, NULL);
    }
  z_policy_release_main(self->policy);
  z_connection_destroy(conn, FALSE);
  z_return();
}

static void
z_py_zorp_attach_unref(PyObject *attach)
{
  ZPolicy *policy;
  
  policy = z_policy_ref(((ZorpAttach *) attach)->policy);
  z_policy_acquire_main(policy);
  Py_XDECREF(attach);
  z_policy_release_main(policy);
  z_policy_unref(policy);
}


/**
 * z_py_zorp_attach_start_method:
 * @self this
 * @args not used
 *
 * Zorp.Attach.start, starts establishing the connection. (Wrapper around
 * z_attach_start.)
 * 
 * Returns:
 * NULL on error, PyNone else
 */
static PyObject *
z_py_zorp_attach_start_method(ZorpAttach *self, PyObject *args G_GNUC_UNUSED)
{
  gboolean res;

  z_enter();
  if (self->attach)
    {
      Py_BEGIN_ALLOW_THREADS;
      res = z_attach_start(self->attach);
      Py_END_ALLOW_THREADS;
      if (res)
        {
          self->local = z_attach_get_local(self->attach);
        }
      else
        {
          PyErr_SetString(PyExc_IOError, "Error in z_attach_start");
          z_return(NULL);
        }
    }
  Py_XINCREF(Py_None);
  z_return(Py_None);
}


/**
 * z_py_zorp_attach_block_method:
 * @self this
 * @args not used
 *
 * Zorp.Attach.block, block execution until the connection gets established.
 * (Wrapper around z_attach_block.) Note that if there is a callback installed
 * (@handler of the constructor), then this method will fail.
 *
 * Returns:
 * NULL when there was a callback installed
 * PyNone if an error happened during connecting
 * The new data stream (Zorp.Stream) otherwise
 */
static PyObject *
z_py_zorp_attach_block_method(ZorpAttach *self, PyObject *args G_GNUC_UNUSED)
{
  z_enter();
  if (self->handler == Py_None)
    {
      PyObject *res;
      ZConnection *conn;
      
      Py_BEGIN_ALLOW_THREADS
      conn = z_attach_block(self->attach);
      Py_END_ALLOW_THREADS
      
      if (conn != NULL)
        {
          /* Note: we don't assign a name to this stream now, it will be assigned later */
          res = z_policy_stream_new(conn->stream);
          z_connection_destroy(conn, FALSE);
        }
      else
        {
          Py_XINCREF(Py_None);
          res = Py_None;
        }
      z_return(res);
    }
  PyErr_SetString(PyExc_ValueError, "ZorpAttach.block called with handler != None");
  z_return(NULL);
}


/**
 * z_py_zorp_attach_cancel_method:
 * 
 * Cancels an ongoing connecting attempt.
 * Called from Python to destroy this instance
 *
 * Returns: Py_None
 */
static PyObject *
z_py_zorp_attach_cancel_method(ZorpAttach *self, PyObject *args G_GNUC_UNUSED)
{
  PyObject *handler;
  
  z_enter();
  /* this would race with _connected, but we are protected by the interpreter lock */
  z_attach_cancel(self->attach);
  /* handler being null indicates we have been cancelled */  
  /* NOTE: self->handler is protected by the interpreter lock */
  handler = self->handler;
  self->handler = NULL;
  Py_XDECREF(handler); 
  Py_XINCREF(Py_None);
  z_return(Py_None);
}

/**
 * z_py_zorp_attach_free:
 * @self: this
 *
 * Destructor for Zorp.Attach, called automatically to free up this instance
 */
static void
z_py_zorp_attach_free(ZorpAttach *self)
{
  z_enter();
  if (self->handler)
    {
      Py_XDECREF(self->handler);
    }
  if (self->attach)
    z_attach_unref(self->attach);
  if (self->policy)
    z_policy_unref(self->policy);
  z_sockaddr_unref(self->local);
  PyObject_Del(self);
  z_return();
}

/**
 * z_py_zorp_attach_getattr:
 * @o: this 
 * @name: Attribute name
 *
 * Get the value of an attribute
 * Currently only the methods and one attribute is supported: 'local', the
 * address of the local endpoint.
 *
 * Returns:
 * The attribute value as a Python object
 */
static PyObject *
z_py_zorp_attach_getattr(PyObject *o, char *name)
{
  ZorpAttach *self = (ZorpAttach *) o;
  PyObject * back;
  
  z_enter();
  if (strcmp(name, "local") == 0)
    {
      if (self->local)
        {
          back = z_policy_sockaddr_new(self->local);
          z_return(back);
        }
      Py_XINCREF(Py_None);
      z_return(Py_None);
    }
  back = Py_FindMethod(py_zorp_attach_methods, o, name);
  z_return(back);
}


/** 
 * z_py_zorp_attach_new_instance:
 * @s not used
 * @args Python args: session_id, protocol, local, remote, handler, keywords
 *
 * Constructor of Zorp.Attach. After creating and setting up a new instance,
 * creates self->attach (ZAttach), passing the arguments to its constructor
 * z_attach_new. The argument @handler will be called when the connection
 * got established.
 *
 * Returns:
 * The new instance
 */
static PyObject *
z_py_zorp_attach_new_instance(PyObject *s G_GNUC_UNUSED, PyObject *args)
{
  ZorpAttach *self;
  PyObject *local, *remote;
  PyObject *handler, *keywords, *fake_args;
  ZAttachParams params;
  static gchar *tcp_keywords[] = { "timeout", "local_loose", "tos", NULL };
  /* In UDP mode timeout not used, but python complain if found an unknown
   * Keyword Argument. */
  static gchar *udp_keywords[] = { "timeout", "local_loose", "tos", NULL };
  gchar buf1[MAX_SOCKADDR_STRING], buf2[MAX_SOCKADDR_STRING], *session_id;
  ZSockAddr *local_sa, *remote_sa;
  guint protocol;
  /* Unused timeout parameter will be put here in UDP mode. */
  guint fake_timeout;

  z_enter();
  /* called by python, no need to lock the interpreter */
  if (!PyArg_ParseTuple(args, "siOOO|O", &session_id, &protocol, &local, &remote, &handler, &keywords))
    z_return(NULL);

  if (handler != Py_None && !PyCallable_Check(handler))
    {
      PyErr_SetString(PyExc_TypeError, "Handler parameter must be callable");
      z_return(NULL);
    }
  if (((local != Py_None) && !z_policy_sockaddr_check(local)) ||
      (!z_policy_sockaddr_check(remote)))
    {
      PyErr_SetString(PyExc_TypeError, "Local and remote arguments must be SockAddr or None");
      z_return(NULL);
    }

  memset(&params, 0, sizeof(params));
  fake_args = PyTuple_New(0);
  switch (protocol)
    {
    case ZD_PROTO_TCP:
      params.tcp.timeout = 30000;
      params.tcp.tos = -1;
      if (!PyArg_ParseTupleAndKeywords(fake_args, keywords, "|iii", tcp_keywords, &params.tcp.timeout, &params.tcp.loose, &params.tcp.tos))
        {
          Py_XDECREF(fake_args);
          z_return(NULL);
        }
      break;
      
    case ZD_PROTO_UDP:
      params.udp.tos = -1;
      if (!PyArg_ParseTupleAndKeywords(fake_args, keywords, "|iii", udp_keywords, &fake_timeout, &params.udp.loose, &params.udp.tos))
        {
          Py_XDECREF(fake_args);
          z_return(NULL);
        }
      break;
    }
  Py_XDECREF(fake_args);
  self = PyObject_New(ZorpAttach, &z_py_zorp_attach_type);
  if (!self)
    z_return(NULL);
  
  local_sa = local == Py_None ? NULL : z_policy_sockaddr_get_sa(local);
  remote_sa = z_policy_sockaddr_get_sa(remote);

  /*LOG
    This message indicates that Zorp began establishing connection
    with the indicated remote host.
   */
  z_log(NULL, CORE_DEBUG, 7, "Connecting to remote host; protocol='%d', local='%s', remote='%s'", 
        protocol,
	local_sa ? z_sockaddr_format(local_sa, buf1, sizeof(buf1)) : "NULL",
	z_sockaddr_format(remote_sa, buf2, sizeof(buf2)));
  
  /* NOTE: this pointer is used as a mark to indicate that connection has
   * not succeeded yet. Every reference to self->conn _MUST_ check this
   * value prior to using the value in _ANY_ way
   */
  self->local = NULL;
  self->policy = NULL;
  self->handler = NULL;
  /* z_attach_new stores a reference to self, which is freed by z_py_zorp_attach_unref */
  if (handler != Py_None)
    {
      self->attach = z_attach_new(session_id, protocol, local_sa, remote_sa,
                                  &params,
                                  z_py_zorp_attach_connected, 
                                  self, (GDestroyNotify) z_py_zorp_attach_unref);
      Py_XINCREF((PyObject *) self); /* returned reference */
    }
  else
    {
      self->attach = z_attach_new(session_id, protocol, local_sa, remote_sa,
                                  &params,
                                  NULL, NULL, NULL); 
    }

  z_sockaddr_unref(remote_sa);
  z_sockaddr_unref(local_sa);
  if (!self->attach)
    {
      PyErr_SetString(PyExc_IOError, "Error during connect");
      
      Py_XDECREF(self);
      if (handler != Py_None)
        {
          Py_XDECREF(self);
        }
      z_return(NULL);
    }
  Py_XINCREF(handler);
  self->handler = handler;
  self->policy = z_policy_ref(current_policy);
  z_return((PyObject *) self);
}

/**
 * z_py_zorp_attach_init:
 *
 * Module initialisation
 */
void
z_py_zorp_attach_init(void)
{
  /* PyImport_AddModule("Zorp.Zorp"); */
  Py_InitModule("Zorp.Zorp", z_py_zorp_attach_funcs);
}
