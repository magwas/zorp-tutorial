#ifndef ZORP_COREDUMP_H_INCLUDED
#define ZORP_COREDUMP_H_INCLUDED

int z_coredump_create(void);

#endif /* ZORP_COREDUMP_H_INCLUDED */
