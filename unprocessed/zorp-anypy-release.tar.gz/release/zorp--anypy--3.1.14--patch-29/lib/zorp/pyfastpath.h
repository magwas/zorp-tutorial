#ifndef ZORP_PYFASTPATH_H_INCLUDED
#define ZORP_PYFASTPATH_H_INCLUDED

void z_py_zorp_fastpath_init(void);

#endif
