/***************************************************************************
 *
 * Copyright (c) 2000, 2001, 2002, 2003, 2004, 2005, 2006 BalaBit IT Ltd, Budapest, Hungary
 *
 * This program is free software; you can redistribute it and/or modify it
 * under the terms of the GNU General Public License version 2 as published
 * by the Free Software Foundation.
 *
 * Note that this permission is granted for only version 2 of the GPL.
 *
 * As an additional exemption you are allowed to compile & link against the
 * OpenSSL libraries as published by the OpenSSL project. See the file
 * COPYING for details.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
 *
 * $Id: anypy.c,v 1.28 2003/10/13 09:40:54 bazsi Exp $
 *
 * Author: Bazsi
 * Auditor: Bazsi
 * Last audited version: 1.14
 * Notes:
 *
 ***************************************************************************/
 
#include <zorp/zorp.h>
#include <zorp/proxy.h>
#include <zorp/thread.h>
#include <zorp/policy.h>
#include <zorp/zpython.h>
#include <zorp/pystream.h>
#include <zorp/registry.h>
#include <zorp/log.h>
#include <zorp/streamline.h>
#include <zorp/poll.h>

#define ANYPY_ERROR "anypy.error"
#define ANYPY_DEBUG "anypy.debug"

typedef struct _AnyPyProxy
{
  ZProxy super;
  guint max_line_length[EP_MAX];
  ZPoll *poll;
  gboolean quit;
  gboolean linebased;
} AnyPyProxy;

extern ZClass AnyPyProxy__class;


/**
 * anypy_stream_init:
 * @self: AnyPyProxy instance
 * 
 * This function is called upon startup to initialize our streams.
 **/

static gboolean
anypy_stream_init(AnyPyProxy *self)
{

  z_proxy_enter(self);
  if (!self->super.endpoints[EP_CLIENT] || !self->super.endpoints[EP_SERVER])
    {
      z_proxy_log(self, ANYPY_ERROR, 2, "Server side not yet connected, unable to init streams;");
      z_proxy_return(self,FALSE);
    }
  z_proxy_log(self, ANYPY_DEBUG, 2, "linebased= %u;",self->linebased);
  if (self->linebased)
   {
      z_proxy_log(self, ANYPY_ERROR, 2, "stacking in streamline;");
	  self->super.endpoints[EP_CLIENT] = z_stream_push(self->super.endpoints[EP_CLIENT], z_stream_line_new(NULL, self->max_line_length[EP_CLIENT], ZRL_EOL_CRLF|ZRL_EOL_FATAL|ZRL_RETURN_EOL));
	  self->super.endpoints[EP_SERVER] = z_stream_push(self->super.endpoints[EP_SERVER], z_stream_line_new(NULL, self->max_line_length[EP_SERVER], ZRL_EOL_CRLF|ZRL_EOL_FATAL|ZRL_RETURN_EOL));
   }

  z_proxy_return(self,TRUE);
}

/*
 * a structure to use with the callback
 */
typedef struct _ZPolicyStreamCBData {
       PyObject *callback;
       AnyPyProxy *self;
       ZPolicyStream *stream;
       PyObject *obj;
} ZPolicyStreamCBData;

/*
 * anypy_callback
 * @stream: the stream
 * @cond: the I/O condition (unused)
 * @user_data: user data
 *
 * this is the C callback set in anypy_register_callback
 * it will call the python callback function
 */
static gboolean
anypy_callback(ZStream *stream, GIOCondition  cond G_GNUC_UNUSED, gpointer  user_data)
{
  ZPolicyObj *res;
  guint resno;
  ZPolicyStreamCBData *cbdata = (ZPolicyStreamCBData *) user_data;

  z_proxy_log(cbdata->self, ANYPY_DEBUG, 2, "anypy_callback, %s;",cbdata->self->super.session_id);
  {
  ZPolicyObj *callback;
  ZPolicyObj *args;
  callback=cbdata->callback;
  z_proxy_log(cbdata->self, ANYPY_DEBUG, 2, "callback=%p;",callback);
  args = z_policy_var_build("(OO)",cbdata->stream,cbdata->obj);
  z_proxy_log(cbdata->self, ANYPY_DEBUG, 2, "args=%p;",args);
  z_policy_lock(cbdata->self->super.thread);  
  res=z_policy_call_object(callback,args,"ooo");
  z_policy_unlock(cbdata->self->super.thread);  
//       cbdata->callback,
//       z_policy_var_build("(OO)",cbdata->stream,cbdata->obj),"oooo");
//       cbdata->self->super.session_id);
  }
 z_proxy_log(cbdata->self, ANYPY_DEBUG, 2, "res=%p;",res);
 if (NULL == res)
 {
   cbdata->self->quit=1;
   z_proxy_log(cbdata->self, ANYPY_ERROR, 2, "error calling callback;");
   return FALSE;
 }
 else if (!z_policy_var_parse(res,"i",&resno))
 {
   cbdata->self->quit=1;
   z_proxy_log(cbdata->self, ANYPY_ERROR, 2, "callback returned invalid value;");
   return FALSE;
 }
 else
 {
   cbdata->self->quit=resno;
 }
 return !cbdata->self->quit;
}

/**
 * anypy_cbdata_unref:
 * @cbdata: ZPolicyStreamCBData instance
 *
 * This function frees cbdata and decrements the reference counts.
 **/
static void
anypy_cbdata_unref(ZPolicyStreamCBData *cbdata)
{
  z_proxy_log(cbdata->self, ANYPY_ERROR, 2, "cbdata_unref");
  Py_XDECREF(cbdata->callback);
  Py_XDECREF(cbdata->obj);
  Py_XDECREF((ZPolicyObj *)cbdata->self);
  g_free(cbdata);
}

/**
 * anypy_register_callback:
 * @self: AnyPyProxy instance
 * @args: Python args argument
 * 
 * registers callback for a stream
 * args is (flags,callback,stream,obj)
 **/

static ZPolicyObj *
anypy_register_callback(AnyPyProxy *self, ZPolicyObj *args)
{
  int flags;
  ZPolicyStream *stream;

  z_proxy_enter(self);
  //FIXME register all needed callbacks for a stream once
  ZPolicyStreamCBData *cbdata = g_new0(ZPolicyStreamCBData,1);
  if (!z_policy_var_parse_tuple(args, "iOOO", &flags, &(cbdata->callback), &stream, &(cbdata->obj)))
    {
      PyErr_SetString(PyExc_AttributeError, "Arguments should be (flags,callback,stream,obj)");
      z_proxy_return(self,NULL);
    }
  cbdata->self=self;
  cbdata->stream=stream;//FIXME: we can get rid of it

  Py_XINCREF(cbdata->callback);
  Py_XINCREF(cbdata->obj);
  //Py_XINCREF(cbdata->stream);
  Py_XINCREF((ZPolicyObj *)cbdata->self);

  Py_BEGIN_ALLOW_THREADS
  z_stream_set_nonblock(stream->stream, TRUE);
  z_stream_set_callback(stream->stream,flags,anypy_callback,(GDestroyNotify) cbdata,(GDestroyNotify) anypy_cbdata_unref);
  z_stream_set_cond(stream->stream, flags, TRUE);
  stream->stream->timeout = -2;
  z_proxy_log(self, ANYPY_DEBUG, 2, "adding stream %p to poll %p, flags=%u;",stream->stream,self->poll,flags);
  z_poll_add_stream(self->poll, stream->stream);
  Py_END_ALLOW_THREADS

  Py_XINCREF(Py_None);
  z_proxy_return(self,Py_None);
}

/**
 * anypy_add_to_poll:
 * @self: AnyPyProxy instance
 * @args: Python args argument
 * 
 * add a stream to the poll
 * args is (stream,flags)
 **/

static ZPolicyObj *
anypy_add_to_poll(AnyPyProxy *self, ZPolicyObj *args)
{
  ZPolicyStream *stream;
  int flags;

  z_proxy_enter(self);
  if (!z_policy_var_parse_tuple(args, "Oi", &stream,&flags))
    {
      PyErr_SetString(PyExc_AttributeError, "Arguments should be (stream)");
      z_proxy_return(self,NULL);
    }
  Py_XINCREF(stream);
  Py_BEGIN_ALLOW_THREADS
  z_proxy_log(self, ANYPY_DEBUG, 2, "adding stream %p to poll %p;",stream->stream,self->poll);
  z_stream_set_cond(stream->stream, flags, TRUE);
  z_poll_add_stream(self->poll, stream->stream);
  Py_END_ALLOW_THREADS

  Py_XINCREF(Py_None);
  z_proxy_return(self,Py_None);
}

/**
 * anypy_poll_iter_timeout:
 * @self: AnyPyProxy instance
 * @args: Python args argument
 * 
 * does a poll_iter_timeout
 * args is (timeout)
 **/
static ZPolicyObj *
anypy_poll_iter_timeout(AnyPyProxy * self, ZPolicyObj *args) 
{
  guint timeout;
  guint res;

  z_proxy_enter(self);

  if ( self->quit )
  {
   goto err;
  }
  if (!z_policy_var_parse_tuple(args, "i", &timeout))
    {
      z_policy_raise_exception_obj(z_policy_exc_value_error, "Invalid arguments.");
      z_proxy_return(self,NULL);
    }
  z_proxy_log(self, ANYPY_DEBUG, 2, "calling z_poll_iter_timeout;");
  Py_BEGIN_ALLOW_THREADS
  res=z_poll_iter_timeout(self->poll,timeout);
  Py_END_ALLOW_THREADS
  if(res)
    {
      ZPolicyObj *ret;
      z_proxy_log(self, ANYPY_DEBUG, 2, "z_poll_iter_timeout returned true;");
      ret=z_policy_var_build("i",1);
      z_proxy_return(self,ret);
    }
err:
  z_proxy_log(self, ANYPY_DEBUG, 2, "z_poll_iter_timeout returned false;");
  Py_XINCREF(Py_None);
  z_proxy_return(self,Py_None);
}

/**
 * anypy_set_verdict:
 * @self: AnyPyProxy instance
 * @args: Python args argument
 * 
 * sets verdict for the parent proxy
 * args is (verdict,description)
 **/
static ZPolicyObj *
anypy_set_verdict(AnyPyProxy * self, ZPolicyObj *args) 
{
  gint verdict;
  gchar *description;
  ZPolicyObj *res = NULL;

  z_proxy_enter(self);

  if (!z_policy_var_parse_tuple(args, "is", &verdict, &description))
    {
      z_policy_raise_exception_obj(z_policy_exc_value_error, "Invalid arguments.");
      z_proxy_return(self,NULL);
    }
  if (self->super.parent_proxy)
    {
      ZProxyStackIface *iface;
      iface = z_proxy_find_iface(self->super.parent_proxy, Z_CLASS(ZProxyStackIface));
      if (iface)
        {
          z_proxy_stack_iface_set_verdict(iface, verdict, description);
          z_object_unref(&iface->super);
        }
    }
  z_policy_var_ref(z_policy_none);
  res = z_policy_none;
  z_proxy_return(self,res);
}

/**
 * anypy_config_set_defaults:
 * @self: AnyPyProxy instance
 *
 * This function initializes various attributes exported to the Python layer
 * for possible modification.
 **/
static void
anypy_config_set_defaults(AnyPyProxy *self)
{
  z_proxy_enter(self);

  self->max_line_length[EP_CLIENT] = 4096;
  self->max_line_length[EP_SERVER] = 4096;
  self->linebased = 1;

  z_proxy_leave(self);
}

/**
 * anypy_register_vars:
 * @self: AyPyProxy instance
 *
 * This function is called upon startup to export Python attributes.
 **/

static void
anypy_register_vars(AnyPyProxy *self)
{
  z_proxy_enter(self);
  /* method for setting the proxy verdict. It should be used before the first write */
  z_proxy_var_new(&self->super, "set_verdict",
	Z_VAR_TYPE_METHOD | Z_VAR_GET,
	self,anypy_set_verdict);
  /* method for registering callback for a stream */
  z_proxy_var_new(&self->super, "register_callback",
	Z_VAR_TYPE_METHOD | Z_VAR_GET,
	self,anypy_register_callback);
  /* method for adding a stream to the poll */
  z_proxy_var_new(&self->super, "add_to_poll",
	Z_VAR_TYPE_METHOD | Z_VAR_GET,
	self,anypy_add_to_poll);
  /* method for iterating through poll */
  z_proxy_var_new(&self->super, "poll_iter_timeout",
	Z_VAR_TYPE_METHOD | Z_VAR_GET,
	self,anypy_poll_iter_timeout);
  /* size of line buffer of the client stream */
  z_proxy_var_new(&self->super, "client_max_line_length",
	Z_VAR_TYPE_INT | Z_VAR_GET | Z_VAR_SET_CONFIG | Z_VAR_GET_CONFIG,
	&self->max_line_length[EP_CLIENT]);
  /* size of line buffer of the server stream */
  z_proxy_var_new(&self->super, "server_max_line_length",
	Z_VAR_TYPE_INT | Z_VAR_GET | Z_VAR_SET_CONFIG | Z_VAR_GET_CONFIG,
	&self->max_line_length[EP_SERVER]);
  /* is the proxy line-based (streams are streamlines)? */
  z_proxy_var_new(&self->super, "linebased",
	Z_VAR_TYPE_INT | Z_VAR_GET | Z_VAR_SET_CONFIG | Z_VAR_GET_CONFIG,
	&self->linebased);
  z_proxy_leave(self);
}

/**
 * anypy_config:
 * @s: AnyPyProxy instance casted to ZProxy
 *
 * This function is called upon startup to configure the proxy.
 * This calls the the __pre_config__, config and __post_config__ events.
 **/
static gboolean
anypy_config(ZProxy *s)
{
  AnyPyProxy *self = Z_CAST(s, AnyPyProxy);

  self->poll = z_poll_new();
  anypy_config_set_defaults(self);
  anypy_register_vars(self);
  if (Z_SUPER(s, ZProxy)->config(s))
    {
      return TRUE;
    }
  return FALSE;
}

static gboolean
anypy_startup(ZProxy * s)
{
  AnyPyProxy *self = Z_CAST(s, AnyPyProxy);

  z_proxy_enter(self);
  self->quit = 0;
  if (!z_proxy_connect_server(&self->super, NULL, 0) || !anypy_stream_init(self))
    {
      z_proxy_return(self,FALSE);
    }
  if (Z_SUPER(s,ZProxy)->startup(s))
    {
      z_proxy_return(self,TRUE);
    }
  z_proxy_return(self,FALSE);
}

static void
anypy_main(ZProxy * s)
{
  AnyPyProxy *self = Z_CAST(s, AnyPyProxy);
  ZPolicyObj *res;
  gboolean called;

  z_proxy_enter(self);
  self->quit = 0;
  z_policy_lock(self->super.thread);  
  res = z_policy_call(self->super.handler, "proxyThread", NULL, &called, self->super.session_id);
  z_policy_var_unref(res);
  z_poll_unref(self->poll);
  self->poll = NULL;
  z_policy_unlock(self->super.thread);
  z_proxy_return(self);
}

/**
 * anypy_proxy_new:
 * @params: parameters for the AnyPyProxy class constructor
 *
 * This function is called upon startup to create a new AnyPy proxy.
 **/
ZProxy *
anypy_proxy_new(ZProxyParams *params)
{
  AnyPyProxy *self;
  
  z_enter();
  self = Z_CAST(z_proxy_new(Z_CLASS(AnyPyProxy), params), AnyPyProxy);
  z_return(&self->super);
}

ZProxyFuncs anypy_proxy_funcs =
{
  {
    Z_FUNCS_COUNT(ZProxy),
    NULL
  },
  anypy_config,
  anypy_startup,
  anypy_main,
  NULL,
  NULL,
  NULL
};

ZClass AnyPyProxy__class =
{
  Z_CLASS_HEADER,
  &ZProxy__class,
  "AnyPyProxy",
  sizeof(AnyPyProxy),
  &anypy_proxy_funcs.super,
};

gint
zorp_module_init(void)
{
  z_registry_add("anypy", ZR_PYPROXY, anypy_proxy_new);
  return TRUE;
}
