############################################################################
##
## Copyright (c) 2000, 2001, 2002, 2003, 2004, 2005, 2006 BalaBit IT Ltd, Budapest, Hungary
##
## This program is free software; you can redistribute it and/or modify
## it under the terms of the GNU General Public License as published by
## the Free Software Foundation; either version 2 of the License, or
## (at your option) any later version.
##
## This program is distributed in the hope that it will be useful,
## but WITHOUT ANY WARRANTY; without even the implied warranty of
## MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
## GNU General Public License for more details.
##
## You should have received a copy of the GNU General Public License
## along with this program; if not, write to the Free Software
## Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
##
##
############################################################################

"""<module maturity="stable">
  <summary>Module defining interface to the establishment primitives.</summary>
  <description>
    <para>
      This module implements a couple of internal classes to establish
      connections. They are actively used by various <link
      linkend="python.Chainer">Chainer</link> classes, but otherwise they work
      'behind the scenes'.
    </para>
  </description>
  <metainfo/>
</module>
"""

import Zorp

class Attacher:
	"""<class internal="yes">
          <summary>A wrapper class around the ZorpAttach class implemented in C.</summary>
          <description>
            <para>
              This class is a wrapper around the ZorpAttach class
              implemented by the Zorp core, and as such it'll be a placeholder
              for future extensions.
            </para>
          </description>
          <metainfo>
            <attributes>
              <attribute maturity="stable">
                <name>local</name>
                <type>
                  <sockaddr/>
                </type>
                <description>Address of local end of the connection (set after __init__ in nonblocking mode, or after blockingConnect() in blocking mode)</description>
              </attribute>
              <attribute maturity="stable">
                <name>remote</name>
                <type>
                  <sockaddr/>
                </type>
                <description>Address where we connect</description>
              </attribute>
              <attribute maturity="stable">
                <name>attach</name>
                <type></type>
                <description>a Zorp.Attach object</description>
              </attribute>
            </attributes>
          </metainfo>
        </class>
	"""
	def __init__(self, session_id, protocol, local, remote, callback = None, **kw):
		"""<method maturity="stable">
                  <summary>Constructor initializing a Attach instance.</summary>
                  <description>
                    <para>
                      Sets the instance attributes based on constructor
                      parameters, and starts connecting in a separate thread if
                      callback is not None. If callback is None, a separate call
                      to blockingConnect() will start the connection.
                    </para>
                  </description>
                  <metainfo>
                    <arguments>
                      <argument maturity="stable">
                        <name>self</name>
                        <type></type>
                        <description>This instance</description>
                      </argument>
                      <argument maturity="stable">
                        <name>session_id</name>
                        <type></type>
                        <description>TBD The ID of the session initializing the Attach</description>
                      </argument>
                      <argument maturity="stable">
                        <name>protocol</name>
                        <type>TBD</type>
                        <description>TBD</description>
                      </argument>
                      <argument maturity="stable">
                        <name>local</name>
                        <type></type>
                        <description>Address of local end of the connection</description>
                      </argument>
                      <argument maturity="stable">
                        <name>remote</name>
                        <type></type>
                        <description>Address where we connect</description>
                      </argument>
                      <argument maturity="stable">
                        <name>callback</name>
                        <type></type>
                        <description>Callback to be called when the connection is established.</description>
                      </argument>
                      <argument maturity="stable">
                        <name>timeout</name>
                        <type></type>
                        <description>The timeout value for connection establishment in milliseconds. Applies to TCP only.
                        </description>
                      </argument>
                    </arguments>
                  </metainfo>
                </method>
		"""
		
		self.local = local
		self.remote = remote
		self.attach = Zorp.Attach(session_id, protocol, local, remote, callback, kw)

	def block(self):
		"""<method maturity="stable">
                  <summary>Function establishing a connection in blocking mode.</summary>
                  <description>
                    <para>
                      This function must be called when the Connect instance was
                      initialized with callback=None. It establishes the connection
                      in this thread (ie. waits for the connection to complete)
                      and returns the file corresponding file descriptor.
                      Returns the stream corresponding to the connection
                    </para>
                  </description>
                  <metainfo>
                    <arguments>
                      <argument maturity="stable">
                        <name>self</name>
                        <type></type>
                        <description>This instance</description>
                      </argument>
                    </arguments>
                  </metainfo>
                </method>
		"""
		global connect_hook
		
		self.attach.start()
		self.local = self.attach.local
		return self.attach.block()

	def start(self):
		"""<method internal="yes">
                </method>
		"""
		self.attach.start()
		
	def cancel(self):
		"""<method maturity="stable">
                  <summary>Function to destroy this connector instance.</summary>
                  <description>
                    <para>
                      This function forces the underlying ZorpAttach instance
                      to stop connecting and free any allocated memory block.
                    </para>
                  </description>
                  <metainfo>
                    <arguments>
                      <argument maturity="stable">
                        <name>self</name>
                        <type></type>
                        <description>This instance</description>
                      </argument>
                    </arguments>
                  </metainfo>
                </method>
		"""
		self.attach.cancel()
