############################################################################
##
## Copyright (c) 2000, 2001, 2002, 2003, 2004, 2005, 2006 BalaBit IT Ltd, Budapest, Hungary
##
## This program is free software; you can redistribute it and/or modify
## it under the terms of the GNU General Public License as published by
## the Free Software Foundation; either version 2 of the License, or
## (at your option) any later version.
##
## This program is distributed in the hope that it will be useful,
## but WITHOUT ANY WARRANTY; without even the implied warranty of
## MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
## GNU General Public License for more details.
##
## You should have received a copy of the GNU General Public License
## along with this program; if not, write to the Free Software
## Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
##
##
############################################################################

"""
<module maturity="stable">
  <summary>
    The Chainer module defines the classes required to connect to the target servers.
  </summary>
  <description>
	<para>
	Chainers establish a TCP or UDP connection between a proxy and a selected destination.
	The destination is usually a server, but the <link linkend="python.Chainer.SideStackChainer">SideStackChainer
	</link> connects an additional proxy before connecting the server.
	</para>
	
	<section id="chainer_protocol">
	<title>Selecting the network protocol</title>
	<para>The client-side and the server-side connections can use different networking protocols if needed.
	The <parameter>protocol</parameter> attribute of the chainer classes determines the network protocol used in the 
	server-side connection. By default, Zorp uses the same protocol in both connections. 
	The following options are available:</para>
	<!--<inline type="enum" target="zorp.proto.id"/>-->
	<table frame="all">
	<title>
	The network protocol used in the server-side connection
	</title>
	<tgroup cols="2">
	<thead>
		<row><entry>Name</entry><entry>Description</entry>
		</row></thead>
	<tbody>
		<row>
		<entry>ZD_PROTO_AUTO</entry>
		<entry>Use the protocol that is used on the client side.
		</entry>
		</row>
		<row>
		<entry>ZD_PROTO_TCP</entry>
		<entry>Use the TCP protocol on the server side.
		</entry>
		</row>
		<row>
		<entry>ZD_PROTO_UDP</entry>
		<entry>Use the UDP protocol on the server side.
		</entry>
		</row>
	</tbody>
	</tgroup>
	</table>
	</section>
  </description>
  <metainfo>
</metainfo>
</module>
"""

from Zorp import *
from Session import MasterSession
from Attach import Attacher
from Stream import Stream
from Session import StackedSession
from SockAddr import SockAddrInet
from NAT import NAT_SNAT, NAT_DNAT
from Cache import TimedCache
import types

class AbstractChainer:
	"""
        <class maturity="stable" abstract="yes">
          <summary>
            Class encapsulating the abstract chainer.
          </summary>
          <description>
            <para>
		AbstractChainer implements an abstract chainer that establishes a connection between
		the parent proxy and the selected destination. This class serves as a starting point for customized chainer
		classes, but is itself not directly usable. Service definitions should refer to a customized class derived 			from AbstractChainer, or one of the predefined chainer classes, such as <link
		      linkend="python.Chainer.ConnectChainer">ConnectChainer</link> or <link
		      linkend="python.Chainer.FailoverChainer">FailoverChainer</link>.
            </para>
          </description>
          <metainfo>
            <attributes/>
          </metainfo>
        </class>
	"""
	def __init__(self):
		"""
                <method internal="yes">
                </method>
		"""
		pass

	def setupFastpath(self, proxy):
		"""
                <method internal="yes">
                  <summary>
                    Function called to setup fast path handlers.
                  </summary>
                  <description>
                    <para>
                      This function is called to provide the C-level fast path
                      handlers to the proxy, which are called when subsequent
                      connections are added to the proxy (currently only used
                      for UDP proxies.
                    </para>
                  </description>
                  <metainfo/>
                </method>
		"""
		pass

	def chainParent(self, session):
		"""
                <method internal="yes">
                  <summary>
                    Function to be called when a proxy wants to connect to its parent.
                  </summary>
                  <description>
                    <para>
                      This function is called to actually perform chaining to the parent.
                    </para>
                  </description>
                  <metainfo>
                    <arguments>                      
                      <argument maturity="stable">
                        <name>session</name>
                        <type>SESSION</type>
                        <description>session we belong to</description>
                      </argument>
                    </arguments>
                  </metainfo>
                </method>
		"""
		raise NotImplementedError

class ConnectChainer(AbstractChainer):
	"""
        <class maturity="stable">
          <summary>
            Class to establish the server-side TCP/IP connection.
          </summary>
          <description>
            <para>
		ConnectChainer is the default chainer class based on AbstractChainer. This class establishes a TCP or UDP
		connection between the proxy and the selected destination address.
            </para>
            <para>
              	ConnectChainer is used by default if no other chainer class is specified in the service definition.
            </para>
            <para>
              ConnectChainer attempts to connect only a single destination address: if the connection establishment
              procedure selects multiple target servers (e.g., a <link linkend="python.Resolver.DNSResolver">DNSResolver</link> with the
              <parameter>multi=TRUE</parameter> parameter or a <link linkend="python.Router.DirectedRouter">DirectedRouter</link> with multiple
              addresses), ConnectChainer will use the first address and ignore all other addresses. Use <link
		      linkend="python.Chainer.FailoverChainer">FailoverChainer</link> to select from the destination 
		from multiple addresses in round-robin or failover fashion.	
            </para>
            <example>
              <title>A sample ConnectChainer</title>
              <para>The following service uses a ConnectChainer that uses the UDP protocol on the server side.</para>
		<synopsis>
Service(name="demo_service", proxy_class=HttpProxy, chainer=ConnectChainer(protocol=ZD_PROTO_UDP), router=TransparentRouter(overrideable=FALSE, forge_addr=FALSE))
		</synopsis>
            </example>
          </description>
          <metainfo>
            <attributes/>
          </metainfo>
        </class>
	"""
	
	def __init__(self, protocol=ZD_PROTO_AUTO, timeout=None):
		"""
                <method maturity="stable">
                  <summary>
                    Constructor to initialize an instance of the ConnectChainer class.
                  </summary>
                  <description>
                    <para>
                      This constructor creates a new ConnectChainer instance which can be
                      associated with a <link linkend="python.Service">Service</link>.
                    </para>
                  </description>
                  <metainfo>
                    <arguments>
                      <argument maturity="stable">
                        <name>protocol</name>
                        <type>
			  <link id="zorp.proto.id"/>
			</type>
			<default>ZD_PROTO_AUTO</default>
                        <description>
                          Optional parameter that specifies the network protocol used in the connection protocol. By
                          default, the server-side communication uses the same protocol that is
			  used on the client side. See <xref linkend="chainer_protocol"/> for details.
                        </description>
                      </argument>
                    </arguments>
                  </metainfo>
                </method>
		"""
		AbstractChainer.__init__(self)
		self.protocol = protocol
		if not timeout:
			self.timeout = config.options.timeout_server_connect
		else:
			self.timeout = timeout

	def setupFastpath(self, proxy):
		"""
                <method internal="yes">
                </method>
		"""
		protocol = self.protocol
		if protocol == 0:
			protocol = proxy.session.protocol
		setupConnectChainer(proxy, proxy.session.session_id, protocol)

	def establishConnection(self, session, local, remote):
		"""
                <method internal="yes">
                  <summary>
                    Function to actually establish a connection.
                  </summary>
                  <description>
                    <para>
                      Internal function to establish a connection with the given
                      local and remote addresses. It is used by derived chainer
                      classes after finding out the destination address to connect
                      to. This function performs access control checks.
                      Returns The stream of the connection to the server
                    </para>
                  </description>
                  <metainfo>
                    <arguments>                      
                      <argument maturity="stable">
                        <name>session</name>
                        <type>SESSION</type>
                        <description>session we belong to
                        </description>
                      </argument>
                      <argument maturity="stable">
                        <name>local</name>
                        <type></type>
                        <description>bind address</description>
                      </argument>
                      <argument maturity="stable">
                        <name>remote</name>
                        <type></type>
                        <description>host to connect to</description>
                      </argument>
                      <argument maturity="stable">
                        <name>protocol</name>
                        <type></type>
                        <description>protocol to connect to</description>
                      </argument>
                    </arguments>
                  </metainfo>
                </method>
		"""
		protocol = self.protocol
		if protocol == 0:
			protocol = session.protocol
		if remote.port == 0:
			remote.port = session.client_local.port
		session.setServer(remote)
		if session.isServerPermitted() == Z_ACCEPT:
			#remote.options = session.client_address.options
			try:
				conn = Attacher(session.session_id, protocol, local, remote, local_loose=session.server_local_loose, tos=session.server_tos, timeout=self.timeout)
				session.server_stream = conn.block()
				session.server_local = conn.local
			except IOError:
				session.server_stream = None
			if session.server_stream == None:
				## LOG ##
				# This message indicates that the connection to the server failed.
				##
				log(session.session_id, CORE_SESSION, 3, 
                                    "Server connection failure; server_address='%s', server_zone='%s', server_local='%s', server_protocol='%s'",
                                    (session.server_address, session.server_zone, session.server_local, session.protocol_name))
			else:
				session.server_stream.name = session.session_id + "/server"
				## LOG ##
				# This message indicates that the connection to the server succeeded.
				##
				log(session.session_id, CORE_SESSION, 3, 
				    "Server connection established; server_fd='%d', server_address='%s', server_zone='%s', server_local='%s', server_protocol='%s'",
				    (session.server_stream.fd, session.server_address, session.server_zone, session.server_local, session.protocol_name))
			return session.server_stream
		raise DACException

	def chainParent(self, session):
		"""
                <method internal="yes">
                  <summary>
                    Function to perform connection establishment.
                  </summary>
                  <description>
                    <para>
                      This function is called by the underlying proxy implementation
                      to actually connect to the server-endpoint of the session.
                      The destination address is 'session.server_address' (which
                      is previously set by the Router used for the service, and
                      optionally overridden by the Proxy). The local address to
                      bind to is determined with the help of a NAT object if one
                      is provided, or allocated dynamically by the kernel.
                    </para>
                  </description>
                  <metainfo>
                    <arguments>
                      <argument maturity="stable">
                        <name>session</name>
                        <type>AbstractSession instance</type>
                        <description>session we belong to</description>
                      </argument>
                    </arguments>
                  </metainfo>
                </method>
		"""
		if session.server_local:
			local = session.server_local.clone(0)
		else:
			local = None

		if type(session.server_address) == types.TupleType and type(session.server_address) == types.ListType:
			session.server_address = session.server_address[0]

		if session.server_address == None:
			## LOG ##
			# This message indicates that the connection to the
			# server can not be established, because no server
			# address is set.
			##
			log(session.session_id, CORE_SESSION, 3, "Server connection failure, no destination;")
			return None
		elif type(session.server_address) == types.TupleType or type(session.server_address) == types.ListType:
			## LOG ##
			# This message indicates that the connection to the
			# server can not be established, the routing
			# meachnism specified several destination addresses
			# and ConnectChainer only supports a single address.
			##
			log(session.session_id, CORE_SESSION, 3, "Server connection failure, multiple destination addresses;")
			return None
		remote = session.server_address.clone(0)

		if session.service.snat_policy:
			local = session.service.snat_policy.performTranslation(session, local, NAT_SNAT)

		if session.service.dnat_policy:
			remote = session.service.dnat_policy.performTranslation(session, remote, NAT_DNAT)

		return self.establishConnection(session, local, remote)

class FailoverChainer(ConnectChainer):
	"""
        <class maturity="stable">
          <summary>
            Class to establish the server-side connection with failover and load-balancing capabilities.
          </summary>
          <description>
            <para>
              FailoverChainer is based on ConnectChainer, but has the extra capability 
              to select the destination server from a list. The destination 
              server can be selected in failover or round-robin fashion. 
            </para>
	<para>
		The Router class used in the service sets a list
		of IP addresses in the <parameter>session.server_address</parameter> 
		attribute. In failover mode, the chainer attempts to connect the 
		first address in the list. If the destination is unreachable the chainer
		attempts to connect the next destination address of the list. </para>	
	<para>
		In round-robin mode, the chainer directs each incoming connection 
		to the next available server of the list. That way the load is 
		balanced between the servers set in the destination list.
	</para>
	<para>If only one server is set, FailoverChainer acts as a regular ConnectChainer.
        </para>
            <example>
              <title>A sample FailoverChainer</title>
              <para>The following service uses FailoverChainer to select the 
              destination from a list defined in a DirectedRouter.</para>
		<synopsis>
Service(name="demo_service", proxy_class=HttpProxy, chainer=FailoverChainer(protocol=ZD_PROTO_TCP, timeout=0, round_robin=TRUE), router=DirectedRouter(dest_addr=(SockAddrInet('192.168.25.25', 80), SockAddrInet('192.168.25.26', 80), SockAddrInet('192.168.25.27', 80)), overrideable=FALSE, forge_addr=FALSE))
		</synopsis>
            </example>
          </description>
          <metainfo>
            <attributes>
               <attribute internal="yes">
                 <name>current_host</name>
                 <type></type>
                 <description>index of the last attempted destination</description>
               </attribute>
             </attributes>
          </metainfo>
        </class>
	"""
	def __init__(self, protocol=ZD_PROTO_TCP, timeout=0, round_robin=TRUE):
		"""
                <method maturity="stable">
                  <summary>
                    Constructor to initialize an instance of the FailoverChainer class.
                  </summary>
                  <description>
                    <para>
                      This constructor creates a new FailoverChainer instance which can be
                      associated with a <link linkend="python.Service.Service">Service</link>.
                    </para>
                  </description>
                  <metainfo>
                    <arguments>
                      <argument maturity="stable">
                        <name>protocol</name>
                        <type>
			  <link id="zorp.proto.id"/>
			</type>
			<default>ZD_PROTO_TCP</default>
			<description>
                          Optional parameter that specifies the network protocol used in the connection protocol. By
                          default, the server-side communication uses the same protocol that is
			  used on the client side. See <xref linkend="chainer_protocol"/> for details.
                        </description>
                      </argument>
                      <argument>
                        <name>timeout</name>
                        <type>
			  <integer/>
			</type>
			<default>0</default>
                        <description>
                          Zorp does not try to connect to an unreachable server until this timeout (specified in seconds) expires.   
                        </description>
                      </argument>
                      <argument>
                        <name>round_robin</name>
                        <type>
			  <boolean/>
			</type>
			<default>TRUE</default>
                        <description>
                         If set to <parameter>TRUE</parameter>, the chainer connects to the destination addresses in
			 round-robin fashion.
                        </description>
                      </argument>
                    </arguments>
                  </metainfo>
                </method>
		"""
		ConnectChainer.__init__(self, protocol)
		if timeout:
			self.state = TimedCache('failover-state', timeout, update_stamp=FALSE)
		else:
			self.state = None
		self.current_host = 0
		self.round_robin = round_robin

	def chainParent(self, session):
		"""
                <method internal="yes">
                  <summary>
                    Overridden function to perform connection establishment.
                  </summary>
                  <description>
                    <para>
                      This function is called by the actual Proxy implementation
                      to actually connect to the server-endpoint of the session.
                      The destination address is 'session.server_address' (which
                      is previously set by the Router used for the service, and
                      optionally overridden by the Proxy). The local address to
                      bind to is determined with the help of a NAT object if one
                      is provided, or allocated dynamically by the kernel.
                    </para>
                    <para>
                      The failover capability of FailoverChainer is implemented
                      here.
                    </para>
                  </description>
                  <metainfo>
                    <arguments>
                      <argument maturity="stable">
                        <name>session</name>
                        <type>SESSION</type>
                        <description>session we belong to
                        </description>
                      </argument>
                    </arguments>
                  </metainfo>
                </method>
		"""
		if session.server_local:
			local = session.server_local.clone(0)
		else:
			local = None
		hostlist = session.server_address
		if type(hostlist) != types.TupleType and type(hostlist) != types.ListType:
			return ConnectChainer.chainParent(self, session)

		if len(hostlist) == 1:
			session.server_address = hostlist[0]
			return ConnectChainer.chainParent(self, session)

		if session.service.snat_policy:
			local = session.service.snat_policy.performTranslation(session, local, NAT_SNAT)

 		if not self.round_robin:
 			self.current_host = 0

		stream = None
		try_count = 0
		while (try_count < 2)  and (stream == None):
			first_attempt = self.current_host % len(hostlist)
			remote = None
	 		while stream == None and (remote == None or (self.current_host != first_attempt)):
				remote = hostlist[self.current_host].clone(0)
				self.current_host = (self.current_host + 1) % len(hostlist)

				if session.service.dnat_policy:
					remote = session.service.dnat_policy.performTranslation(session, remote, NAT_DNAT)

				if self.state:
					is_host_down = self.state.lookup(remote.ip_s)
				else:
					is_host_down = 0
				if not is_host_down:
					stream = self.establishConnection(session, local, remote)
					if not stream and self.state:
						## LOG ##
						# This message reports that the remote end is down and Zorp stores the 
						# down state of the remote end, so Zorp wont try to connect to it within the 
						# timeout latter.
						##
						log(None, CORE_MESSAGE, 4, "Destination is down, keeping state; remote='%s'", (remote,))
						self.state.store(remote.ip_s, 1)
				else:
					## LOG ##
					# This message reports that the remote end is down, but Zorp does not store the
					# down state of the remote end, so Zorp will try to connect to it next time.
					##
					log(None, CORE_MESSAGE, 4, "Destination is down, skipping; remote='%s'", (remote,))
			if (stream == None) and (try_count == 0):
				if self.state:
					log(None, CORE_MESSAGE, 4, "All destinations are down, clearing cache and trying again;")
					self.state.clear()
				else:
					# there was no state, tried all possible destinations, no point in trying again
					break
			try_count = try_count + 1
		return stream


class SideStackChainer(AbstractChainer):
	"""
        <class maturity="stable">
          <summary>
            Class to pass the traffic to another proxy.
          </summary>
          <description>
            <para>
              This class encapsulates a special chainer. Instead of
              establishing a connection to a server, it creates
              a new proxy instance and connects the server side of the current (parent) proxy
              to the client side of the new (child) proxy. The <parameter>right_class</parameter>
               parameter specifies the child proxy.
            </para>
            <para>
             It is possible to stack multiple proxies side-by-side. The final step of sidestacking is always to specify 
             a regular chainer via the <parameter>right_chainer</parameter> parameter that connects the last proxy to the 
             destination server.
            </para>            
            <tip>
            <para>
            Proxy sidestacking is useful for example to create one-sided SSL connections. 
            See the tutorials of the BalaBit Documentation Page available at  
            <ulink url="http://www.balabit.com/support/documentation/">http://www.balabit.com/support/documentation/</ulink> 
            for details.
            </para>
            </tip>
          </description>
          <metainfo>
            <attributes>
              <attribute maturity="stable">
                <name>right_class</name>
                <type></type>
                <description>The proxy class to connect to the parent proxy. Both built-in and customized classes 
                can be used.</description>
              </attribute>
              <attribute maturity="stable">
                <name>right_chainer</name>
                <type></type>
                <description>The chainer used to connect to the destination of the side-stacked proxy class set in the
		<parameter>right_class</parameter> attribute.
                </description>
              </attribute>
            </attributes>
          </metainfo>
        </class>
	"""
	def __init__(self, right_class, right_chainer = None):
		"""
                <method maturity="stable">
                  <summary>
                    Constructor to initialize an instance of the SideStackChainer class.
                  </summary>
                  <description>
			<para>
                      This constructor creates a new FailoverChainer instance which can be
                      associated with a <link linkend="python.Service.Service">Service</link>.
                    </para>
                  </description>
                  <metainfo>
                    <arguments>
                      <argument maturity="stable">
                        <name>right_class</name>
                        <type>
			  <class filter="proxy"/>
			</type>
                        <description>The proxy class to connect to the parent proxy. Both built-in or customized classes 				can be used.</description>
                      </argument>
                      <argument maturity="stable">
                        <name>right_chainer</name>
                        <type>
			  <class filter="chainer" instance="yes"/>
			</type>
			<default>None</default>
                        <description>The chainer used to connect to the destionation of the side-stacked proxy class set in 				the <parameter>right_class</parameter> attribute.</description>
                      </argument>
                    </arguments>
                  </metainfo>
                </method>
		"""
		AbstractChainer.__init__(self)
		self.right_class = right_class
		if right_chainer == None:
			right_chainer = ConnectChainer()
		self.right_chainer = right_chainer

	def chainParent(self, session):
		"""
                <method internal="yes">
                  <summary>
                    Overridden function to perform chaining.
                  </summary>
                  <description>
                    <para>
                      This function is called by a Proxy instance to establish its
                      server side connection. Instead of connecting to a server
                      this chainer creates another proxy instance and connects
                      this new proxy with the current one.
                    </para>
                  </description>
                  <metainfo>
                    <arguments>
                      <argument maturity="stable">
                        <name>session</name>
                        <type>SESSION</type>
                        <description>session we belong to</description>
                      </argument>
                    </arguments>
                  </metainfo>
                </method>
		"""
		try:
			streams = streamPair(AF_UNIX, SOCK_STREAM)
		except IOError:
			## LOG ##
			# This message indicates that side stacking failed, because Zorp was unable to create a socketPair.
			# It is likely that there is now resource available. Try increase fd limits.
			##
			log(session.session_id, CORE_SESSION, 3, "Side stacking failed, socketPair failed;")
			return None

		try:
			# convert our tuple to an array, to make it possible
			# to modify items
			streams = [streams[0], streams[1]]
			ss = None

			session.server_stream = streams[0]
			session.server_stream.name = session.owner.session_id + "/leftside"
			ss = StackedSession(session, self.right_chainer)
			streams[0] = None
			ss.client_stream = streams[1]
			ss.client_stream.name = ss.session_id + "/rightside"
			ss.server_stream = None
			streams[1] = None
			## LOG ##
			# This message indicates that side stacking was successful.
			##
			log(session.session_id, CORE_SESSION, 4, 
                                "Side-stacking proxy instance; server_fd='%d', client_fd='%d', proxy_class='%s'",
                                (session.server_stream.fd, ss.client_stream.fd, self.right_class.__name__))
			self.right_class(ss)
		except:
			## LOG ##
			# This message indicates that side stacking failed. 
			##
			log(session.session_id, CORE_ERROR, 3, "Side-stacking failed; proxy_class='%s'", (self.right_class.__name__))
			if ss:
				ss.destroy()
			if (streams[0] != None):
				streams[0].close()
			if (streams[1] != None):
				streams[1].close()
