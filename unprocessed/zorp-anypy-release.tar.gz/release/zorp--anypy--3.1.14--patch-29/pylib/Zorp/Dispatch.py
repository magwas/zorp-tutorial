############################################################################
##
## Copyright (c) 2000, 2001, 2002, 2003, 2004, 2005, 2006 BalaBit IT Ltd, Budapest, Hungary
##
## This program is free software; you can redistribute it and/or modify
## it under the terms of the GNU General Public License as published by
## the Free Software Foundation; either version 2 of the License, or
## (at your option) any later version.
##
## This program is distributed in the hope that it will be useful,
## but WITHOUT ANY WARRANTY; without even the implied warranty of
## MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
## GNU General Public License for more details.
##
## You should have received a copy of the GNU General Public License
## along with this program; if not, write to the Free Software
## Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
##
##
############################################################################
"""
<module maturity="stable">
  <summary>The Dispatch module defines the abstract classes that accept incoming connections.</summary>
   <description>
    <para>
      This module defines the abstract dispatcher classes. The Listener and Receiver classes derived from dispatchers
       listen for incoming connection requests on the interfaces of Zorp. Dispatchers cannot be used directly in service
        definitions: use <link linkend="python.Listener">Listeners</link> to accept TCP traffic, and 
        <link linkend="python.Receiver">Receivers</link> to accept UDP traffic. 
	</para>
	</description>
  <metainfo>
    <enums>
      <enum maturity="stable" id="enum.zd.pri">
        <description/>
        <item>
          <name>ZD_PRI_LISTEN</name>
        </item>
        <item>
          <name>ZD_PRI_NORMAL</name>
        </item>
        <item>
          <name>ZD_PRI_RELATED</name>
        </item>
      </enum>
    </enums>
  </metainfo>
</module>
"""
from Zorp import *
from Session import MasterSession
from Cache import ShiftCache
from traceback import print_exc
from string import atoi
import Zorp, SockAddr
import types, sys

listen_hook = None
unlisten_hook = None
dispatch_id = 0

ZD_PRI_LISTEN = 100
ZD_PRI_NORMAL = 0
ZD_PRI_RELATED = -100

"""
<module maturity="stable">
  <summary>
  </summary>
  <description/>
</module>
"""  
def convertSockAddrToDB(sa, protocol):
	"""
        <function internal="yes">
        </function>
	"""
        if type(sa) == list:
                return map(lambda x: convertSockAddrToDB(x), sa)
        if type(sa) == SockAddr.SockAddrType:
                if protocol == ZD_PROTO_AUTO:
                        raise ValueError, "No preferred protocol specified"
                return DBSockAddr(sa, protocol=protocol)
        else:
                if sa.protocol:
			if sa.protocol != protocol:
	                        raise ValueError, "Protocol number mismatch (%d != %d)" % (sa.protocol, protocol)
		else:
			sa.protocol = protocol
                return sa

class AbstractDispatch:
	"""
        <class maturity="stable" abstract="yes" internal="yes">
        <summary>Class encapsulating the abstract Dispatch interface.</summary>
          <description>
            <para>
            </para>
          </description>
        </class>
	"""
	def __init__(self, session_id, bindto=None, **kw):
		"""
                <method internal="yes">
                </method>
		"""
		global dispatch_id
		
                if not bindto:
                        raise ValueError, "bindto is required argument"
		
		self.session_id = 'dsp/dispatch:%d' % dispatch_id
		dispatch_id = dispatch_id + 1
		self.dispatches = []
		prio = kw.pop('prio', ZD_PRI_LISTEN)
		if kw == None:
			kw = {}
		if type(bindto) == types.TupleType or type(bindto) == types.ListType:
			self.protocol = ZD_PROTO_AUTO
			for b in bindto:
                                if b.protocol == ZD_PROTO_AUTO:
                                        raise ValueError, "No preferred protocol is specified"
				if b.protocol != self.protocol:
					if self.protocol == ZD_PROTO_AUTO:
						self.protocol = b.protocol
					else:
						raise ValueError, "Inconsistent protocol specified in dispatch addresses"
				self.dispatches.append(Dispatch(self.session_id, b, prio, self.accepted, kw))
		else:
                        if bindto.protocol == ZD_PROTO_AUTO:
                                raise ValueError, "No preferred protocol is specified"
			self.protocol = bindto.protocol
			self.dispatches.append(Dispatch(self.session_id, bindto, prio, self.accepted, kw))
			
		Globals.dispatches.append(self)

	def accepted(self):
		"""
                <method internal="yes">
                  <summary>Function called when a connection is established.</summary>
                  <description>
                    <para>
                      This function is called when a connection is established.
                      It does nothing here, it should be overridden by descendant
                      classes.
                    </para>
                  </description>
                  <metainfo>
                    <arguments/>
                  </metainfo>
                </method>
		"""
		return Z_REJECT

	def destroy(self):
		"""
                <method internal="yes">
                  <summary>Stops the listener on the given port</summary>
                  <description>
                    <para>
                      Calls the destroy method of the low-level object
                    </para>
                  </description>
                  <metainfo>
                    <arguments/>
                  </metainfo>
                </method>
		"""
		for d in self.dispatches:
			d.destroy()


class Dispatcher(AbstractDispatch):
	"""
        <class maturity="stable" internal="yes">
          <summary>Class encapsulating the Dispatcher which starts a service by the client and server zone.</summary>
          <description>
            <para>
              This class is the starting point of Zorp services. It listens on the
              given port, and when a connection is accepted it starts a session
              and the given service.
            </para>
          </description>
          <metainfo>
            <attributes>
              <attribute maturity="stable">
                <name>listen</name>
                <type></type>
                <description>A Zorp.Listen instance</description>
              </attribute>
              <attribute maturity="stable">
                <name>service</name>
                <type></type>
                <description>the service to be started</description>
              </attribute>
              <attribute maturity="stable">
                <name>bindto</name>
                <type></type>
                <description>bind address</description>
              </attribute>
              <attribute maturity="stable">
                <name>local</name>
                <type></type>
                <description>local address where the listener is bound</description>
              </attribute>
              <attribute maturity="stable">
                <name>protocol</name>
                <type></type>
                <description>the protocol we were bound to</description>
              </attribute>
            </attributes>
          </metainfo>
        </class>
	"""

	def __init__(self, bindto=None, service=None, **kw):
		"""
                <method maturity="stable">
                  <summary>Constructor to initialize a Listen instance</summary>
                  <description>
                    <para>
                      Creates the instance, sets the initial attributes, and
                      starts the listener
                    </para>
                  </description>
                  <metainfo>
                    <arguments>
                      <argument maturity="stable">
                        <name>bindto</name>
                        <type></type>
                        <description>the address to bind to</description>
                      </argument>
                      <argument maturity="stable">
                        <name>service</name>
                        <type></type>
                        <description>the service name to start</description>
                      </argument>
                      <argument maturity="stable">
                        <name>transparent</name>
                        <type></type>
                        <description>TRUE if this is a listener of a transparent service, specifying this is not mandatory but performs additional checks</description>
                      </argument>
                    </arguments>
                  </metainfo>
                </method>
		"""
		try:
			if service != None:
				self.service = Globals.services[service]
			else:
				self.service = None
		except KeyError:
			raise ServiceException, "Service %s not found" % (service,)
		self.bindto = bindto
	        AbstractDispatch.__init__(self, Zorp.firewall_name, bindto, **kw)
	        
	def accepted(self, stream, client_address, client_local, client_listen):
		"""
                <method internal="yes">
                  <summary>Callback to inform the python layer about incoming connections.</summary>
                  <description>
                    <para>
                      This callback is called by the core when a connection is
                      accepted. Its primary function is to check access control
                      (whether the client is permitted to connect to this port),
                      and to spawn a new session to handle the connection.
                    </para>
                    <para>
                      Exceptions raised due to policy violations are handled here.
                      Returns TRUE if the connection is accepted
                    </para>
                  </description>
                  <metainfo>
                    <arguments>
                      <argument maturity="stable">
                        <name>stream</name>
                        <type></type>
                        <description>the stream of the connection to the client</description>
                      </argument>
                      <argument maturity="stable">
                        <name>client_address</name>
                        <type></type>
                        <description>the address of the client</description>
                      </argument>
                      <argument maturity="stable">
                        <name>client_local</name>
                        <type></type>
                        <description>client local address (contains the original destination if transparent)</description>
                      </argument>
                      <argument maturity="stable">
                        <name>client_listen</name>
                        <type></type>
                        <description>the address where the listener was bound to</description>
                      </argument>
                    </arguments>
                  </metainfo>
                </method>
		"""
		if stream == None:
			return None
		session = None
		try:
			session = MasterSession()
			session.setProtocol(self.protocol)
			stream.name = session.session_id
			session.setClient(stream, client_address)
			session.client_local = client_local
			session.client_listen = client_listen
			try:
				if stream.fd != -1:
					session.client_tos = Zorp.getPeerToS(stream.fd)
					Zorp.setOurToS(stream.fd, session.client_tos)
			except IOError:
				pass
			
			service = self.getService(session)
			if not service:
				raise DACException, "No applicable service found"
			session.setService(service)
			
			service.router.routeConnection(session)

			if session.isClientPermitted() == Z_ACCEPT:
				## LOG ##
				# This message indicates that a new connection is accepted.
				##
 				log(session.session_id, CORE_DEBUG, 8, "Connection accepted; client_address='%s'", (client_address,))
 				sys.exc_clear()
				proxy = session.service.startInstance(session)
				if proxy:
					return proxy
			else:
				raise DACException, "This service was not permitted outbound"
		except ZoneException, s:
			## LOG ##
			# This message indicates that no appropriate zone was found for the client address.
			# @see: Zone
			##
 			log(session.session_id, CORE_POLICY, 1, "Zone not found; info='%s'", (s,))
		except DACException, s:
			## LOG ##
			# This message indicates that an DAC policy violation occurred.
			# It is likely that the new connection was not permitted as an outbound_service in the given zone.
			# @see: Zone
			##
 			log(session.session_id, CORE_POLICY, 1, "DAC policy violation; info='%s'", (s,))
		except MACException, s:
			## LOG ##
			# This message indicates that a MAC policy violation occurred.
			##
 			log(session.session_id, CORE_POLICY, 1, "MAC policy violation; info='%s'", (s,))
		except AAException, s:
			## LOG ##
			# This message indicates that an authentication failure occurred.
			# @see: Auth
			##
 			log(session.session_id, CORE_POLICY, 1, "Authentication failure; info='%s'", (s,))
		except LimitException, s:
			## LOG ##
			# This message indicates that the maximum number of concurrent instance number is reached.
			# Try increase the Service "max_instances" attribute.
			# @see: Service.Service
			##
 			log(session.session_id, CORE_POLICY, 1, "Connection over permitted limits; info='%s'", (s,))
		except LicenseException, s:
			## LOG ##
			# This message indicates that the licensed number of IP address limit is reached, and no new IP address is allowed or an unlicensed component is used.
			# Check your license's "Licensed-Hosts" and "Licensed-Options" options.
			##
			log(session.session_id, CORE_POLICY, 1, "Attempt to use an unlicensed component, or number of licensed hosts exceeded; info='%s'", (s,))
		except:
			print_exc()
			
		if session != None: 
			session.destroy()

		return None

	def getService(self, session):
		"""
                <method internal="yes">
                  <summary>Returns the service associated with the listener</summary>
                  <description>
                    <para>
                      Returns the service to start.
                    </para>
                  </description>
                  <metainfo>
                    <arguments>
                      <argument maturity="stable">
                        <name>session</name>
                        <type></type>
                        <description>session reference</description>
                      </argument>
                    </arguments>
                  </metainfo>
                </method>
		"""
		return self.service


class ZoneDispatcher(Dispatcher):
	"""
        <class maturity="stable" internal="yes">
          <summary>Class encapsulating the Dispatcher which starts a service by the client zone.</summary>
          <description>
            <para>
              This class is similar to a simple Dispatcher, but instead of
              starting a fixed service, it chooses one based on the client
              zone.
            </para>
            <para>
              It takes a mapping of services indexed by a zone name, with
              an exception of the '*' service, which matches anything.
            </para>
          </description>
          <metainfo>
            <attributes>
              <attribute maturity="stable">
                <name>services</name>
                <type></type>
                <description>services mapping indexed by zone name</description>
              </attribute>
            </attributes>
          </metainfo>
        </class>
	"""
	
	def __init__(self, bindto=None, services=None, **kw):
		"""
                <method maturity="stable">
                  <summary>Constructor to initialize a ZoneDispatcher instance.</summary>
                  <description>
                    <para>
                      This constructor initializes a ZoneDispatcher instance and sets
                      its initial attributes based on arguments.
                    </para>
                  </description>
                  <metainfo>
                    <arguments>
                      <argument maturity="stable">
                        <name>bindto</name>
                        <type></type>
                        <description>bind to this address</description>
                      </argument>
                      <argument maturity="stable">
                        <name>services</name>
                        <type></type>
                        <description>a mapping between zone names and services</description>
                      </argument>
                      <argument maturity="stable">
                        <name>follow_paren</name>
                        <type></type>
                        <description>whether to follow the administrative hieararchy when finding the correct service</description>
                      </argument>
                    </arguments>
                  </metainfo>
                </method>
		"""
		self.follow_parent = kw.pop('follow_parent', FALSE)
		Dispatcher.__init__(self, bindto, None, **kw)
		self.services = services
		self.cache = ShiftCache('sdispatch(%s)' % str(bindto), config.zone_dispatcher_shift_threshold)
	
	def getService(self, session):
		"""
                <method internal="yes">
                  <summary>Virtual function which returns the service to be ran</summary>
                  <description>
                    <para>
                      This function is called by our base class to find out the
                      service to be used for the current session. It uses the
                      client zone name to decide which service to use.
                    </para>
                  </description>
                  <metainfo>
                    <arguments>
                      <argument maturity="stable">
                        <name>session</name>
                        <type></type>
                        <description>session we are starting</description>
                      </argument>
                    </arguments>
                  </metainfo>
                </method>
		"""

		cache_ndx = session.client_zone.getName()

                cached = self.cache.lookup(cache_ndx)
                if cached == 0:
                        ## LOG ##
                        # This message indicates that no applicable service was found for this client zone in the services cache.
                        # It is likely that there is no applicable service configured in this ZoneListener/Receiver at all.
                        # Check your ZoneListener/Receiver service configuration.
                        # @see: Listener.ZoneListener
                        # @see: Receiver.ZoneReceiver
                        ##
                        log(None, CORE_POLICY, 2, "No applicable service found for this client zone (cached); bindto='%s', client_zone='%s'", (self.bindto, session.client_zone))
                elif cached:
                        return cached

		src_hierarchy = {}
		if self.follow_parent:
			z = session.client_zone
			level = 0
			while z:
				src_hierarchy[z.getName()] = level
				z = z.admin_parent
				level = level + 1
			src_hierarchy['*'] = level
			max_level = level + 1
		else:
			src_hierarchy[session.client_zone.getName()] = 0
			src_hierarchy['*'] = 1
			max_level = 10

		best = None
		for spec in self.services.keys():
			try:
				src_level = src_hierarchy[spec]
			except KeyError:
				src_level = max_level
				
			if not best or 							\
			   (best_src_level > src_level):
				best = self.services[spec]
				best_src_level = src_level

		s = None
		if best_src_level < max_level:
			try:
				s = Globals.services[best]
			except KeyError:
				log(None, CORE_POLICY, 2, "No such service; service='%s'", (best))

		else:
			## LOG ##
			# This message indicates that no applicable service was found for this client zone. 
			# Check your ZoneListener/Receiver service configuration.
			# @see: Listener.ZoneListener
			# @see: Receiver.ZoneReceiver
			##
			log(None, CORE_POLICY, 2, "No applicable service found for this client zone; bindto='%s', client_zone='%s'", (self.bindto, session.client_zone))

		self.cache.store(cache_ndx, s)
		return s

class CSZoneDispatcher(Dispatcher):
	"""
        <class maturity="stable" internal="yes">
          <summary>Class encapsulating the Dispatcher which starts a service by the client and server zone.</summary>
          <description>
            <para>
              This class is similar to a simple Dispatcher, but instead of
              starting a fixed service, it chooses one based on the client
              and the destined server zone.
            </para>
            <para>
              It takes a mapping of services indexed by a client and the server
              zone name, with an exception of the '*' zone, which matches
              anything.
            </para>
            <para>
              NOTE: the server zone might change during proxy and NAT processing,
              therefore the server zone used here only matches the real
              destination if those phases leave the server address intact.
            </para>
          </description>
          <metainfo>
            <attributes>
              <attribute maturity="stable">
                <name>services</name>
                <type></type>
                <description>services mapping indexed by zone names</description>
              </attribute>
            </attributes>
          </metainfo>
        </class>
	"""
	
	def __init__(self, bindto=None, services=None, **kw):
		"""
                <method maturity="stable">
                  <summary>Constructor to initialize a ZoneDispatcher instance.</summary>
                  <description>
                    <para>
                      This constructor initializes a ZoneDispatcher instance and sets
                      its initial attributes based on arguments.
                    </para>
                  </description>
                  <metainfo>
                    <arguments>
                      <argument maturity="stable">
                        <name>bindto</name>
                        <type></type>
                        <description>bind to this address</description>
                      </argument>
                      <argument maturity="stable">
                        <name>services</name>
                        <type></type>
                        <description>a mapping between zone names and services</description>
                      </argument>
                      <argument maturity="stable">
                        <name>follow_parent</name>
                        <type></type>
                        <description>whether to follow the administrative hieararchy when finding the correct service</description>
                      </argument>
                    </arguments>
                  </metainfo>
                </method>
		"""
		self.follow_parent = kw.pop('follow_parent', FALSE)
		Dispatcher.__init__(self, bindto, None, **kw)
		self.services = services
		self.cache = ShiftCache('csdispatch(%s)' % str(self.bindto), config.zone_dispatcher_shift_threshold)
	
	def getService(self, session):  
		"""
                <method internal="yes">
                  <summary>Virtual function which returns the service to be ran</summary>
                  <description>
                    <para>
                      This function is called by our base class to find out the
                      service to be used for the current session. It uses the
                      client and the server zone name to decide which service to
                      use.
                    </para>
                  </description>
                  <metainfo>
                    <arguments>
                      <argument maturity="stable">
                        <name>session</name>
                        <type></type>
                        <description>session we are starting</description>
                      </argument>
                    </arguments>
                  </metainfo>
                </method>
		"""
		from Zone import root_zone
		dest_zone = root_zone.findZone(session.client_local)
		
		cache_ndx = (session.client_zone.getName(), dest_zone.getName())

                cached = self.cache.lookup(cache_ndx)
                if cached == 0:
                        ## LOG ##
                        # This message indicates that no applicable service was found for this client zone in the services cache.
                        # It is likely that there is no applicable service configured in this CSZoneListener/Receiver at all.
                        # Check your CSZoneListener/Receiver service configuration.
                        # @see: Listener.CSZoneListener
                        # @see: Receiver.CSZoneReceiver
                        ##
                        log(None, CORE_POLICY, 2, "No applicable service found for this client & server zone (cached); bindto='%s', client_zone='%s', server_zone='%s'", (self.bindto, session.client_zone, dest_zone))
                elif cached:
			return cached

		src_hierarchy = {}
		dst_hierarchy = {}
		if self.follow_parent:
			z = session.client_zone
			level = 0
			while z:
				src_hierarchy[z.getName()] = level
				z = z.admin_parent
				level = level + 1
			src_hierarchy['*'] = level
			max_level = level + 1
			z = dest_zone
			level = 0
			while z:
				dst_hierarchy[z.getName()] = level
				z = z.admin_parent
				level = level + 1
			dst_hierarchy['*'] = level
			max_level = max(max_level, level + 1)
		else:
			src_hierarchy[session.client_zone.getName()] = 0
			src_hierarchy['*'] = 1
			dst_hierarchy[dest_zone.getName()] = 0
			dst_hierarchy['*'] = 1
			max_level = 10

		best = None
		for spec in self.services.keys():
			try:
				src_level = src_hierarchy[spec[0]]
				dst_level = dst_hierarchy[spec[1]]
			except KeyError:
				src_level = max_level
				dst_level = max_level
				
			if not best or 							\
			   (best_src_level > src_level) or				\
			   (best_src_level == src_level and best_dst_level > dst_level):
				best = self.services[spec]
				best_src_level = src_level
				best_dst_level = dst_level
				
		s = None
		if best_src_level < max_level and best_dst_level < max_level:
			try:
				s = Globals.services[best]
			except KeyError:
				log(None, CORE_POLICY, 2, "No such service; service='%s'", (best))
		else:
			## LOG ##
			# This message indicates that no applicable service was found for this client zone. 
			# Check your CSZoneListener/Receiver service configuration.
			# @see: Listener.CSZoneListener
			# @see: Receiver.CSZoneReceiver
			##
			log(None, CORE_POLICY, 2, "No applicable service found for this client & server zone; bindto='%s', client_zone='%s', server_zone='%s'", (self.bindto, session.client_zone, dest_zone))
		self.cache.store(cache_ndx, s)
		return s


def purgeDispatches():
	"""
        <function internal="yes">
        </function>
        """
	for i in Globals.dispatches:
		i.destroy()
	del Globals.dispatches

Globals.deinit_callbacks.append(purgeDispatches)

