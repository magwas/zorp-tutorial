############################################################################
##
## Copyright (c) 2000, 2001, 2002, 2003, 2004, 2005, 2006 BalaBit IT Ltd, Budapest, Hungary
##
## This program is free software; you can redistribute it and/or modify
## it under the terms of the GNU General Public License as published by
## the Free Software Foundation; either version 2 of the License, or
## (at your option) any later version.
##
## This program is distributed in the hope that it will be useful,
## but WITHOUT ANY WARRANTY; without even the implied warranty of
## MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
## GNU General Public License for more details.
##
## You should have received a copy of the GNU General Public License
## along with this program; if not, write to the Free Software
## Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
##
##
############################################################################

"""
<module maturity="stable">
  <summary>
    Module defining interface to Network Address Translation.
  </summary>
  <description>
    <para>
      Network Address Translation (NAT) is a technology that can be used to
      change source or destination addresses in a connection from one IP
      address to another one. This module defines the classes performing
      the translation for IP addresses.
    </para>
    <para>Zorp supports several different NAT methods using different
    NAT classes, like <link linkend="python.NAT.GeneralNAT">GeneralNAT</link>
    or <link linkend="python.NAT.StaticNAT">StaticNAT</link>. To actually
    perform network address translation in a service, you have to use a
    <link linkend="python.NAT.NATPolicy">NATPolicy</link> instance that contains
    a configured NAT class. NAT policies provide a way to re-use NAT instances
    whithout having to define NAT mappings for each service individually. </para>
  </description>
  <metainfo>
    <enums>
      <enum maturity="stable" id="enum.NAT.type">
        <description>
        </description>
        <item><name>NAT_SNAT</name></item>
        <item><name>NAT_DNAT</name></item>
      </enum>
    </enums>
  </metainfo>
</module>
"""

from Zorp import *
from SockAddr import SockAddrInet, inet_ntoa
from Domain import InetDomain
from Cache import ShiftCache
import Globals
import types

from random import choice

NAT_SNAT = 1
NAT_DNAT = 2

Globals.nat_policies[None] = None

class NATPolicy:
        """
        <class maturity="stable" type="natpolicy">
          <summary>
            Class encapsulating named NAT instances.
          </summary>
          <description>
            <para>
              This class encapsulates a name and an associated NAT instance.
              NAT policies provide a way to re-use NAT instances whithout
              having to define NAT mappings for each service
              individually.
            </para>
            <example>
            <title>Using Natpolicies</title>
            <para>
            The following example defines a simple NAT policy, and uses this
            policy for SNAT in a service.</para>
            <synopsis>
NATPolicy(name="demo_natpolicy", nat=GeneralNAT(mapping=((InetDomain(addr="10.0.1.0/24"), InetDomain(addr="192.168.1.0/24")),)))

Service(name="office_http_inter", proxy_class=HttpProxy, snat_policy="demo_natpolicy")
            </synopsis>
            </example>
          </description>
        </class>


        """
        def __init__(self, name, nat, cacheable=TRUE):
                """
                <method maturity="stable">
                  <summary>
                    Constructor to initialize a NAT policy.
                  </summary>
                  <description>
                    <para>
                      This contructor initializes a NAT policy.
                    </para>
                  </description>
                  <metainfo>
                    <arguments>
                      <argument>
                        <name>name</name>
                        <type>
                          <string/>
                        </type>
                        <description>Name identifying the NAT policy.</description>
                      </argument>
                      <argument>
                        <name>nat</name>
                        <type>
                          <class filter="nat" instance="yes"/>
                        </type>
                        <description>NAT object which performs address translation.</description>
                      </argument>
                      <argument>
                        <name>cacheable</name>
                        <type>
                          <boolean/>
                        </type>
                        <default>TRUE</default>
                        <description>Enable this parameter to cache the NAT decisions.</description>
                      </argument>
                    </arguments>
                  </metainfo>
                </method>
                """

                self.name = name
                self.nat = nat
                self.cacheable = cacheable
                if self.cacheable:
                        self.nat_cache = ShiftCache('nat(%s)' % name, 1000)
                if Globals.nat_policies.has_key(name):
                        raise ValueError, "Duplicate NATPolicy name: %s" % name
                Globals.nat_policies[name] = self

        def performTranslation(self, session, addr, nat_type):
                """
                <method internal="yes">
                </method>
                """
                if session:
                        session_id = session.session_id
                else:
                        session_id = None
                ## LOG ##
                # This message reports that the NAT type and the old address before the NAT mapping occurs.
                ##
                log(session_id, CORE_DEBUG, 4, "Before NAT mapping; nat_type='%d', old_addr='%s'", (nat_type, str(addr)))
                if self.cacheable:
                        cached = self.nat_cache.lookup(addr.ip_s)
                        if cached:
                                addr.ip_s = cached
                                v = addr
                        else:
                                ip = addr.ip_s
                                v = self.nat.performTranslation(session, addr, nat_type)
                                self.nat_cache.store(ip, v.ip_s)
                else:
                        v = self.nat.performTranslation(session, addr, nat_type)

                ## LOG ##
                # This message reports that the NAT type and the new address after the NAT mapping occurred.
                ##
                log(session_id, CORE_DEBUG, 4, "After NAT mapping; nat_type='%d', new_addr='%s'", (nat_type, str(v)))
                return v

def getNATPolicy(name):
        """
        <function internal="yes">
        </function>
        """
        if name:
                if Globals.nat_policies.has_key(name):
                        return Globals.nat_policies[name]
                else:
                        log(None, CORE_POLICY, 3, "No such NAT policy; policy='%s'", name)
        return None

class AbstractNAT:
        """
        <class maturity="stable" abstract="yes">
          <summary>
            Class encapsulating the abstract NAT interface.
          </summary>
          <description>
            <para>
              This class encapsulates an interface for application level network
              address translation (NAT). This NAT is different from the NAT used
              by packet filters: it modifies the outgoing source/destination addresses
              just before Zorp connects to the server.
            </para>
            <para>
              Source and destination NATs can be specified when a <link linkend="python.Service.Service">Service</link> is
              created.
            </para>
            <para>
              The NAT settings are used by the <link linkend="python.Chainer.ConnectChainer">ConnectChainer</link>
              class just before connecting to the server.
            </para>
          </description>
        </class>
        """

        def __init__(self):
                """
                <method maturity="stable">
                  <summary>
                    Constructor to initialize an AbstractNAT instance.
                  </summary>
                  <description>
                    <para>
                      This constructor initializes an AbstractNAT instance.
                      Currently it does nothing, but serves as a placeholder for
                      future extensions.
                    </para>
                  </description>
                  <metainfo>
                    <arguments/>
                  </metainfo>
                </method>
                """
                pass

        def setupFastpath(self, proxy):
                """
                <method internal="yes">
                  <summary>
                    Function called to setup fast path handlers.
                  </summary>
                  <description>
                    <para>
                      This function is called to provide the C-level fast path
                      handlers to the proxy, which are called when subsequent
                      connections are added to the proxy (currently only used
                      for UDP proxies)
                    </para>
                  </description>
                </method>
                """
                pass

        def performTranslation(self, session, addr, nat_type):
                """
                <method maturity="stable">
                  <summary>
                    Function that performs the address translation.
                  </summary>
                  <description>
                    <para>
                    This function is called before connecting a session
                    to the destination server. The function returns the address (a <link linkend="python.SockAddr">SockAddr</link> instance) to
                    bind to before establishing the connection.
                    </para>
                  </description>
                  <metainfo>
                    <arguments>
                      <argument maturity="stable">
                        <name>session</name>
                        <type></type>
                        <description>Session which is about to connect the server.</description>
                      </argument>
                      <argument maturity="stable">
                        <name>addr</name>
                        <type></type>
                        <description>The IP address to translate.</description>
                      </argument>
                    </arguments>
                  </metainfo>
                </method>
                """
                raise NotImplementedError

class GeneralNAT(AbstractNAT):
        """
        <class maturity="stable">
          <summary>
            Class encapsulating a general subnet-to-subnet NAT.
          </summary>
          <description>
            <para>
              This class encapsulates a general subnet-to-subnet NAT. It
              requires a list of <parameter>from, to</parameter> mapping pairs, where the elements of the pairs
              represent the source and destination subnets. The translation occurs
              according to the first matching pair.
            </para>
           <example>
            <title>GeneralNat example</title>
            <para>
            The following example defines a simple GeneralNAT policy that maps
            the <parameter>10.0.1.0/24</parameter> subnet into the
            <parameter>192.168.1.0/24</parameter> subnet.</para>
            <synopsis>
NATPolicy(name="demo_natpolicy", nat=GeneralNAT(mapping=((InetDomain(addr="10.0.1.0/24"), InetDomain(addr="192.168.1.0/24")),)))
            </synopsis>
            </example>
          </description>
        </class>
        """
        def __init__(self, mapping):
                """
                <method maturity="stable">
                  <summary>
                    Constructor to initialize a GeneralNAT instance.
                  </summary>
                  <description>
                    <para>
                      This constructor initializes a GeneralNAT instance.
                    </para>
                  </description>
                  <metainfo>
                    <arguments>
                      <argument>
                        <name>mapping</name>
                        <type>
                          <list>
                            <tuple>
                              <class filter="domain" instance="yes"/>
                              <class filter="domain" instance="yes"/>
                            </tuple>
                          </list>
                        </type>
                        <description>
                          List of pairs of InetDomains in <parameter>from, to</parameter> format.
                        </description>
                      </argument>
                    </arguments>
                  </metainfo>
                </method>
                """
                AbstractNAT.__init__(self)
                self.mapping = mapping

        def performTranslation(self, session, addr, nat_type):
                """
                <method internal="yes">
                </method>
                """
                if type(self.mapping) != types.TupleType and type(self.mapping) != types.ListType:
                        self.mapping = (self.mapping,)

                for (src_dom, dst_dom) in self.mapping:
                        if src_dom.contains(addr):
                                # addr is in domain, do translation
                                hostaddr = src_dom.getHostAddr(addr)
                                addr.ip = dst_dom.mapHostAddr(hostaddr)
                                return addr
                return addr

class ForgeClientSourceNAT(AbstractNAT):
        """
        <class maturity="stable">
          <summary>
            Class using the original client address for outgoing connections.
          </summary>
          <description>
            <para>
              This class uses the client's IP address as the source address of the server-side connection. That way the
               server sees that the connection comes from the original client instead of the firewall.
            </para>
            <para>
              This feature is useful when the source address of the server-side conneciton is important, for
              example, to webservers performing address-based access control.
            </para>
            <warning>
            <para>
              This class is OBSOLETE and may be removed in future releases.
              Use the <parameter>forge_addr</parameter> parameter of
              the <link linkend="python.Router">Router</link> class used in the service definition instead.
            </para>
            </warning>
          </description>
        </class>
        """
        def performTranslation(self, session, addr, nat_type):
                """
                <method maturity="stable">
                  <summary>
                    Function that performs the address translation.
                  </summary>
                  <description>
                    <para>
                      This function returns the original client address with
                      a dynamically allocated port number.
                    </para>
                  </description>
                  <metainfo>
                    <arguments>
                      <argument maturity="stable">
                        <name>session</name>
                        <type></type>
                        <description>Session which is about to connect the server.</description>
                      </argument>
                      <argument maturity="stable">
                        <name>addr</name>
                        <type></type>
                        <description>Th IP address to translate.</description>
                      </argument>
                    </arguments>
                  </metainfo>
                </method>
                """

                return SockAddrInet(session.client_address.ip_s, 0)

class StaticNAT(AbstractNAT):
        """
        <class maturity="stable">
          <summary>
            Class that replaces the source or destination address with
            a predefined address.
          </summary>
          <description>
            <para>
              This class assigns a predefined value to the
              address of the connection.
            </para>
          </description>
        </class>
        """
        def __init__(self, addr):
                """
                <method maturity="stable">
                  <summary>
                    Constructor to initialize a StaticNAT instance.
                  </summary>
                  <description>
                    <para>
                      This constructor initializes a StaticNAT instance.
                    </para>
                  </description>
                  <metainfo>
                    <arguments>
                      <argument maturity="stable">
                        <name>addr</name>
                        <type>
                          <sockaddr/>
                        </type>
                        <description>The address that replaces all addresses.</description>
                      </argument>
                    </arguments>
                  </metainfo>
                </method>
                """
                AbstractNAT.__init__(self)
                self.addr = addr

        def performTranslation(self, session, addr, nat_type):
                """
                <method maturity="stable">
                  <summary>
                    Function to actually perform address translation.
                  </summary>
                  <description>
                    <para>
                      This function returns the predefined address.
                    </para>
                  </description>
                  <metainfo>
                    <arguments>
                      <argument maturity="stable">
                        <name>session</name>
                        <type></type>
                        <description>Session which is about to connect the server.</description>
                      </argument>
                      <argument maturity="stable">
                        <name>addr</name>
                        <type></type>
                        <description>The IP address to translate.</description>
                      </argument>
                    </arguments>
                  </metainfo>
                </method>
                """

                return SockAddrInet(self.addr.ip_s, self.addr.port)


class OneToOneNAT(AbstractNAT):
        """
        <class maturity="stable">
          <summary>
            Class translating addresses between two IP ranges.
          </summary>
          <description>
          <note>
              <para>This class is obsolete, use <link linkend="python.NAT.OneToOneMultiNAT">GeneralNAT</link> instead.</para>
            </note>
            <para>
              This class performs 1:1 address translation between the source
              and destination subnets. If the source address
              is outside the given source address range, a <parameter>DACException</parameter> is raised.
              The source and destination subnets must have the same size.
            </para>
            <tip>
            <para>
              Use OneToOneNAT to redirect a
              a block of IP addresses to another block, for example, when the webservers
              located in the DMZ have dedicated IP aliases on the firewall.
            </para>
            </tip>
          </description>
        </class>
        """
        def __init__(self, from_domain, to_domain, default_reject=TRUE):
                """
                <method maturity="stable">
                  <summary>
                    Constructor to initialize a OneToOneNAT instance.
                  </summary>
                  <description>
                    <para>
                      This constructor initializes a OneToOneNAT instance. Arguments must be
                      <parameter>InetDomain</parameter> instances specifying two non-overlapping IP subnets
                      with the same size.
                    </para>
                  </description>
                  <metainfo>
                    <arguments>
                      <argument maturity="stable">
                        <name>from_domain</name>
                        <type>
                          <class filter="domain" instance="yes"/>
                        </type>
                        <description>The source subnet (InetDomain instance).</description>
                      </argument>
                      <argument maturity="stable">
                        <name>to_domain</name>
                        <type>
                          <class filter="domain" instance="yes"/>
                        </type>
                        <description>The destination subnet (InetDomain instance).</description>
                      </argument>
                      <argument maturity="stable">
                        <name>default_reject</name>
                        <type>
                          <boolean/>
                        </type>
                        <default>TRUE</default>
                        <description>Enable this parameter to reject all connections outside the specific source
                        range.</description>
                      </argument>
                    </arguments>
                  </metainfo>
                </method>
                """
                AbstractNAT.__init__(self)
                self.from_domain = from_domain
                self.to_domain = to_domain
                self.default_reject = default_reject
                if from_domain.mask_bits != to_domain.mask_bits:
                        raise ValueError, 'OneToOneNAT requires two domains of the same size'

        def performTranslation(self, session, addr, nat_type):
                """
                <method maturity="stable">
                  <summary>
                    Function that performs the OneToOneNAT translation.
                  </summary>
                  <description>
                    <para>
                      This function modifies the source address to its corresponding address in the
                      destination address range. The function returns the new address.
                    </para>
                  </description>
                  <metainfo>
                    <arguments>
                      <argument maturity="stable">
                        <name>session</name>
                        <type></type>
                        <description>Session which is about to connect the server.</description>
                      </argument>
                      <argument maturity="stable">
                        <name>addr</name>
                        <type></type>
                        <description>The IP address to translate.</description>
                      </argument>
                    </arguments>
                  </metainfo>
                </method>
                """
                try:
                        return self.mapAddress(addr, self.from_domain, self.to_domain, nat_type)
                except ValueError:
                        pass
                if self.default_reject:
                        raise DACException, 'IP not within the required range.'
                else:
                        return addr

        def mapAddress(self, addr, from_domain, to_domain, nat_type):
                """
                <method internal="yes">
                  <summary>
                    Function to map an address to another subnet.
                  </summary>
                  <description>
                    <para>
                      This function maps the address 'addr' in the domain
                      'from_domain' to another domain 'to_domain'.
                      Returns a SockAddrInet in the destination domain or None
                    </para>
                  </description>
                  <metainfo>
                    <arguments>
                      <argument maturity="stable">
                        <name>from_domain</name>
                        <type></type>
                        <description>source domain</description>
                      </argument>
                      <argument maturity="stable">
                        <name>to_domain</name>
                        <type></type>
                        <description>destination domain</description>
                      </argument>
                      <argument maturity="stable">
                        <name>nat_type</name>
                        <type></type>
                        <description>specifies the NAT type</description>
                      </argument>
                    </arguments>
                  </metainfo>
                </method>
                """
                if addr < from_domain:
                        ip = (addr.ip & ~to_domain.mask) + (to_domain.ip & to_domain.mask)
                        if nat_type == NAT_SNAT:
                                return SockAddrInet(inet_ntoa(ip), 0)
                        elif nat_type == NAT_DNAT:
                                return SockAddrInet(inet_ntoa(ip), addr.port)

class OneToOneMultiNAT(OneToOneNAT):
        """
        <class maturity="stable">
          <summary>
            Class translating addresses between two IP ranges.
          </summary>
          <description>
            <note>
              <para>This class is obsolete, use <link linkend="python.NAT.OneToOneMultiNAT">GeneralNAT</link> instead.</para>
            </note>
            <para>
              This class is similar to <link target="python.NAT.OneToOneNAT">OneToOneNAT</link> as it 1:1 address
               translation between the source and destination subnets. The difference is that the OneToOneMultiNAT class
                supports multiple mappings by using a list of mapping pairs.
            </para>
            <para>
              If the source address
              is outside the given source address range, a <parameter>DACException</parameter> is raised.
              The source and destination subnets must have the same size.
            </para>
          </description>
        </class>
        """
        def __init__(self, mapping, default_reject=TRUE):
                """
                <method maturity="stable">
                  <summary>
                    Constructor to initialize a OneToOneMultiNAT instance.
                  </summary>
                  <description>
                    <para>
                      This constructor initializes an instance of the OneToOneMultiNAT class. Arguments must be
                      <parameter>InetDomain</parameter> instances specifying two non-overlapping IP subnets
                      with the same size.
                    </para>
                  </description>
                  <metainfo>
                    <arguments>
                      <argument maturity="stable">
                        <name>mapping</name>
                        <type>
                          <list>
                            <tuple>
                              <class filter="domain" instance="yes"/>
                              <class filter="domain" instance="yes"/>
                            </tuple>
                          </list>
                        </type>
                        <description>
                          List of <parameter>InetDomain</parameter> pairs in the <parameter>from, to</parameter> format.
                        </description>
                      </argument>
                      <argument maturity="stable">
                        <name>default_reject</name>
                        <type>
                          <boolean/>
                        </type>
                        <default>TRUE</default>
                        <description>Enable this parameter to reject all connections outside the specific source
                        range.</description>
                      </argument>
                    </arguments>
                  </metainfo>
                </method>
                """
                AbstractNAT.__init__(self)
                self.mapping = mapping
                self.default_reject = default_reject
                for (from_domain, to_domain) in mapping:
                        if from_domain.mask_bits != to_domain.mask_bits:
                                raise ValueError, 'OneToOneMultiNAT requires two domains of the same size'

        def performTranslation(self, session, addr, nat_type):
                """
                <method maturity="stable">
                  <summary>
                    Function to actually perform 1:1 NAT
                  </summary>
                  <description>
                    <para>
                      This function modifies the source address to its corresponding address in the
                      destination address range. The function returns the new address.
                    </para>
                  </description>
                  <metainfo>
                    <arguments>
                      <argument maturity="stable">
                        <name>session</name>
                        <type></type>
                        <description>Session which is about to connect the server.</description>
                      </argument>
                      <argument maturity="stable">
                        <name>addr</name>
                        <type></type>
                        <description>The IP address to translate.</description>
                      </argument>
                    </arguments>
                  </metainfo>
                </method>
                """
                for (from_domain, to_domain) in self.mapping:
                        try:
                                return self.mapAddress(addr, from_domain, to_domain, nat_type)
                        except ValueError:
                                pass
                if self.default_reject:
                        raise DACException, 'IP not within the required range.'
                else:
                        return addr

class RandomNAT(AbstractNAT):
        """
        <class maturity="stable">
          <summary>
            Class generating a random IP address.
          </summary>
          <description>
            <para>
              This class randomly selects an address from a list of IP addresses.
              This can be used for load-balancing several lines by binding
              each session to a different interface.
            </para>
          </description>
        </class>
        """
        def __init__(self, addresses):
                """
                <method maturity="stable">
                  <summary>
                    Constructor to initialize a RandomNAT instance.
                  </summary>
                  <description>
                    <para>
                      This constructor initializes a RandomNAT instance.
                    </para>
                  </description>
                  <metainfo>
                    <arguments>
                      <argument maturity="stable">
                        <name>addresses</name>
                        <type>
                          <list>
                            <sockaddr/>
                          </list>
                        </type>
                        <description>List of the available interfaces. Each item of the list must be am instance
                        of the <parameter>SockAddr</parameter> (or a derived) class.</description>
                      </argument>
                    </arguments>
                  </metainfo>
                </method>
                """
                AbstractNAT.__init__(self)
                self.addresses = addresses

        def performTranslation(self, session, addr, nat_type):
                """
                <method maturity="stable">
                  <summary>
                    Function that performs random address translation.
                  </summary>
                  <description>
                    <para>
                      This function modifies the source address to a random address from the
                      list of available addresses. The function returns the new address.
                    </para>
                  </description>
                  <metainfo>
                    <arguments>
                      <argument maturity="stable">
                        <name>session</name>
                        <type></type>
                        <description>Session which is about to connect the server.</description>
                      </argument>
                      <argument maturity="stable">
                        <name>addr</name>
                        <type></type>
                        <description>The IP address to translate.</description>
                      </argument>
                    </arguments>
                  </metainfo>
                </method>
                """
                return choice(self.addresses)

class HashNAT(AbstractNAT):
        """
        <class maturity="stable">
          <summary>
            Class which sets the address from a hash table.
          </summary>
          <description>
           HashNAT statically maps an IP address to
           another using a hash table. The table is indexed by the source IP address, and the
           value is the translated IP address. Both IP addresses are stored in string format.
          </description>
        </class>
        """
        def __init__(self, ip_hash, default_reject=TRUE):
                """
                <method maturity="stable">
                  <summary>
                    Constructor to initialize a HashNAT instance.
                  </summary>
                  <description>
                    <para>
                      This constructor initializes a HashNAT instance.
                    </para>
                  </description>
                  <metainfo>
                    <arguments>
                      <argument maturity="stable">
                        <name>ip_hash</name>
                        <type>
                          <hash>
                            <key>
                              <string/>
                            </key>
                            <value>
                              <string/>
                            </value>
                          </hash>
                        </type>
                        <description>The hash storing the IP address.</description>
                      </argument>
                      <argument maturity="stable">
                        <name>default_reject</name>
                        <type>
                          <boolean/>
                        </type>
                        <default>TRUE</default>
                        <description>Enable this parameter to reject all connections outside the specific source
                        range.</description>
                      </argument>
                    </arguments>
                  </metainfo>
                </method>
                """
                AbstractNAT.__init__(self)
                self.ip_hash = ip_hash
                self.default_reject = default_reject

        def performTranslation(self, session, addr, nat_type):
                """
                <method maturity="stable">
                  <summary>
                    Function to actually perform hash based translation.
                  </summary>
                  <description>
                    <para>
                      This function modifies the source address to the corresponding address from the
                      hash table. The function returns the new address.
                    </para>
                  </description>
                  <metainfo>
                    <arguments>
                      <argument maturity="stable">
                        <name>session</name>
                        <type></type>
                        <description>Session which is about to connect the server.</description>
                      </argument>
                      <argument maturity="stable">
                        <name>addr</name>
                        <type></type>
                        <description>The IP address to translate.</description>
                      </argument>
                      <argument maturity="stable">
                        <name>nat_type</name>
                        <type></type>
                        <description>nat type</description>
                      </argument>
                    </arguments>
                  </metainfo>
                </method>
                """
                try:
                        if nat_type == NAT_SNAT:
                                ip = self.ip_hash[addr.ip_s]
                                return SockAddrInet(ip, 0)
                        else:
                                ip = self.ip_hash[addr.ip_s]
                                return SockAddrInet(ip, addr.port)
                except KeyError:
                        if self.default_reject:
                                raise DACException, 'IP not within the required range.'
                        else:
                                return addr

