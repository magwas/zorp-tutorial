############################################################################
##
## Copyright (c) 2000, 2001, 2002, 2003, 2004, 2005, 2006 BalaBit IT Ltd, Budapest, Hungary
##
## This program is free software; you can redistribute it and/or modify
## it under the terms of the GNU General Public License as published by
## the Free Software Foundation; either version 2 of the License, or
## (at your option) any later version.
##
## This program is distributed in the hope that it will be useful,
## but WITHOUT ANY WARRANTY; without even the implied warranty of
## MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
## GNU General Public License for more details.
##
## You should have received a copy of the GNU General Public License
## along with this program; if not, write to the Free Software
## Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
##
##
############################################################################
"""
<module maturity="stable">
  <summary>
    Module defining interface to the Notifications.
  </summary>
</module>
"""

from Zorp import *
import os, re, string, types, time, socket

class NotificationPolicy:
	"""<class maturity="stable" type="notificationpolicy">
          <summary>
            Class encapsulating a NotificationPolicy which describes how to send out notifications.
          </summary>
          <description>
            <para>
            </para>
          </description>
        </class>
        """
	def __init__(self, method, alerts = None, rate_threshold = 0, rate_interval = 60):
		"""<method internal="yes">
		<metainfo>
		  <arguments>
		    <argument maturity="stable">
		      <name>name</name>
		      <type>
			<string/>
		      </type>
		      <description>The name of the NotificationPolicy</description>
		    </argument>
		    <argument maturity="stable">
		      <name>notification</name>
		      <type>
		      </type>
		      <description>The encapsulated Notification instance</description>
		    </argument>
		    <argument maturity="stable">
		      <name>n</name>
		      <type>
                        <integer/>
		      </type>
		      <description>The maximum allowed number of events in a given time interval, def.:0 (rate check disabled)</description>
		    </argument>
		    <argument maturity="stable">
		      <name>delta_t</name>
		      <type>
                        <integer/>
		      </type>
		      <description>The length of the rate interval is seconds, def.: 60 (1 min)</description>
		    </argument>
		  </arguments>
		</metainfo>
		</method>
		"""
                self.method = method
                self.alerts = alerts
                self.rate_threshold = rate_threshold
                self.rate_interval = rate_interval
                self.q = []
		Globals.notification_policy = self

	def notify(self, event, params):
                """<method internal="yes">
                <metainfo>
                  <arguments>
                    <argument maturity="stable">
                      <name>self</name>
                      <type>
                      </type>
                      <description>The current instance</description>
                    </argument>
                    <argument>
                      <name>event</name>
                      <type/>
                      <description>The name of the event</description>
                    </argument>
                    <argument maturity="stable">
                      <name>params</name>
                      <type>
                      </type>
                      <description>The additional event parameters</description>
                    </argument>
                  </arguments>
                </metainfo>
                </method>
                """
                try:
                        alert_enabled = self.alerts[event]
                except KeyError:
                        alert_enabled = self.alerts['*']
                else:
                        alert_enabled = False
                
                if not alert_enabled:
                        return
                
                # FIXME: use an event specific rate limit
                if self.rate_threshold > 0:
                        qlen = len(self.q)
                        now = time.time()
                        if qlen < self.rate_threshold:
                                self.q.append(now)
                        elif (now - self.q[0]) >= self.rate_interval:
                                del self.q[0]
                                self.q.append(now)
                        else:
		                log(None, CORE_ERROR, 3, "Notification would exceed rate limit; event='%s'", (event))
                                return
		log(None, CORE_DEBUG, 7, "Sending notification; event='%s'", (event))
                self.method.notify(event, params)

class AbstractNotificationMethod:
	"""
        <class maturity="stable" abstract="yes">
          <summary>
            Class encapsulating the abstract notification method.
          </summary>
          <description>
            <para>
              This abstract class encapsulates a notification whose purpose is to
              be able to be called on some event.
            </para>
            <para>
              Specialized subclasses of AbstractNotification exist such as 'EmailNotification'
              which process the event in more specialised ways.
            </para>
          </description>
          <metainfo>
            <attributes/>
          </metainfo>
        </class>
	"""
	def __init__(self):
		"""
                <method internal="yes">
                  <summary>
                    Constructor to initialize an AbstractNotification instance.
                  </summary>
                  <description>
                    This constructor initializes an AbstractNotification instance, currently it
                    does nothing.
                  </description>
                  <metainfo>
                    <arguments>
                      <argument maturity="stable">
                        <name>self</name>
                        <type></type>
                        <description>this instance</description>
                      </argument>
                    </arguments>
                  </metainfo>
                </method>
		"""
		pass
		
	def notify(self, event, params):
		"""
                <method internal="yes">
                  <summary>
                    Virtual function that is called when the event occurs.
                  </summary>
                  <description>
                    <para>
                      This function is the actual entry point of the event handler.
                    </para>
                    <para>
      	              It can raise a NotificationException to indicate general failure.
                    </para>
                  </description>
                  <metainfo>
                    <arguments>
                      <argument maturity="stable">
                        <name>self</name>
                        <type></type>
                        <description>this instance</description>
                      </argument>
                      <argument maturity="stable">
                        <name>event</name>
                        <type></type>
                        <description>name of the event</description>
                      </argument>
                      <argument maturity="stable">
                        <name>params</name>
                        <type></type>
                        <description>parameters associated with the event</description>
                      </argument>
                    </arguments>
                  </metainfo>
                </method>
		"""
		raise NotImplementedError


class EmailNotificationMethod(AbstractNotificationMethod):
	"""
        <class maturity="stable">
          <summary>
            Class encapsulating the Notification which handles the event by sending out an e-mail.
          </summary>
          <description>
            <para>
              This class encapsulates a notification handler that sends an e-mail with the given
              mail properties.
            </para>
          </description>
          <metainfo>
            <attributes>
              <attribute maturity="stable">
                <name>recipient</name>
                <type></type>
                <description>recipient of the e-mail</description>
              </attribute>
            </attributes>
          </metainfo>
        </class>
	"""
	def __init__(self, recipient):
		"""
                <method maturity="stable">
                  <summary>
                    Constructor to initialize an EmailNotification instance.
                  </summary>
                  <description>
                    <para>
                      This constructor initializes an EmailNotification instance by setting
                      mail attributes.
                    </para>
                  </description>
                  <metainfo>
                    <arguments>
                      <argument maturity="stable">
                        <name>self</name>
                        <type></type>
                        <description>this instance</description>
                      </argument>
                      <attribute maturity="stable">
                        <name>recipient</name>
                        <type></type>
                        <description>recipient of the e-mail</description>
                      </attribute>
                    </arguments>
                  </metainfo>
                </method>
		"""
                AbstractNotificationMethod.__init__(self)
                self.recipient = recipient

	def notify(self, event, params):
		"""
                <method internal="yes">
                  <summary>
                    Virtual function that is called when the event occurs.
                  </summary>
                  <description>
                    <para>
                      This function is the actual entry point of the event handler.
                    </para>
                    <para>
      	              It can raise a NotificationException to indicate general failure.
                    </para>
                  </description>
                  <metainfo>
                    <arguments>
                      <argument maturity="stable">
                        <name>self</name>
                        <type></type>
                        <description>this instance</description>
                      </argument>
                      <argument maturity="stable">
                        <name>event</name>
                        <type></type>
                        <description>name of the event</description>
                      </argument>
                      <argument maturity="stable">
                        <name>params</name>
                        <type></type>
                        <description>parameters associated with the event</description>
                      </argument>
                    </arguments>
                  </metainfo>
                </method>
		"""
                p = os.popen("/usr/sbin/sendmail -oi -bm '%s'" % self.recipient, "w")
                subst = { 
                        'instance': Globals.instance_name, 
                        'hostname': socket.gethostname(), 
                        'recipient': self.recipient, 
                        'event': event 
                }
                content = "From: zorp@%(hostname)s\r\nTo: %(recipient)s\r\nSubject: ** ALERT: %(event)s - %(instance)s@%(hostname)s **\r\n\r\n" % subst
                content = content + "This is a Zorp generated alert generated by %(instance)s on %(hostname)s\r\n\r\nEvent: %(event)s\r\n\r\n" % subst
                for (key, value) in params:
                        if key[0] != '_':
                                content = content + '%s: %s\r\n' % (key, value)
                p.write(content)
                p.close()


