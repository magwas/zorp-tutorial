
This directory contains the Testcase Database suitable for ZTS (Zorp Test
System) for processing.
