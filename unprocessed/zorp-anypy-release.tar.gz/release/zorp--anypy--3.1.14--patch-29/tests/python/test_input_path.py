from Zorp.Core import *
from Zorp.Zorp import quit, init
from Zorp.Zone import root_zone
from Zorp.SockAddr import inet_ntoa, htonl
from Zorp.Session import MasterSession
from traceback import *
from time import time
import profile

class DummyProxy:
        name = "dummy"
        def __init__(self, session):
                pass

class DummyStream:
        fd = -1
        name = "noname"
        
        def close(self):
                pass
                
count = 10000
do_profile = 1

def benchmark():
        global listener, count
        for i in range(1, count):
                listener.accepted(stream=DummyStream(), 
                        client_address=SockAddrInet('192.168.1.6', 5555), 
                        client_local=SockAddrInet('192.168.1.5', 80),
                        client_listen=SockAddrInet('0.0.0.0', 56789))


def zorp():
        global listener
	try:
		t1 = InetZone("test1", "192.168.0.0/24", inbound_services=["s1"], outbound_services=["s2"])
		t2 = InetZone("test2", "192.168.0.32/27")
		t3 = InetZone("test3", "192.168.0.0/26")
		t4 = InetZone("test4", "192.168.0.64/27")
		t5 = InetZone("test5", "192.168.0.96/27")
		t6 = InetZone("test6", "192.168.0.0/25")
		t7 = InetZone("test7", "192.168.0.0/16")
		t8 = InetZone("test8", "192.168.1.1/32", admin_parent="test1")
		t9 = InetZone("test9", "192.168.1.2/32", admin_parent="test8")
		t10 = InetZone("test10", "192.168.1.3/32", admin_parent="test9", umbrella=1)
		t11 = InetZone("test11", "192.168.1.4/32", admin_parent="test9")
		t12 = InetZone("test12", "192.168.1.5/32", inbound_services=['*'])
		t13 = InetZone("test13", "192.168.1.6/32", outbound_services=['*'])

		inet = InetZone("internet", "0.0.0.0/0", inbound_services=["s2"], outbound_services=["s1"])
		
		Service('test-service', DummyProxy, router=TransparentRouter())
		
		listener = CSZoneListener(SockAddrInet('0.0.0.0', 56789), 
		                services={('test1', 'test2'): 'test-service',
		                          ('test1', 'test3'): 'test-service',
		                          ('*', '*'): 'test-service'})
                
                start = time()
                if do_profile:
                        profile.run("benchmark()", 'profile.out')
                else:
                        benchmark()
                end = time()
                
                print 'Connection rate: %f' % (1 / ((end-start)/count))

	except Exception, e:
		print_exc()
		quit(1)
		return 1
		
	quit(0)
	return 1
