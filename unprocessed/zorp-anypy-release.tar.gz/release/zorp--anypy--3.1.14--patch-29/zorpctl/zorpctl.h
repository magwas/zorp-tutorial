#ifndef ZORPCTL_ZORPCTL_H_INCLUDED
#define ZORPCTL_ZORPCTL_H_INCLUDED

#include <zorpconfig.h>

#define FALSE 0
#define TRUE  1

#endif

