############################################################################
##
## Copyright (c) 2000-2001 BalaBit IT Ltd, Budapest, Hungary
## All rights reserved.
##
## $Id: policy.py.sample,v 1.16 2003/02/11 14:45:32 bazsi Exp $
##
############################################################################

#
# sample firewall policy with transparent access to FTP, HTTP and CVS protocols.
# For FTP and HTTP we use application level gateways, for CVS we use a plug.
# (as long as CVS protocol proxy is not available)
#
# firewall internal network: 192.168.1.0/24
# firewall internal interface: 192.168.1.1
# firewall external interface: 193.225.235.6
#

import sys
sys.path.append('/etc/zorp')
from Zorp.Core import *
from Zorp.Plug import *
from local.FormProxy import FormProxy, CheckTrue, CheckFalse, CheckString, CheckFileTrue
import re

Zorp.firewall_name = 'zorp@site'

InetZone("local", "127.0.0.0/8",
	 inbound_services=["*"],
	 outbound_services=["*"])
	
InetZone("internet", "0.0.0.0/0",
	 inbound_services=["*"],
	 outbound_services=[])


#
# Let's define a transparent http proxy, which rewrites the user_agent
# header to something different.
#

class MyFormProxy(FormProxy):
	def config(self):
		self.transparent_mode = TRUE
		# self.parent_proxy = "proxy.site.net"
		# self.parent_proxy_port = 3128
		self.timeout = 10000
		# self.max_keepalive_requests = 10
		policy={
			("http://mag.webhome.hu/test/form","family"): CheckString(self,0,30),
			("*","gender"): CheckString(self,0,4),
			("*","thename"): CheckString(self,0,8),
			("*","*"): CheckTrue(),
		}
		filepolicy={
			("*","*","image","*"): CheckFileTrue(),
		}
		self.set_form_policy(policy,filepolicy,silent_drop=0,drop_empty=1,one_blob=1,filename_pattern="^[a-z]$",default_filename="nocsak.egy.file")
		self.error_files_directory="/home/mag/test/6/http"
	
		
# zorp_http instance
def http():
	
	# create services
	Service("intra_http", MyFormProxy, router=DirectedRouter(SockAddrInet('127.0.0.1',1234)))
	
	# bind services to listeners
	# you'll need the packet filter redirect these connections, and
	# to protect transparent listeners, since if you connect to
	# a transparent listener directly, Zorp reconnects to itself.
	Listener(SockAddrInet("127.0.0.1", 1235), "intra_http")

