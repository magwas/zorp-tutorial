from Zorp.Core import *
import re
#We need AnyPy for the proxy class, and Zorp for logging
from Zorp import AnyPy,Zorp,Http
#We use urllib for unquoting and quoting
import urllib

class CheckString:
	def __init__(self,proxy,minlen=0,maxlen=30,regex=None):
		self.maxlen=maxlen
		self.minlen=minlen
		self.re=regex
		if regex:
			regex=re.compile(regex)
		self.regex = regex

	def __call__(self,proxy,name,value):
		Zorp.log("form.info",3, "%s: checking (%s,%s) with CheckString(%u,%u,%s)" % (proxy.session.session_id, name, value.encode("string_escape"),self.minlen,self.maxlen,self.re))
		if self.minlen <= len(value) <= self.maxlen:
			if self.regex:
				if not self.regex.search(value):
					return False
			return (name,value)
		return False

class UrlEncodedProxy(AnyPy.AnyPyProxy):
        def checkOneArg(self,request_url,name,value):
                for searcher in [(request_url,name),("*",name),("request_url",name),("*","*")]:
                        if self.policy.has_key(searcher):
                                Zorp.log("form.info",2, "%s: got checker for %s " % (self.session.session_id, searcher))
                                return self.policy[searcher](self,name,value)
                else:
                        Zorp.log("form.policy",2, "%s: no default checker, giving up " % (self.session.session_id))
                        return 0

        def proxyThread(self):
                Zorp.log("form.info",0, "%s: starting anypy thread" % (self.session.session_id))
		self.policy = self.session.owner.proxy.policy
                client_data=self.client_stream.read(65536)
                request_url=self.session.owner.proxy.request_url
                ret=[]
                for arg in client_data.split("&"):
                        nv = arg.split("=")
                        if len(nv) != 2:
                                        self.set_verdict(AnyPy.ANYPY_DENY,"invalid form data: %u"%(len(nv)))
                                        return False
                        (name,value) = nv
                        if not re.match("^[A-Za-z][A-Za-z0-9-_:\.]*$",name):
                                Zorp.log("form.policy", 3, "%s: DENY: invalid control name" % (self.session.session_id))
                                self.set_verdict(AnyPy.ANYPY_DENY,"invalid control name")
                                return False
                        value=urllib.unquote_plus(value)
                        Zorp.log("form.info",1, "%s: checking (%s,%s)" % (self.session.session_id, name, value.encode("string_escape")))
                        r=self.checkOneArg(request_url,name,value)
                        if r == False:
                                self.set_verdict(AnyPy.ANYPY_DENY,"invalid form value for %s"%(name))
                                return False
                        (name,value)=r
                        value=urllib.quote_plus(value)
                        ret.append("%s=%s"%(name,value))
                data_for_server = "&".join(ret)
                self.server_stream.write(data_for_server)


Zorp.firewall_name = 'zorp@site'

InetZone("local", "127.0.0.0/8",
         inbound_services=["*"],
         outbound_services=["*"])
        
class MyFormProxy(Http.HttpProxy):
        def contentType(self,name,value):
                Zorp.log("form.info",1, "%s: content-type header detected" % (self.session.session_id))
                if re.match("(?i)aPplication/x-www-form-urlencoded",value):
                        self.request_stack["POST"] = (Http.HTTP_STK_DATA, UrlEncodedProxy)
                return Http.HTTP_HDR_ACCEPT

        def config(self):
                Http.HttpProxy.config(self)
                self.transparent_mode = TRUE
                self.timeout = 10000
                self.policy={
                        ("*","gender"): CheckString(self,0,4),
                        ("*","thename"): CheckString(self,0,9),
                        ("*","files"): CheckString(self,0,30),
                        ("*","*"): CheckString(self,0,9),
                }
                self.request_headers["CONTENT-TYPE"] = (Http.HTTP_HDR_POLICY, self.contentType)
                self.request_stack["POST"] = (Http.HTTP_STK_DATA, UrlEncodedProxy)

        
def http():
        Service("intra_http", MyFormProxy, router=DirectedRouter(SockAddrInet('127.0.0.1',1234)))
        Listener(SockAddrInet("127.0.0.1", 1235), "intra_http")

