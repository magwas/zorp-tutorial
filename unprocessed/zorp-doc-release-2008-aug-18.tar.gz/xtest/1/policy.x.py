############################################################################
##
## Copyright (c) 2000-2001 BalaBit IT Ltd, Budapest, Hungary
## All rights reserved.
##
## $Id: policy.py.sample,v 1.16 2003/02/11 14:45:32 bazsi Exp $
##
############################################################################


import sys
sys.path.append('/etc/zorp')
from Zorp.Core import *
from Zorp.Plug import *
from Zorp import Zorp,AnyPy,Stream
import time

Zorp.firewall_name = 'zorp@site'

InetZone("local", "127.0.0.0/8",
	 inbound_services=["*"],
	 outbound_services=["*"])
	
InetZone("internet", "0.0.0.0/0",
	 inbound_services=["*"],
	 outbound_services=[])




AbortProxyException="Abort Proxy"
CRLF="\r\n"


class NonblockProxy(AnyPy.AnyPyProxy):
	def __init__(self,session):
		AnyPy.AnyPyProxy.__init__(self,session)

	def config(self):
		pass

	def abortProxy(self,message):
		"""
			<method>
				Policy violation happened, we set a DENY verdict with the given message and raise AbortProxyException
			</method>
		"""
		Zorp.log("nonblock.policy", 3, "DENY: %s" % message)
		self.set_verdict(AnyPy.ANYPY_DENY,message)
		raise AbortProxyException

	def proxyThread(self):
		Zorp.log("nonblock.debug", 3, "thread started" )
		while 1:
			clientdata=self.client_stream.read(65535)
			Zorp.log("nonblock.debug", 3, "client said: %s"%clientdata.encode("string_escape"))
			self.server_stream.write(clientdata)
			serverdata=self.server_stream.read(65535)
			Zorp.log("nonblock.debug", 3, "server said: %s"%serverdata.encode("string_escape"))
			self.client_stream.write(serverdata)
		Zorp.log("nonblock.debug", 3, "done" )


		
# zorp_http instance
def x11():
	
	# create services
	Service("local_x11", NonblockProxy, router=DirectedRouter(SockAddrInet('127.0.0.1',6001)))
	
	# bind services to listeners
	# you'll need the packet filter redirect these connections, and
	# to protect transparent listeners, since if you connect to
	# a transparent listener directly, Zorp reconnects to itself.
	Listener(SockAddrInet("127.0.0.1", 6002), "local_x11")

