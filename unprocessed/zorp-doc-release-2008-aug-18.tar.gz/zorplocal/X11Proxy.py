############################################################################
##
## Copyright (c) 2008, �rp�d Magos�nyi
##
## This program is free software; you can redistribute it and/or modify
## it under the terms of the GNU General Public License as published by
## the Free Software Foundation; either version 2 of the License, or
## (at your option) any later version.
##
## This program is distributed in the hope that it will be useful,
## but WITHOUT ANY WARRANTY; without even the implied warranty of
## MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
## GNU General Public License for more details.
##
## You should have received a copy of the GNU General Public License
## along with this program; if not, write to the Free Software
## Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
##
## $Id$
##
## Author  : Mag
## Auditor : 
## Last audited version:
## Notes:
##
############################################################################

from Zorp import Zorp,AnyPy,Stream
import time

#FIXME: these should go to Stream.py

G_IO_IN=1
G_IO_OUT=4


AbortProxyException="Abort Proxy"
CRLF="\r\n"


class X11Proxy(AnyPy.AnyPyProxy):
	def __init__(self,session):
		AnyPy.AnyPyProxy.__init__(self,session)

	def config(self):
		pass

	def abortProxy(self,message):
		"""
			<method>
				Policy violation happened, we set a DENY verdict with the given message and raise AbortProxyException
			</method>
		"""
		Zorp.log("x11.policy", 3, "DENY: %s" % message)
		self.set_verdict(AnyPy.ANYPY_DENY,message)
		raise AbortProxyException

	def callback(self,stream,otherside):
		Zorp.log("x11.debug", 3, "client called for %s" % stream)
		while 1:
			try:
				requests=stream.read(65536)
			except Stream.StreamException, (status,buffer):
				if status == Stream.G_IO_STATUS_EOF:
					Zorp.log("x11.debug", 3, "EOF, bailing out")
					return 1
				elif status == Stream.G_IO_STATUS_AGAIN:
					Zorp.log("x11.debug", 3, "again ")
					return 0
				else:
					raise
			Zorp.log("x11.debug", 3, "request len=%u,request=%s" % (len(requests),requests.encode("string_escape")))
			otherside.write(requests)
		return 0

		
	def proxyThread(self):
		Zorp.log("x11.debug", 3, "thread started" )
		self.register_callback(G_IO_IN,self.callback,self.client_stream,self.server_stream,self.session.session_id)
		Zorp.log("x11.debug", 3, "callback is set on client stream" )
		self.register_callback(G_IO_IN,self.callback,self.server_stream,self.client_stream,self.session.session_id)
		Zorp.log("x11.debug", 3, "callback is set on server stream" )
		#FIXME: somehow we have to go to sleep here
		while self.poll_iter_timeout(60000):
			Zorp.log("x11.debug", 3, "poll iter timed out" )
			pass
		Zorp.log("x11.debug", 3, "done" )

