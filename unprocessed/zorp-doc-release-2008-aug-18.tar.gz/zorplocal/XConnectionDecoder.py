#!/usr/bin/python
# coding=utf-8
#Warning: it is ugly code, do not read it right after eating!

import os,sys
import socket
import struct
#import time
import fcntl
if hasattr(fcntl, 'F_SETFD'):
    F_SETFD = fcntl.F_SETFD
    if hasattr(fcntl, 'FD_CLOEXEC'):
        FD_CLOEXEC = fcntl.FD_CLOEXEC
    else:
        FD_CLOEXEC = 1
else:
    from FCNTL import F_SETFD, FD_CLOEXEC

from Xlib import protocol

def fake_rc(display,value):
	return value
class fake_display:
	def get_resource_class(self,name):
		return fake_rc

class XConnectionDecoder:
	def __init__(self,logfile,dumpfile):
		self.reqno = 0
		self.reqlist={}
		self.d=fake_display()
		self.connsetup = None
		self.logfile=logfile
		self.dumpfile=dumpfile
		self.pending=""

	def write(self,what,detail):
		self.logfile.write("%s: %s\n"%(what,detail))

	def dump(self,direction,data):
		self.dumpfile.write("%s:%s:%s"%(direction,len(data),data))

	def decode_req(self,data):
		"""
		decodes request, and writes it through self.write
		"""
		self.dump("s",data)
		while data:
			code,pad,length = struct.unpack("BBH",data[0:4])
			packet=data[:length*4]
			data=data[length*4:]
			if self.reqno:
				opcode=struct.unpack("B",packet[0])[0]
				request=protocol.request.major_codes[opcode]
				self.reqlist[self.reqno]=request
				dic = request._request.parse_binary(packet,self.d,rawdict=1)
			else:
				dic=protocol.display.ConnectionSetupRequest._request.parse_binary(packet,self.d,rawdict=1)
				request=protocol.display.ConnectionSetupRequest
				self.connsetup=request
			self.reqno += 1
			self.write(request,dic[0])

	def decode_rep(self,data):
		self.dump("r",data)
		data=self.pending+data
		self.penfing=""
		while data:
			if self.connsetup:
				(rep,data)=self.connsetup._reply.parse_binary(data,self.d,rawdict=1)
				self.write("setup reply",rep)
				(rep,data)=self.connsetup._success_reply.parse_binary(data,self.d,rawdict=1)
				self.write("setup reply cont",rep)
				self.connsetup = False
				continue
			code,pad,seqno,length = struct.unpack("BBHL",data[0:8])
			#print code,pad,seqno,length*4+32,len(data)
			if code <2 and (len(data) < length*4+32 ):
				self.pending=data
				self.write("short packet","len=%s,have=%s"%(length*4+32,len(data)))
				return
			if code <2 or self.connsetup:
				request=self.reqlist[seqno]
				(rep,data)=request._reply.parse_binary(data,self.d,rawdict=1)
				self.write("%s reply"%request,rep)
				if self.reqlist.has_key(seqno):
					del(self.reqlist[seqno])
			else:
				try:
					event = protocol.event.event_class[code&0x7f]
					(rep,data)=event._fields.parse_binary(data,self.d,rawdict=1)
				except KeyError:
					event="Unknown event"
					rep=code
					data=data[32:]
				self.write(event,rep)

	def get_socket(self,dname,host,dno):
		s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
		def my_sock_send(data,flags=0,oldsend=s.send):
			self.decode_req(data)
			return oldsend(data,flags)
		s.send=my_sock_send
		def my_sock_recv(buffersize,flags=0,oldrecv=s.recv):
			data=oldrecv(buffersize,flags)
			self.decode_rep(data)
			return data
		s.recv=my_sock_recv
		s.connect((host, 6002,))
		fcntl.fcntl(s.fileno(), F_SETFD, FD_CLOEXEC)
		return s


